import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'active_job_tab.dart';
import 'dashboard_home_tab.dart';
import 'employee_requets_tab.dart';
import 'main.dart';
import 'map_tab.dart';
import 'session_utils.dart';
import 'settings_screen.dart';
import 'shared/models/service_request.dart';
import 'shared/services/request_service.dart';
import 'shared/widgets/employee_request_card.dart';

class EmployeeDashboardScreen extends StatefulWidget {
  const EmployeeDashboardScreen({super.key});

  @override
  State<EmployeeDashboardScreen> createState() => _EmployeeDashboardScreenState();
}

class _EmployeeDashboardScreenState extends State<EmployeeDashboardScreen> {
  final GlobalKey<MapTabState> _mapTabKey = GlobalKey<MapTabState>();

  int _selectedIndex = 0;
  bool _isOnline = false;
  bool _updatingOnlineStatus = false;

  User? get _user => FirebaseAuth.instance.currentUser;

  String _themeModeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  void _showSnack(
    String message, {
    bool isError = false,
  }) {
    if (!mounted) return;

    final scheme = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
          backgroundColor: isError ? scheme.error : null,
        ),
      );
  }

  Future<void> _onToggleOnline() async {
    final user = _user;
    if (user == null || _updatingOnlineStatus) return;

    final nextValue = !_isOnline;

    setState(() {
      _isOnline = nextValue;
      _updatingOnlineStatus = true;
    });

    try {
      await RequestService.setProviderOnline(nextValue);

      if (!mounted) return;
      _showSnack(nextValue ? '🟢 You are ONLINE' : '🔴 You are OFFLINE');
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isOnline = !nextValue;
      });

      _showSnack('Failed to update online status: $e', isError: true);
    } finally {
      if (mounted) {
        setState(() {
          _updatingOnlineStatus = false;
        });
      }
    }
  }

  void _goToTab(int index) {
    if (!mounted) return;
    setState(() => _selectedIndex = index);
  }

  void _onRecenterMap() {
    _goToTab(1);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _mapTabKey.currentState?.centerToEmployee();
    });
  }

  void _openMapWithRoute() {
    _goToTab(1);
  }

  void _openProfile() {
    final appState = AppStateScope.read(context);

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SettingsScreen(
          isEmployee: true,
          currentTheme: _themeModeToString(appState.themeMode),
          currentLanguage: appState.locale.languageCode,
          onLanguageChanged: (locale) async {
            await appState.setLocale(locale);
          },
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required int index,
    Color? color,
  }) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: TextStyle(color: color),
      ),
      selected: _selectedIndex == index,
      onTap: () {
        Navigator.pop(context);
        _goToTab(index);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    final scheme = Theme.of(context).colorScheme;

    if (user == null) {
      return const Scaffold(
        body: Center(
          child: Text('Please sign in'),
        ),
      );
    }

    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.providerJobsStream(user.uid),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            !snapshot.hasData) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Something went wrong:\n${snapshot.error}',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: scheme.error,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          );
        }

        final jobs = snapshot.data ?? const <ServiceRequestModel>[];

        final int activeJobs = jobs.where((j) => j.isActive).length;
        final int completedJobs = jobs.where((j) => j.isCompleted).length;
        final double earnings = jobs
            .where((j) => j.isCompleted || j.isOngoing || j.isAccepted)
            .fold<double>(0.0, (sum, item) => sum + item.fare);

        final appState = AppStateScope.of(context);

        final pages = <Widget>[
          DashboardHomeTab(
            onRecenterMap: _onRecenterMap,
            onProfile: _openProfile,
            onToggleOnline: _onToggleOnline,
            activeJobs: activeJobs,
            completedJobs: completedJobs,
            earnings: earnings,
            isOnline: _isOnline,
          ),
          MapTab(
            key: _mapTabKey,
            requestId: null,
            providerId: user.uid,
            trackLiveDriver: true,
            listenToAssignedRequest: false,
          ),
          EmployeeRequestsTab(
            mapTabKey: _mapTabKey,
            onOpenMapTab: _openMapWithRoute,
          ),
          const ActiveJobTab(),
          SettingsScreen(
            isEmployee: true,
            currentTheme: _themeModeToString(appState.themeMode),
            currentLanguage: appState.locale.languageCode,
            onLanguageChanged: (locale) async {
              await appState.setLocale(locale);
            },
          ),
        ];

        final int safeIndex = _selectedIndex.clamp(0, pages.length - 1);

        return Scaffold(
          appBar: AppBar(
            title: const Text('🚗 FixMe Driver'),
            actions: [
              IconButton(
                tooltip: _isOnline ? 'Go offline' : 'Go online',
                onPressed: _updatingOnlineStatus ? null : _onToggleOnline,
                icon: _updatingOnlineStatus
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(
                        _isOnline ? Icons.toggle_on : Icons.toggle_off,
                        size: 32,
                        color: _isOnline ? Colors.green : null,
                      ),
              ),
              IconButton(
                tooltip: 'Settings',
                onPressed: _openProfile,
                icon: const Icon(Icons.settings_outlined),
              ),
            ],
          ),
          drawer: Drawer(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                UserAccountsDrawerHeader(
                  decoration: BoxDecoration(
                    color: scheme.primary,
                  ),
                  accountName: Text(user.displayName ?? 'No Name'),
                  accountEmail: Text(user.email ?? ''),
                  currentAccountPicture: CircleAvatar(
                    backgroundColor: scheme.onPrimary,
                    child: Text(
                      (user.displayName?.isNotEmpty == true
                              ? user.displayName![0]
                              : 'E')
                          .toUpperCase(),
                      style: TextStyle(
                        color: scheme.primary,
                        fontWeight: FontWeight.bold,
                        fontSize: 22,
                      ),
                    ),
                  ),
                ),
                _buildDrawerItem(
                  icon: Icons.dashboard_outlined,
                  title: 'Dashboard',
                  index: 0,
                ),
                _buildDrawerItem(
                  icon: Icons.map_outlined,
                  title: 'Map',
                  index: 1,
                ),
                _buildDrawerItem(
                  icon: Icons.receipt_long_outlined,
                  title: 'Requests',
                  index: 2,
                ),
                _buildDrawerItem(
                  icon: Icons.work_outline,
                  title: 'Active Job',
                  index: 3,
                ),
                const Divider(),
                _buildDrawerItem(
                  icon: Icons.settings_outlined,
                  title: 'Settings',
                  index: 4,
                ),
                ListTile(
                  leading: Icon(Icons.logout, color: scheme.error),
                  title: Text(
                    'Logout',
                    style: TextStyle(color: scheme.error),
                  ),
                  onTap: () async {
                    Navigator.pop(context);
                    await SessionUtils.logout(context);
                  },
                ),
              ],
            ),
          ),
          body: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: KeyedSubtree(
              key: ValueKey<int>(safeIndex),
              child: pages[safeIndex],
            ),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: safeIndex,
            onDestinationSelected: _goToTab,
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'Home',
              ),
              NavigationDestination(
                icon: Icon(Icons.map_outlined),
                selectedIcon: Icon(Icons.map),
                label: 'Map',
              ),
              NavigationDestination(
                icon: Icon(Icons.list_alt_outlined),
                selectedIcon: Icon(Icons.list_alt),
                label: 'Requests',
              ),
              NavigationDestination(
                icon: Icon(Icons.work_outline),
                selectedIcon: Icon(Icons.work),
                label: 'Job',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings),
                label: 'Settings',
              ),
            ],
          ),
        );
      },
    );
  }
}