import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

Future<void> showRatingDialog({
  required BuildContext context,
  required String requestId,
  required String providerId,
  required String providerName,
}) async {
  double rating = 5;
  final reviewController = TextEditingController();

  await showDialog(
    context: context,
    builder: (_) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text('Rate $providerName'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'How was the service?',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    final star = index + 1;
                    return IconButton(
                      onPressed: () => setState(() => rating = star.toDouble()),
                      icon: Icon(
                        star <= rating ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                      ),
                    );
                  }),
                ),
                TextField(
                  controller: reviewController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Write a review',
                    hintText: 'Optional feedback',
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Later'),
              ),
              FilledButton(
                onPressed: () async {
                  final customerId = FirebaseAuth.instance.currentUser?.uid;
                  if (customerId == null) return;

                  await FirebaseFirestore.instance.collection('ratings').add({
                    'providerId': providerId,
                    'providerName': providerName,
                    'customerId': customerId,
                    'requestId': requestId,
                    'rating': rating,
                    'review': reviewController.text.trim(),
                    'createdAt': FieldValue.serverTimestamp(),
                  });

                  final providerRef =
                      FirebaseFirestore.instance.collection('users').doc(providerId);

                  await FirebaseFirestore.instance.runTransaction((tx) async {
                    final snap = await tx.get(providerRef);
                    final oldRating =
                        ((snap.data()?['rating'] ?? 0) as num).toDouble();
                    final oldCount =
                        ((snap.data()?['ratingCount'] ?? 0) as num).toInt();

                    final newCount = oldCount + 1;
                    final newRating = ((oldRating * oldCount) + rating) / newCount;

                    tx.set(providerRef, {
                      'rating': newRating,
                      'ratingCount': newCount,
                    }, SetOptions(merge: true));
                  });

                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        const SnackBar(
                          content: Text('Thanks for your rating'),
                          behavior: SnackBarBehavior.floating,
                        ),
                      );
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          );
        },
      );
    },
  );
}