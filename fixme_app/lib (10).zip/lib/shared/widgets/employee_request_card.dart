import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

const Color kBrand = Color(0xFF01411C);

class EmployeeRequestCard extends StatefulWidget {
  final String requestId;
  final String title;
  final String subtitle;
  final double price;

  final VoidCallback? onRoute;
  final VoidCallback? onChat;

  const EmployeeRequestCard({
    super.key,
    required this.requestId,
    required this.title,
    required this.subtitle,
    required this.price,
    this.onRoute,
    this.onChat,
  });

  @override
  State<EmployeeRequestCard> createState() => _EmployeeRequestCardState();
}

class _EmployeeRequestCardState extends State<EmployeeRequestCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  late final Animation<double> _pulseAnimation;

  bool _sendingOffer = false;

  String get _userId => FirebaseAuth.instance.currentUser?.uid ?? '';

  DocumentReference<Map<String, dynamic>> get _requestRef =>
      FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(widget.requestId);

  DocumentReference<Map<String, dynamic>> get _offerDocRef =>
      _requestRef.collection('offers').doc(_userId);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.06,
    ).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _showSnack(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  Future<void> _sendOffer(double offerPrice) async {
    if (_userId.isEmpty) {
      _showSnack('You must be logged in first.');
      return;
    }

    setState(() => _sendingOffer = true);

    try {
      final user = FirebaseAuth.instance.currentUser;

      await _offerDocRef.set({
        'employeeId': _userId,
        'employeeName': user?.displayName?.trim().isNotEmpty == true
            ? user!.displayName!.trim()
            : 'Worker',
        'price': offerPrice,
        'counterPrice': null,
        'lastUpdatedBy': 'employee',
        'updatedAt': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      await _requestRef.set({
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      _showSnack('Offer sent successfully.');
    } catch (e) {
      _showSnack('Failed to send offer: $e');
    } finally {
      if (mounted) {
        setState(() => _sendingOffer = false);
      }
    }
  }

  Future<void> _respondToCounter(double price) async {
    if (_userId.isEmpty) return;

    setState(() => _sendingOffer = true);

    try {
      await _offerDocRef.set({
        'employeeId': _userId,
        'price': price,
        'counterPrice': price,
        'lastUpdatedBy': 'employee',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      await _requestRef.set({
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      _showSnack('Counter offer accepted and updated.');
    } catch (e) {
      _showSnack('Failed to update offer: $e');
    } finally {
      if (mounted) {
        setState(() => _sendingOffer = false);
      }
    }
  }

  Future<void> _showOfferDialog() async {
    final controller = TextEditingController(
      text: widget.price.toStringAsFixed(2),
    );

    final result = await showDialog<double>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Send Offer'),
          content: TextField(
            controller: controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Offer Price (OMR)',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                final value = double.tryParse(controller.text.trim());
                Navigator.of(context).pop(value);
              },
              child: const Text('Send'),
            ),
          ],
        );
      },
    );

    if (result == null) return;
    if (result <= 0) {
      _showSnack('Please enter a valid price.');
      return;
    }

    await _sendOffer(result);
  }

  @override
  Widget build(BuildContext context) {
    if (_userId.isEmpty) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withOpacity(0.18),
                  Colors.white.withOpacity(0.08),
                ],
              ),
              border: Border.all(
                color: Colors.white.withOpacity(0.18),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.10),
                  blurRadius: 24,
                  offset: const Offset(0, 12),
                ),
                BoxShadow(
                  color: kBrand.withOpacity(0.10),
                  blurRadius: 28,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                stream: _offerDocRef.snapshots(),
                builder: (context, offerSnap) {
                  final hasOffer = offerSnap.data?.exists ?? false;
                  final offerData = offerSnap.data?.data() ?? <String, dynamic>{};

                  final myOffer = (offerData['price'] as num?)?.toDouble();
                  final counter = (offerData['counterPrice'] as num?)?.toDouble();
                  final updatedBy = offerData['lastUpdatedBy']?.toString();

                  return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                    stream: _requestRef.snapshots(),
                    builder: (context, requestSnap) {
                      final requestData =
                          requestSnap.data?.data() ?? <String, dynamic>{};

                      final employeeId =
                          (requestData['employeeId'] ?? '').toString().trim();
                      final status =
                          (requestData['status'] ?? '').toString().trim().toLowerCase();

                      final isAssignedToMe =
                          employeeId.isNotEmpty && employeeId == _userId;
                      final isAssignedToOther =
                          employeeId.isNotEmpty && employeeId != _userId;
                      final isClosed =
                          status == 'completed' || status == 'cancelled';

                      final canSendOffer =
                          !isClosed && !isAssignedToMe && !isAssignedToOther;

                      final canRespondToCounter =
                          canSendOffer &&
                          counter != null &&
                          updatedBy == 'customer';

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              ScaleTransition(
                                scale: _pulseAnimation,
                                child: Container(
                                  width: 52,
                                  height: 52,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: LinearGradient(
                                      colors: [
                                        kBrand,
                                        kBrand.withOpacity(0.75),
                                      ],
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: kBrand.withOpacity(0.35),
                                        blurRadius: 18,
                                        offset: const Offset(0, 8),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.handyman_rounded,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.titleMedium?.copyWith(
                                        fontWeight: FontWeight.w800,
                                        height: 1.15,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      widget.subtitle,
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.bodyMedium?.copyWith(
                                        color: scheme.onSurfaceVariant,
                                        height: 1.25,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              gradient: LinearGradient(
                                colors: [
                                  kBrand.withOpacity(0.14),
                                  scheme.primary.withOpacity(0.08),
                                ],
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.attach_money_rounded,
                                  size: 20,
                                  color: kBrand,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'OMR ${widget.price.toStringAsFixed(2)}',
                                  style: theme.textTheme.titleSmall?.copyWith(
                                    fontWeight: FontWeight.w800,
                                    color: kBrand,
                                  ),
                                ),
                                const Spacer(),
                                if (isAssignedToMe)
                                  _StatusChip(
                                    label: 'Accepted',
                                    color: Colors.green,
                                  )
                                else if (isAssignedToOther)
                                  _StatusChip(
                                    label: 'Taken',
                                    color: Colors.redAccent,
                                  )
                                else if (hasOffer)
                                  _StatusChip(
                                    label: 'Offer sent',
                                    color: Colors.green,
                                  ),
                              ],
                            ),
                          ),
                          if (hasOffer) ...[
                            const SizedBox(height: 14),
                            _GlassInfoTile(
                              icon: Icons.local_offer_outlined,
                              title: 'Your Offer',
                              value: myOffer == null
                                  ? '-'
                                  : 'OMR ${myOffer.toStringAsFixed(2)}',
                              valueColor: Colors.green.shade700,
                            ),
                          ],
                          if (counter != null) ...[
                            const SizedBox(height: 10),
                            _GlassInfoTile(
                              icon: Icons.swap_horiz_rounded,
                              title: updatedBy == 'customer'
                                  ? 'Customer Counter'
                                  : 'Updated Offer',
                              value: 'OMR ${counter.toStringAsFixed(2)}',
                              valueColor: Colors.orange.shade800,
                            ),
                          ],
                          const SizedBox(height: 18),
                        // ✅ REPLACE YOUR ACTION BUTTONS WITH THIS

Wrap(
  spacing: 10,
  runSpacing: 10,
  children: [

    /// TRACK (only if assigned to me)
    if (isAssignedToMe && widget.onRoute != null)
      _PremiumButton(
        label: 'Track',
        icon: Icons.my_location,
        onPressed: widget.onRoute,
        variant: _PremiumButtonVariant.outline,
      ),

    /// CHAT (only if assigned to me)
    if (isAssignedToMe && widget.onChat != null)
      _PremiumButton(
        label: 'Chat',
        icon: Icons.chat_bubble_outline,
        onPressed: widget.onChat,
        variant: _PremiumButtonVariant.tonal,
      ),

    /// SEND OFFER
    if (canSendOffer)
      _PremiumButton(
        label: _sendingOffer ? 'Sending...' : 'Offer',
        icon: _sendingOffer
            ? Icons.hourglass_top_rounded
            : Icons.local_offer_outlined,
        onPressed: _sendingOffer ? null : _showOfferDialog,
        variant: _PremiumButtonVariant.filled,
      ),

    /// ACCEPT COUNTER
    if (canRespondToCounter)
      _PremiumButton(
        label: _sendingOffer ? 'Updating...' : 'Accept Counter',
        icon: Icons.done_all_rounded,
        onPressed: _sendingOffer
            ? null
            : () => _respondToCounter(counter!),
        variant: _PremiumButtonVariant.tonal,
      ),

    /// WITHDRAW OFFER (NEW ✅)
    if (!isAssignedToMe && hasOffer)
      _PremiumButton(
        label: 'Withdraw',
        icon: Icons.close,
        onPressed: () async {
          await _offerDocRef.delete();
          _showSnack('Offer withdrawn');
        },
        variant: _PremiumButtonVariant.outline,
      ),

    /// REJECT JOB (NEW ✅)
    if (isAssignedToMe)
      _PremiumButton(
        label: 'Reject Job',
        icon: Icons.cancel,
        onPressed: () async {
          await _requestRef.update({
            'employeeId': '',
            'status': 'open',
            'updatedAt': FieldValue.serverTimestamp(),
          });
          _showSnack('Job rejected');
        },
        variant: _PremiumButtonVariant.outline,
      ),
  ],
),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GlassInfoTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final Color valueColor;

  const _GlassInfoTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.14)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: theme.colorScheme.onSurfaceVariant),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w800,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String label;
  final Color color;

  const _StatusChip({
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(
              color: color.withOpacity(0.9),
              fontWeight: FontWeight.w700,
            ),
      ),
    );
  }
}

enum _PremiumButtonVariant { filled, tonal, outline }

class _PremiumButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final _PremiumButtonVariant variant;

  const _PremiumButton({
    required this.label,
    required this.icon,
    required this.onPressed,
    required this.variant,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    switch (variant) {
      case _PremiumButtonVariant.filled:
        return FilledButton.icon(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: kBrand,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          icon: Icon(icon, size: 18),
          label: Text(label),
        );

      case _PremiumButtonVariant.tonal:
        return FilledButton.tonalIcon(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          icon: Icon(icon, size: 18),
          label: Text(label),
        );

      case _PremiumButtonVariant.outline:
        return OutlinedButton.icon(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            side: BorderSide(color: scheme.outlineVariant),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          icon: Icon(icon, size: 18),
          label: Text(label),
        );
    }
  }
}