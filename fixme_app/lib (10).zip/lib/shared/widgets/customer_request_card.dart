import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

const Color kBrand = Color(0xFF01411C);

class CustomerRequestCard extends StatefulWidget {
  final String requestId;
  final String title;
  final String subtitle;
  final double price;

  final VoidCallback? onRoute;
  final VoidCallback? onChat;

  const CustomerRequestCard({
    super.key,
    required this.requestId,
    required this.title,
    required this.subtitle,
    required this.price,
    this.onRoute,
    this.onChat,
  });

  @override
  State<CustomerRequestCard> createState() => _CustomerRequestCardState();
}

class _CustomerRequestCardState extends State<CustomerRequestCard> {
  String get _userId => FirebaseAuth.instance.currentUser?.uid ?? '';

  DocumentReference<Map<String, dynamic>> get _requestRef =>
      FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(widget.requestId);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _requestRef.snapshots(),
      builder: (context, requestSnap) {
        final requestData =
            requestSnap.data?.data() ?? <String, dynamic>{};

        final employeeId =
            (requestData['employeeId'] ?? '').toString().trim();

        final status =
            (requestData['status'] ?? '').toString().toLowerCase();

        final isAssigned = employeeId.isNotEmpty;
        final isCompleted = status == 'completed';
        final isCancelled = status == 'cancelled';

        return Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.18),
                      Colors.white.withOpacity(0.08),
                    ],
                  ),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.18),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.10),
                      blurRadius: 24,
                      offset: const Offset(0, 12),
                    ),
                    BoxShadow(
                      color: kBrand.withOpacity(0.10),
                      blurRadius: 28,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      /// HEADER
                      Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [kBrand, kBrand.withOpacity(0.7)],
                              ),
                            ),
                            child: const Icon(
                              Icons.home_repair_service,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 14),

                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.title,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  widget.subtitle,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: scheme.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      /// PRICE + STATUS
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          gradient: LinearGradient(
                            colors: [
                              kBrand.withOpacity(0.14),
                              scheme.primary.withOpacity(0.08),
                            ],
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.attach_money_rounded, size: 20),
                            const SizedBox(width: 6),
                            Text(
                              'OMR ${widget.price.toStringAsFixed(2)}',
                              style: theme.textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.w800,
                                color: kBrand,
                              ),
                            ),
                            const Spacer(),

                            if (isCompleted)
                              _StatusChip(label: 'Completed', color: Colors.green)
                            else if (isCancelled)
                              _StatusChip(label: 'Cancelled', color: Colors.red)
                            else if (isAssigned)
                              _StatusChip(label: 'Assigned', color: Colors.blue)
                            else
                              _StatusChip(label: 'Waiting', color: Colors.orange),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      /// OFFERS LIST
                      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                        stream: _requestRef.collection('offers').snapshots(),
                        builder: (context, offerSnap) {
                          final offers = offerSnap.data?.docs ?? [];

                          if (offers.isEmpty) {
                            return Text(
                              'No offers yet',
                              style: theme.textTheme.bodyMedium,
                            );
                          }

                          return Column(
                            children: offers.map((doc) {
                              final data = doc.data();
                              final price =
                                  (data['price'] as num?)?.toDouble() ?? 0.0;
                              final worker =
                                  data['employeeName'] ?? 'Worker';
                              final workerId = data['employeeId'];

                              return Container(
                                margin: const EdgeInsets.only(bottom: 10),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        '$worker - OMR ${price.toStringAsFixed(2)}',
                                        style: theme.textTheme.bodyMedium,
                                      ),
                                    ),

                                    /// ACCEPT BUTTON
                                    if (!isAssigned)
                                      FilledButton(
                                        onPressed: () async {
                                          await _requestRef.update({
                                            'employeeId': workerId,
                                            'status': 'accepted',
                                            'updatedAt':
                                                FieldValue.serverTimestamp(),
                                          });
                                        },
                                        child: const Text('Accept'),
                                      ),
                                  ],
                                ),
                              );
                            }).toList(),
                          );
                        },
                      ),

                      const SizedBox(height: 16),

                      /// ACTION BUTTONS
// ✅ FINAL FIXED CUSTOMER REQUEST CARD

// ONLY CHANGE THIS PART (ACTION BUTTONS SECTION)

/// ACTION BUTTONS
Wrap(
  spacing: 10,
  children: [

    /// TRACK (only when assigned)
    if (isAssigned && widget.onRoute != null)
      _PremiumButton(
        label: 'Track',
        icon: Icons.my_location,
        onPressed: widget.onRoute,
        variant: _PremiumButtonVariant.outline,
      ),

    /// CHAT (only when assigned)
    if (isAssigned && widget.onChat != null)
      _PremiumButton(
        label: 'Chat',
        icon: Icons.chat_bubble_outline,
        onPressed: widget.onChat,
        variant: _PremiumButtonVariant.tonal,
      ),

    /// CANCEL REQUEST (NEW ✅)
    if (!isCompleted && !isCancelled)
      _PremiumButton(
        label: 'Cancel',
        icon: Icons.close,
        onPressed: () async {
          await _requestRef.update({
            'status': 'cancelled',
            'updatedAt': FieldValue.serverTimestamp(),
          });
        },
        variant: _PremiumButtonVariant.outline,
      ),
  ],
),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// STATUS CHIP
class _StatusChip extends StatelessWidget {
  final String label;
  final Color color;

  const _StatusChip({
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

/// BUTTON SYSTEM (same as employee)
enum _PremiumButtonVariant { filled, tonal, outline }

class _PremiumButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final _PremiumButtonVariant variant;

  const _PremiumButton({
    required this.label,
    required this.icon,
    required this.onPressed,
    required this.variant,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    switch (variant) {
      case _PremiumButtonVariant.filled:
        return FilledButton.icon(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: kBrand,
            foregroundColor: Colors.white,
          ),
          icon: Icon(icon),
          label: Text(label),
        );

      case _PremiumButtonVariant.tonal:
        return FilledButton.tonalIcon(
          onPressed: onPressed,
          icon: Icon(icon),
          label: Text(label),
        );

      case _PremiumButtonVariant.outline:
        return OutlinedButton.icon(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            side: BorderSide(color: scheme.outlineVariant),
          ),
          icon: Icon(icon),
          label: Text(label),
        );
    }
  }
}