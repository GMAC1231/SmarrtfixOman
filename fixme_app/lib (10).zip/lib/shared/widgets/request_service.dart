import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/service_request.dart';

class RequestService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> get _requests =>
      _db.collection('serviceRequests');

  static String? get _uid => FirebaseAuth.instance.currentUser?.uid;

  static Stream<List<ServiceRequestModel>> customerRequestsStream(
    String customerId,
  ) {
    return _requests
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(_mapRequests);
  }

  static Stream<List<ServiceRequestModel>> providerJobsStream(
    String providerId,
  ) {
    return _requests
        .where('employeeId', isEqualTo: providerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(_mapRequests);
  }

  static Stream<List<ServiceRequestModel>> openRequestsStream() {
    return _requests
        .where(
          'status',
          whereIn: const [
            ServiceRequestModel.statusPending,
            ServiceRequestModel.statusAccepted,
            ServiceRequestModel.statusOngoing,
          ],
        )
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(_mapRequests);
  }

  static List<ServiceRequestModel> _mapRequests(
    QuerySnapshot<Map<String, dynamic>> snap,
  ) {
    return snap.docs.map(ServiceRequestModel.fromDoc).toList();
  }

  static Future<void> createRequest({
    required String serviceType,
    required double fare,
    required double lat,
    required double lng,
    String? note,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      throw Exception('User not logged in');
    }

    await _requests.add({
      'serviceType': serviceType.trim(),
      'fare': fare,
      'status': ServiceRequestModel.statusPending,
      'customerLat': lat,
      'customerLng': lng,
      'customerId': user.uid,
      'customerName': (user.displayName ?? '').trim(),
      'employeeId': '',
      'workerName': '',
      'note': (note ?? '').trim(),
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> cancelRequest(String requestId) async {
    await _requests.doc(requestId).update({
      'status': ServiceRequestModel.statusCancelled,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> assignProvider({
    required String requestId,
    required String providerId,
    required String providerName,
  }) async {
    await _requests.doc(requestId).update({
      'employeeId': providerId,
      'workerName': providerName.trim(),
      'status': ServiceRequestModel.statusAccepted,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> startJob(String requestId) async {
    await _requests.doc(requestId).update({
      'status': ServiceRequestModel.statusOngoing,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> completeJob(String requestId) async {
    await _requests.doc(requestId).update({
      'status': ServiceRequestModel.statusCompleted,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> updateProviderLocation({
    required double lat,
    required double lng,
  }) async {
    final uid = _uid;
    if (uid == null) return;

    await _db.collection('users').doc(uid).set({
      'lat': lat,
      'lng': lng,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static Future<void> setProviderOnline(bool isOnline) async {
    final uid = _uid;
    if (uid == null) return;

    await _db.collection('users').doc(uid).set({
      'isOnline': isOnline,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}