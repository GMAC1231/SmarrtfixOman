import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'map_screen.dart';
import 'shared/models/service_request.dart';
import 'shared/services/request_service.dart';
import 'shared/services/chat_service.dart';

class ActiveJobTab extends StatelessWidget {
  const ActiveJobTab({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Center(child: Text('Please sign in'));
    }

    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.providerJobsStream(user.uid),
      builder: (context, snapshot) {

        /// LOADING
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        /// ERROR
        if (snapshot.hasError) {
          return Center(
            child: Text(
              'Something went wrong',
              style: TextStyle(color: Colors.red.shade300),
            ),
          );
        }

        final jobs = snapshot.data ?? [];

        /// NO JOBS
        if (jobs.isEmpty) {
          return const _EmptyState(
            icon: Icons.work_outline,
            title: "No jobs yet",
            subtitle: "You’ll see your jobs here",
          );
        }

        /// FIND ACTIVE JOB
        ServiceRequestModel? job;
        for (final j in jobs) {
          if (j.status == 'accepted' || j.status == 'ongoing') {
            job = j;
            break;
          }
        }

        /// NO ACTIVE JOB
        if (job == null) {
          return const _EmptyState(
            icon: Icons.access_time,
            title: "Waiting for job",
            subtitle: "Accept a request to start working",
          );
        }

        return _ActiveJobCard(
          job: job,
          userId: user.uid,
        );
      },
    );
  }
}

///////////////////////////////////////////////////////////////
/// ACTIVE JOB CARD
///////////////////////////////////////////////////////////////

class _ActiveJobCard extends StatelessWidget {
  final ServiceRequestModel job;
  final String userId;

  const _ActiveJobCard({
    required this.job,
    required this.userId,
  });

  @override
  Widget build(BuildContext context) {
    final lat = job.customerLat;
    final lng = job.customerLng;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            colors: [
              const Color(0xFF01411C),
              Colors.green.shade600,
            ],
          ),
          boxShadow: [
            BoxShadow(
              blurRadius: 20,
              color: Colors.black.withOpacity(0.25),
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            /// HEADER
            Row(
              children: [
                Expanded(
                  child: Text(
                    job.serviceType,
                    style: const TextStyle(
                      fontSize: 22,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                _StatusChip(status: job.status),
              ],
            ),

            const SizedBox(height: 12),

            Text('Customer: ${job.customerName}',
                style: const TextStyle(color: Colors.white70)),

            Text(
              'Fare: OMR ${job.fare.toStringAsFixed(2)}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            /// BUTTONS
            Wrap(
              spacing: 10,
              children: [

                /// 🚀 ROUTE BUTTON (FIXED)
                ElevatedButton.icon(
                  onPressed: () {
                    if (lat == null || lng == null) return;

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MapScreen(
                          requestId: job.id,
                          providerId: userId,
                          customerLat: lat,
                          customerLng: lng,
                          trackLiveDriver: true,
                          listenToAssignedRequest: true,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.route),
                  label: const Text("Route"),
                ),

                /// 💬 CHAT
                ElevatedButton.icon(
                  onPressed: () async {
                    final chatId = await ChatService.ensureChat(
                      customerId: job.customerId,
                      employeeId: userId,
                      requestId: job.id,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChatScreen(
                          chatId: chatId,
                          otherUserId: job.customerId,
                          title: job.customerName,
                          requestId: job.id,
                          iAmCustomer: false,
                          providerId: userId,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.chat),
                  label: const Text("Chat"),
                ),
              ],
            ),

            const SizedBox(height: 20),

            /// ACTION BUTTONS
            if (job.status == 'accepted')
              _PrimaryButton(
                text: "Start Job",
                onTap: () =>
                    RequestService.updateStatus(job.id, 'ongoing'),
              ),

            if (job.status == 'ongoing')
              _PrimaryButton(
                text: "Complete Job",
                onTap: () =>
                    RequestService.updateStatus(job.id, 'completed'),
              ),
          ],
        ),
      ),
    );
  }
}

///////////////////////////////////////////////////////////////
/// STATUS CHIP
///////////////////////////////////////////////////////////////

class _StatusChip extends StatelessWidget {
  final String status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;

    switch (status) {
      case 'accepted':
        color = Colors.orange;
        break;
      case 'ongoing':
        color = Colors.green;
        break;
      case 'completed':
        color = Colors.blue;
        break;
      default:
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.toUpperCase(),
        style: const TextStyle(color: Colors.white),
      ),
    );
  }
}

///////////////////////////////////////////////////////////////
/// BUTTON
///////////////////////////////////////////////////////////////

class _PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const _PrimaryButton({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        child: Text(text),
      ),
    );
  }
}

///////////////////////////////////////////////////////////////
/// EMPTY STATE
///////////////////////////////////////////////////////////////

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 70, color: Colors.grey),
          const SizedBox(height: 12),
          Text(title,
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold)),
          Text(subtitle, style: const TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}