import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_service.dart';
import 'shared/services/request_service.dart';
import 'shared/widgets/customer_request_card.dart';

class CustomerRequestsTab extends StatelessWidget {
  final GlobalKey<MapTabState> mapTabKey;
  final VoidCallback? onOpenMapTab;

  const CustomerRequestsTab({
    super.key,
    required this.mapTabKey,
    this.onOpenMapTab,
  });

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Center(child: Text("Not logged in"));
    }

    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.customerRequestsStream(user.uid),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text("Error loading requests"));
        }

        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final requests = snapshot.data!;

        return ListView.builder(
          itemCount: requests.length,
          itemBuilder: (context, index) {
            final req = requests[index];

            return CustomerRequestCard(
              requestId: req.id,
              title: req.serviceType.isEmpty
                  ? "Service Request"
                  : req.serviceType,
              subtitle: req.workerName.isNotEmpty
                  ? req.workerName
                  : "Waiting for provider",
              price: req.fare,
              assignedEmployeeId: req.employeeId,

              /// MAP
              onTrack: req.employeeId.isEmpty
                  ? null
                  : () async {
                      final lat = req.customerLat;
                      final lng = req.customerLng;

                      if (lat == null || lng == null) return;

                      await mapTabKey.currentState
                          ?.setCustomerLocation(LatLng(lat, lng));

                      onOpenMapTab?.call();
                    },

              /// CHAT
              onChat: req.employeeId.isEmpty
                  ? null
                  : () async {
                      final chatId = await ChatService.ensureChat(
                        customerId: user.uid,
                        employeeId: req.employeeId,
                        requestId: req.id,
                      );

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChatScreen(
                            chatId: chatId,
                            otherUserId: req.employeeId,
                            title: req.workerName,
                            requestId: req.id,
                            iAmCustomer: true,
                            providerId: req.employeeId,
                          ),
                        ),
                      );
                    },
            );
          },
        );
      },
    );
  }
}