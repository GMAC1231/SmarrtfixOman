import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_service.dart';
import 'shared/services/request_service.dart';
import 'shared/widgets/employee_request_card.dart';

class EmployeeRequestsTab extends StatelessWidget {
  final GlobalKey<MapTabState> mapTabKey;
  final VoidCallback? onOpenMapTab;

  const EmployeeRequestsTab({
    super.key,
    required this.mapTabKey,
    this.onOpenMapTab,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.openRequestsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _ErrorState(
            message: 'Failed to load requests.\n${snapshot.error}',
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        final requests = snapshot.data ?? const <ServiceRequestModel>[];

        if (requests.isEmpty) {
          return const _EmptyState();
        }

        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 14),
          itemBuilder: (context, index) {
            final req = requests[index];

            return EmployeeRequestCard(
              requestId: req.id,
              title: _safeTitle(req),
              subtitle: _safeSubtitle(req),
              price: req.fare,
              onRoute: () => _handleRoute(context, req),
              onChat: req.customerId.trim().isEmpty
                  ? null
                  : () => _openChat(
                        context: context,
                        customerId: req.customerId,
                        requestId: req.id,
                        title: req.customerName.trim().isEmpty
                            ? 'Customer'
                            : req.customerName.trim(),
                      ),
            );
          },
        );
      },
    );
  }

  static String _safeTitle(ServiceRequestModel req) {
    final service = req.serviceType.trim();
    return service.isEmpty ? 'Service Request' : service;
  }

  static String _safeSubtitle(ServiceRequestModel req) {
    final customer = req.customerName.trim();
    return customer.isEmpty ? 'Customer' : customer;
  }

  Future<void> _handleRoute(
    BuildContext context,
    ServiceRequestModel req,
  ) async {
    final point = _extractPoint(req);

    if (point == null) {
      _showSnack(context, 'Customer location not available');
      return;
    }

    final mapState = mapTabKey.currentState;
    if (mapState == null) {
      _showSnack(context, 'Map not ready');
      return;
    }

    try {
      await mapState.setCustomerLocation(point);
      onOpenMapTab?.call();
    } catch (e) {
      _showSnack(context, 'Route failed: $e');
    }
  }

  static LatLng? _extractPoint(ServiceRequestModel req) {
    final lat = req.customerLat;
    final lng = req.customerLng;

    if (lat == null || lng == null) return null;
    return LatLng(lat, lng);
  }

  static Future<void> _openChat({
    required BuildContext context,
    required String customerId,
    required String requestId,
    required String title,
  }) async {
    final employeeId = FirebaseAuth.instance.currentUser?.uid;
    if (employeeId == null) {
      _showSnack(context, 'Login required');
      return;
    }

    try {
      final chatId = await ChatService.ensureChat(
        customerId: customerId,
        employeeId: employeeId,
        requestId: requestId,
      );

      if (!context.mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChatScreen(
            chatId: chatId,
            otherUserId: customerId,
            title: title,
            requestId: requestId,
            iAmCustomer: false,
            providerId: employeeId,
          ),
        ),
      );
    } catch (e) {
      _showSnack(context, 'Chat failed: $e');
    }
  }

  static void _showSnack(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(message)),
      );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('No open requests'),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;

  const _ErrorState({
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(message),
    );
  }
}