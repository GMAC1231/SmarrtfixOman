import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_services.dart';
import 'shared/services/request_service.dart';

class EmployeeRequestsTab extends StatefulWidget {
  final GlobalKey<MapTabState> mapTabKey;

  const EmployeeRequestsTab({super.key, required this.mapTabKey});

  @override
  State<EmployeeRequestsTab> createState() => _EmployeeRequestsTabState();
}

class _EmployeeRequestsTabState extends State<EmployeeRequestsTab> {
  Future<void> _showOfferDialog(ServiceRequestModel req) async {
    final fareController = TextEditingController(
      text: req.displayFare?.toStringAsFixed(2) ?? '',
    );
    final noteController = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Send offer'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: fareController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Your fare', prefixText: 'OMR '),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Optional note'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final fare = double.tryParse(fareController.text.trim());
              if (fare == null || fare <= 0) return;
              Navigator.pop(dialogContext);
              await RequestService.sendOffer(
                requestId: req.id,
                fare: fare,
                note: noteController.text.trim(),
              );
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Offer sent successfully')),
              );
            },
            child: const Text('Send offer'),
          ),
        ],
      ),
    );
  }

  osm.GeoPoint? _extractPoint(ServiceRequestModel req) {
    if (req.customerLat == null || req.customerLng == null) return null;
    return osm.GeoPoint(latitude: req.customerLat!, longitude: req.customerLng!);
  }

  Future<void> _openChat(ServiceRequestModel req) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || req.customerId.isEmpty) return;
    final chatId = await ChatService.ensureChat(
      customerId: req.customerId,
      employeeId: uid,
      requestId: req.id,
    );
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          chatId: chatId,
          otherUserId: req.customerId,
          title: req.customerName,
          requestId: req.id,
          iAmCustomer: false,
          providerId: uid,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.openRequestsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final requests = snapshot.data!;
        if (requests.isEmpty) return const Center(child: Text('No open requests'));

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final req = requests[index];
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            req.serviceType,
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
                          ),
                        ),
                        Text('OMR ${(req.displayFare ?? 0).toStringAsFixed(2)}'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('Customer: ${req.customerName}'),
                    if (req.note.isNotEmpty) Text('Issue: ${req.note}'),
                    if (req.customerLat != null && req.customerLng != null)
                      Text('Location: ${req.customerLat!.toStringAsFixed(5)}, ${req.customerLng!.toStringAsFixed(5)}'),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () async {
                            final point = _extractPoint(req);
                            if (point != null) {
                              await widget.mapTabKey.currentState?.setCustomerLocation(point);
                            }
                          },
                          icon: const Icon(Icons.route_outlined),
                          label: const Text('Route'),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => _showOfferDialog(req),
                          icon: const Icon(Icons.local_offer_outlined),
                          label: const Text('Offer'),
                        ),
                        ElevatedButton(
  onPressed: () => onAcceptRequest(req.id),
  child: const Text("Accept"),
),
                        TextButton(
                          onPressed: () => RequestService.quickAcceptRequest(req.id),
                          child: const Text('Quick accept'),
                        ),
                        if (req.customerId.isNotEmpty)
                          TextButton.icon(
                            onPressed: () => _openChat(req),
                            icon: const Icon(Icons.chat_bubble_outline),
                            label: const Text('Chat'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
