/// Canonical Firestore collection/field names used across the app.
///
/// This file intentionally exposes both [FirestoreKeys] and [FSKeys]
/// so older files and newer files can compile against the same constants.
class FirestoreKeys {
  // Collections
  static const String users = 'users';
  static const String publicUsers = 'publicUsers';
  static const String requests = 'serviceRequests';
  static const String serviceRequests = 'serviceRequests';
  static const String offers = 'offers';
  static const String bids = 'offers';
  static const String chats = 'chats';
  static const String messages = 'messages';
  static const String liveLocations = 'liveLocations';
  static const String feedback = 'feedback';
  static const String ratings = 'ratings';

  // Common fields
  static const String id = 'id';
  static const String createdAt = 'createdAt';
  static const String updatedAt = 'updatedAt';

  // User fields
  static const String uid = 'uid';
  static const String userId = 'userId';
  static const String role = 'role';
  static const String email = 'email';
  static const String name = 'name';
  static const String fullName = 'fullName';
  static const String phone = 'phone';
  static const String city = 'city';
  static const String address = 'address';
  static const String gender = 'gender';
  static const String profession = 'profession';
  static const String fare = 'fare';
  static const String startingFare = 'startingFare';
  static const String car = 'car';
  static const String carPlate = 'carPlateNumber';
  static const String photoUrl = 'photoUrl';
  static const String profileComplete = 'profileComplete';
  static const String employeeApproved = 'employee_approved';

  // Location fields
  static const String lat = 'lat';
  static const String lng = 'lng';
  static const String location = 'location';
  static const String customerLocation = 'customerLocation';
  static const String lastUpdated = 'lastUpdated';
  static const String heading = 'heading';
  static const String speed = 'speed';
  static const String mode = 'mode';

  // Request fields
  static const String requestId = 'requestId';
  static const String customerId = 'customerId';
  static const String customerName = 'customerName';
  static const String customerEmail = 'customerEmail';
  static const String customerPhone = 'customerPhone';
  static const String serviceType = 'serviceType';
  static const String description = 'description';
  static const String note = 'note';
  static const String status = 'status';
  static const String priceOffer = 'priceOffer';
  static const String agreedFare = 'agreedFare';
  static const String acceptedFare = 'acceptedFare';
  static const String customerLat = 'customerLat';
  static const String customerLng = 'customerLng';
  static const String providerId = 'providerId';
  static const String providerName = 'providerName';
  static const String providerCar = 'providerCar';
  static const String providerRating = 'providerRating';
  static const String employeeId = 'employeeId';
  static const String employeeName = 'employeeName';
  static const String etaMinutes = 'etaMinutes';
  static const String bidStatus = 'bidStatus';
  static const String scheduledAt = 'scheduledAt';
}

/// Backward-compatible alias used by some older generated files.
class FSKeys extends FirestoreKeys {}
