import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'chat_screen.dart';
import 'session_utils.dart';
import 'settings_screen.dart';
import 'shared/constants/app_constants.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_services.dart';
import 'shared/services/location_tracking_service.dart';
import 'shared/services/request_service.dart';

class CustomerDashboardScreen extends StatefulWidget {
  const CustomerDashboardScreen({super.key});

  @override
  State<CustomerDashboardScreen> createState() => _CustomerDashboardScreenState();
}

class _CustomerDashboardScreenState extends State<CustomerDashboardScreen> {
  final LocationTrackingService _locationService = LocationTrackingService();
  int _currentIndex = 0;
  Position? _position;
  bool _loadingLocation = false;

  User? get _user => FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  @override
  void dispose() {
    _locationService.dispose();
    super.dispose();
  }

  Future<void> _loadLocation() async {
    if (mounted) setState(() => _loadingLocation = true);
    try {
      final pos = await _locationService.getCurrentPosition();
      if (mounted) setState(() => _position = pos);
    } finally {
      if (mounted) setState(() => _loadingLocation = false);
    }
  }

  Future<void> _createRequest({
    required String serviceType,
    required double fare,
    String? note,
  }) async {
    try {
      await RequestService.createRequest(
        serviceType: serviceType,
        fare: fare,
        lat: _position?.latitude,
        lng: _position?.longitude,
        note: note,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request created successfully')),
      );
      setState(() => _currentIndex = 1);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to create request: $e')),
      );
    }
  }

  Future<void> _openRequestDialog([String? preset]) async {
    final fareController = TextEditingController();
    final noteController = TextEditingController();
    String selected = preset ?? AppConstants.serviceTypes.first;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Book a service'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: selected,
                  decoration: const InputDecoration(labelText: 'Service category'),
                  items: AppConstants.serviceTypes
                      .map(
                        (e) => DropdownMenuItem(
                          value: e,
                          child: Text('${AppConstants.serviceEmoji[e] ?? '•'} $e'),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => selected = value);
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: fareController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'Your budget / fare offer',
                    prefixText: 'OMR ',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteController,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Describe the issue'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final fare = double.tryParse(fareController.text.trim());
                if (fare == null || fare <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Enter a valid fare amount')),
                  );
                  return;
                }
                Navigator.pop(dialogContext);
                await _createRequest(
                  serviceType: selected,
                  fare: fare,
                  note: noteController.text.trim(),
                );
              },
              child: const Text('Submit request'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHomeTab() {
    return RefreshIndicator(
      onRefresh: _loadLocation,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome, ${_user?.displayName ?? 'Customer'}',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _loadingLocation
                        ? 'Detecting your current location...'
                        : _position == null
                            ? 'Location not available yet. You can still create a request.'
                            : 'Live location: ${_position!.latitude.toStringAsFixed(5)}, ${_position!.longitude.toStringAsFixed(5)}',
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => _openRequestDialog(),
                      icon: const Icon(Icons.add_circle_outline),
                      label: const Text('Create a new service request'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Popular categories',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: AppConstants.serviceTypes.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 1.5,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemBuilder: (context, index) {
              final item = AppConstants.serviceTypes[index];
              return InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => _openRequestDialog(item),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          AppConstants.serviceEmoji[item] ?? '🛠️',
                          style: const TextStyle(fontSize: 26),
                        ),
                        const SizedBox(height: 10),
                        Text(item, style: const TextStyle(fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

 Widget _buildRequestsTab() {
  final uid = _user?.uid;
  if (uid == null) return const Center(child: Text('Please sign in again'));

  return StreamBuilder<List<ServiceRequestModel>>(
    stream: RequestService.customerRequestsStream(uid),
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Center(child: Text('Error: ${snapshot.error}'));
      }
      if (!snapshot.hasData) {
        return const Center(child: CircularProgressIndicator());
      }

      final requests = snapshot.data!;
      if (requests.isEmpty) {
        return const Center(child: Text('No requests yet'));
      }

      return ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: requests.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final req = requests[index];

          final providerName = _resolvedProviderName(req);
          final providerId = _resolvedProviderId(req);
          final hasProvider = providerId.isNotEmpty || providerName != 'Searching...';

          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${AppConstants.serviceEmoji[req.serviceType] ?? '🛠️'} ${req.serviceType}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: _statusColor(req.status).withOpacity(0.10),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          req.status.toUpperCase(),
                          style: TextStyle(
                            color: _statusColor(req.status),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text('Fare: OMR ${(req.displayFare ?? 0).toStringAsFixed(2)}'),
Text(
  req.providerName.isEmpty
      ? "🔍 Searching provider..."
      : "👤 ${req.providerName}",
)
                  if (req.car.trim().isNotEmpty && req.car != 'N/A')
                    Text('Vehicle: ${req.car}'),
                  if (req.note.isNotEmpty) Text('Issue: ${req.note}'),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      if (providerId.isNotEmpty)
                        ElevatedButton.icon(
                          onPressed: () async {
                            final chatId = await ChatService.ensureChat(
                              customerId: uid,
                              employeeId: providerId,
                              requestId: req.id,
                            );
                            if (!mounted) return;
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  chatId: chatId,
                                  otherUserId: providerId,
                                  title: providerName,
                                  requestId: req.id,
                                  iAmCustomer: true,
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('Chat'),
                        ),
                      if (req.isOpen)
                        OutlinedButton.icon(
                          onPressed: () => RequestService.cancelRequest(req.id),
                          icon: const Icon(Icons.close),
                          label: const Text('Cancel'),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

String _resolvedProviderName(ServiceRequestModel req) {
  final candidates = [
    req.assignedWorkerName,
    req.providerName,
    req.employeeName,
    req.raw['providerName']?.toString() ?? '',
    req.raw['assignedWorkerName']?.toString() ?? '',
    req.raw['employeeName']?.toString() ?? '',
    req.raw['workerName']?.toString() ?? '',
    req.raw['name']?.toString() ?? '',
  ];

  for (final value in candidates) {
    final v = value.trim();
    if (v.isNotEmpty && v.toLowerCase() != 'n/a') return v;
  }
  return 'Searching...';
}

String _resolvedProviderId(ServiceRequestModel req) {
  final candidates = [
    req.assignedWorkerId,
    req.providerId,
    req.employeeId,
    req.raw['providerId']?.toString() ?? '',
    req.raw['assignedWorkerId']?.toString() ?? '',
    req.raw['employeeId']?.toString() ?? '',
    req.raw['workerId']?.toString() ?? '',
  ];

  for (final value in candidates) {
    final v = value.trim();
    if (v.isNotEmpty) return v;
  }
  return '';
}

Color _statusColor(String status) {
  switch (status.toLowerCase()) {
    case 'pending':
      return Colors.orange;
    case 'accepted':
    case 'on_the_way':
      return Colors.green;
    case 'ongoing':
      return Colors.blue;
    case 'completed':
      return Colors.grey;
    case 'cancelled':
      return Colors.red;
    default:
      return Colors.black54;
  }
}

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _buildHomeTab(),
      _buildRequestsTab(),
      const SettingsScreen(isEmployee: false, currentTheme: 'light'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Customer Dashboard')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(_user?.displayName ?? 'User'),
              accountEmail: Text(_user?.email ?? ''),
              currentAccountPicture: const CircleAvatar(child: Icon(Icons.person)),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard_outlined),
              title: const Text('Dashboard'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.receipt_long_outlined),
              title: const Text('My Requests'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 1);
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('Settings'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 2);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () async {
                Navigator.pop(context);
                await SessionUtils.logout(context);
              },
            ),
          ],
        ),
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: () => _openRequestDialog(),
              backgroundColor: AppConstants.brand,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('Book'),
            )
          : null,
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (value) => setState(() => _currentIndex = value),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long_outlined), label: 'Requests'),
          BottomNavigationBarItem(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }
}
