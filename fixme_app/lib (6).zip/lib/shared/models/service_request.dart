import 'package:cloud_firestore/cloud_firestore.dart';

class ServiceRequestModel {
  final String id;
  final String customerId;
  final String customerName;
  final String serviceType;
  final String status;

  final String providerId;
  final String providerName;

  final double? customerLat;
  final double? customerLng;

  final double? fare;
  final Timestamp? updatedAt;

  ServiceRequestModel({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.serviceType,
    required this.status,
    required this.providerId,
    required this.providerName,
    required this.customerLat,
    required this.customerLng,
    required this.fare,
    required this.updatedAt,
  });

  factory ServiceRequestModel.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return ServiceRequestModel(
      id: doc.id,
      customerId: data['customerId'] ?? '',
      customerName: data['customerName'] ?? '',
      serviceType: data['serviceType'] ?? '',
      status: data['status'] ?? 'pending',

      providerId: data['providerId'] ?? '',
      providerName: data['providerName'] ?? '',

      customerLat: (data['customerLat'] as num?)?.toDouble(),
      customerLng: (data['customerLng'] as num?)?.toDouble(),

      fare: (data['fare'] as num?)?.toDouble(),
      updatedAt: data['updatedAt'],
    );
  }

  bool get isOpen => status != 'completed';
  bool get isActive => status == 'accepted' || status == 'ongoing';
  bool get isCompleted => status == 'completed';
}