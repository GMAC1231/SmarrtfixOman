import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  static String pairId(String a, String b) =>
      a.compareTo(b) <= 0 ? '${a}__${b}' : '${b}__${a}';

  static Future<String> ensureChat({
    required String customerId,
    required String employeeId,
    required String requestId,
  }) async {
    final chatId = pairId(customerId, employeeId);
    final ref = FirebaseFirestore.instance.collection('chats').doc(chatId);

    await ref.set({
      'members': [customerId, employeeId],
      'requestId': requestId,
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessageAt': FieldValue.serverTimestamp(),
      'lastMessageSnippet': '',
    }, SetOptions(merge: true));

    return chatId;
  }

  static Future<String?> sendMessage({
    required String chatId,
    required String text,
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final trimmed = text.trim();
    if (uid == null || trimmed.isEmpty) return null;

    final chatRef = FirebaseFirestore.instance.collection('chats').doc(chatId);
    final msgRef = chatRef.collection('messages').doc();

    await chatRef.set({
      'lastMessageAt': FieldValue.serverTimestamp(),
      'lastMessageSnippet': trimmed,
    }, SetOptions(merge: true));

    await msgRef.set({
      'senderId': uid,
      'text': trimmed,
      'createdAt': FieldValue.serverTimestamp(),
      'deliveredAt': null,
      'readAt': null,
    });

    return msgRef.id;
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> messagesStream(String chatId) {
    return FirebaseFirestore.instance
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('createdAt', descending: true)
        .limit(250)
        .snapshots();
  }
}
