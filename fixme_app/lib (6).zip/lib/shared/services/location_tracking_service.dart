import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

class LocationTrackingService {
  StreamSubscription<Position>? _sub;

  Future<void> startTracking(String requestId) async {
    _sub?.cancel();

    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen((pos) async {
      await FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(requestId)
          .update({
        "providerLat": pos.latitude,
        "providerLng": pos.longitude,
      });
    });
  }

  Future<void> stopTracking() async {
    await _sub?.cancel();
  }
}