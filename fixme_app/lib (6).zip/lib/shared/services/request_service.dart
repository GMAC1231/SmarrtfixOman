import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/service_request.dart';

class RequestService {
  static final _db = FirebaseFirestore.instance;

  static Stream<List<ServiceRequestModel>> openRequestsStream() {
    return _db
        .collection('serviceRequests')
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .map((snap) =>
            snap.docs.map((e) => ServiceRequestModel.fromDoc(e)).toList());
  }

  static Stream<List<ServiceRequestModel>> providerJobsStream(String uid) {
    return _db
        .collection('serviceRequests')
        .where('providerId', isEqualTo: uid)
        .snapshots()
        .map((snap) =>
            snap.docs.map((e) => ServiceRequestModel.fromDoc(e)).toList());
  }

  static Future<void> updateStatus(String id, String status) async {
    await _db.collection('serviceRequests').doc(id).update({
      "status": status,
      "updatedAt": FieldValue.serverTimestamp(),
    });
  }
}