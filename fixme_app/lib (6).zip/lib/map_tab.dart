import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;
import 'package:geolocator/geolocator.dart';

import 'shared/services/request_service.dart';

class MapTab extends StatefulWidget {
  final String? requestId;

  const MapTab({super.key, this.requestId});

  @override
  MapTabState createState() => MapTabState();
}

class MapTabState extends State<MapTab> {
  final osm.MapController _mapController = osm.MapController(
    initMapWithUserPosition: const osm.UserTrackingOption(enableTracking: false),
  );

  StreamSubscription<Position>? _positionSub;
  StreamSubscription<firestore.DocumentSnapshot<Map<String, dynamic>>>? _requestSub;
  StreamSubscription<firestore.QuerySnapshot<Map<String, dynamic>>>? _offersSub;
  StreamSubscription<firestore.DocumentSnapshot<Map<String, dynamic>>>? _providerLiveSub;

  osm.GeoPoint? _employeePoint;
  osm.GeoPoint? _customerPoint;
  osm.GeoPoint? _providerPoint;
  osm.GeoPoint? _lastEmployeeMarker;
  osm.GeoPoint? _lastCustomerMarker;
  osm.GeoPoint? _lastProviderMarker;

  bool _mapReady = false;
  bool _loadingOffers = false;
  double? _distanceKm;
  int? _etaMinutes;

  String? _acceptedProviderId;
  String? _acceptedProviderName;
  String? _acceptedProviderCar;
  double? _acceptedProviderRating;
  List<Map<String, dynamic>> _offers = const [];

  @override
  void initState() {
    super.initState();
    _listenToOwnLocation();
    _listenToRequest();
  }

  @override
  void didUpdateWidget(covariant MapTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.requestId != widget.requestId) {
      _cancelRequestListeners();
      _acceptedProviderId = null;
      _acceptedProviderName = null;
      _acceptedProviderCar = null;
      _acceptedProviderRating = null;
      _offers = const [];
      _listenToRequest();
    }
  }

  @override
  void dispose() {
    _positionSub?.cancel();
    _cancelRequestListeners();
    super.dispose();
  }

  void _cancelRequestListeners() {
    _requestSub?.cancel();
    _offersSub?.cancel();
    _providerLiveSub?.cancel();
  }

  void _listenToOwnLocation() {
    _positionSub?.cancel();
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 8,
      ),
    ).listen((pos) async {
      _employeePoint = osm.GeoPoint(latitude: pos.latitude, longitude: pos.longitude);
      await _publishOwnLiveLocation(_employeePoint!);
      await _refreshEmployeeMarker();
      await _drawRouteIfPossible();
    });
  }

  void _listenToRequest() {
    final requestId = widget.requestId;
    if (requestId == null || requestId.isEmpty) return;

    final requestRef = firestore.FirebaseFirestore.instance.collection('serviceRequests').doc(requestId);
    _loadingOffers = true;

    _requestSub = requestRef.snapshots().listen((doc) async {
      final data = doc.data();
      if (data == null) return;

      final point = _extractPointFromRequest(data);
      if (point != null) {
        _customerPoint = point;
        await _refreshCustomerMarker();
        await _drawRouteIfPossible();
      }

      final status = (data['status'] ?? '').toString();
      final providerId = (data['providerId'] ?? data['employeeId'] ?? '').toString();
      if (const {'accepted', 'arrived', 'ongoing'}.contains(status) && providerId.isNotEmpty) {
        _acceptedProviderId = providerId;
        _acceptedProviderName = (data['providerName'] ?? data['employeeName'] ?? 'Provider').toString();
        _acceptedProviderCar = (data['car'] ?? data['vehicleModel'] ?? 'N/A').toString();
        _acceptedProviderRating = (data['rating'] is num) ? (data['rating'] as num).toDouble() : 0.0;
        _listenToAcceptedProvider(providerId);
      }

      if (mounted) setState(() {});
    });

    _offersSub = requestRef.collection('offers').where('status', isEqualTo: 'pending').snapshots().listen((snapshot) {
      _offers = snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      _loadingOffers = false;
      if (mounted) setState(() {});
    });
  }

  osm.GeoPoint? _extractPointFromRequest(Map<String, dynamic> data) {
    final lat = data['customerLat'];
    final lng = data['customerLng'];
    if (lat is num && lng is num) {
      return osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble());
    }
    final gp = data['customerLocation'];
    if (gp is firestore.GeoPoint) {
      return osm.GeoPoint(latitude: gp.latitude, longitude: gp.longitude);
    }
    final location = data['location'];
    if (location is Map) {
      final l1 = location['lat'];
      final l2 = location['lng'];
      if (l1 is num && l2 is num) {
        return osm.GeoPoint(latitude: l1.toDouble(), longitude: l2.toDouble());
      }
    }
    return null;
  }

  void _listenToAcceptedProvider(String providerId) {
    _providerLiveSub?.cancel();
    _providerLiveSub = firestore.FirebaseFirestore.instance.collection('liveLocations').doc(providerId).snapshots().listen((doc) async {
      final data = doc.data();
      if (data == null) return;
      final lat = data['lat'];
      final lng = data['lng'];
      if (lat is num && lng is num) {
        _providerPoint = osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble());
        await _refreshProviderMarker();
        await _drawRouteIfPossible();
      }
    });
  }

  Future<void> _publishOwnLiveLocation(osm.GeoPoint point) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    await firestore.FirebaseFirestore.instance.collection('liveLocations').doc(uid).set({
      'lat': point.latitude,
      'lng': point.longitude,
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  Future<void> _replaceMarker(osm.GeoPoint? previous, osm.GeoPoint? next, IconData icon, Color color) async {
    if (!_mapReady || next == null) return;
    if (previous != null) {
      try {
        await _mapController.removeMarker(previous);
      } catch (_) {}
    }
    try {
      await _mapController.addMarker(
        next,
        markerIcon: osm.MarkerIcon(icon: Icon(icon, color: color, size: 42)),
      );
    } catch (_) {}
  }

  Future<void> _refreshEmployeeMarker() async {
    await _replaceMarker(_lastEmployeeMarker, _employeePoint, Icons.directions_car, Colors.red);
    _lastEmployeeMarker = _employeePoint;
  }

  Future<void> _refreshCustomerMarker() async {
    await _replaceMarker(_lastCustomerMarker, _customerPoint, Icons.location_on, Colors.green);
    _lastCustomerMarker = _customerPoint;
  }

  Future<void> _refreshProviderMarker() async {
    await _replaceMarker(_lastProviderMarker, _providerPoint, Icons.local_taxi, Colors.blue);
    _lastProviderMarker = _providerPoint;
  }

  Future<void> _drawRouteIfPossible() async {
    if (!_mapReady) return;
    final from = _providerPoint ?? _employeePoint;
    final to = _customerPoint;
    if (from == null || to == null) return;

    try {
      await _mapController.clearAllRoads();
    } catch (_) {}
    try {
      await _mapController.drawRoad(
        from,
        to,
        roadOption: const osm.RoadOption(roadColor: Colors.green, roadWidth: 8),
      );
    } catch (_) {}

    final meters = Geolocator.distanceBetween(
      from.latitude,
      from.longitude,
      to.latitude,
      to.longitude,
    );
    if (!mounted) return;
    setState(() {
      _distanceKm = meters / 1000;
      _etaMinutes = ((_distanceKm! / 25) * 60).ceil();
    });
  }

  Future<void> centerToEmployee() async {
    if (!_mapReady || _employeePoint == null) return;
    await _mapController.goToLocation(_employeePoint!);
    await _mapController.setZoom(zoomLevel: 16);
  }

  Future<void> centerToProvider() async {
    if (!_mapReady || _providerPoint == null) return;
    await _mapController.goToLocation(_providerPoint!);
    await _mapController.setZoom(zoomLevel: 16);
  }

  Future<void> setCustomerLocation(osm.GeoPoint point) async {
    _customerPoint = point;
    await _refreshCustomerMarker();
    await _drawRouteIfPossible();
    if (_mapReady) {
      await _mapController.goToLocation(point);
    }
  }

  Future<void> setCustomerLocationFromMap(dynamic location) async {
    if (location is! Map) return;
    final lat = location['lat'];
    final lng = location['lng'];
    if (lat is num && lng is num) {
      await setCustomerLocation(osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble()));
    }
  }

  Future<void> _acceptOffer(Map<String, dynamic> offer) async {
    final requestId = widget.requestId;
    if (requestId == null || requestId.isEmpty) return;
    final offerId = (offer['id'] ?? '').toString();
    if (offerId.isEmpty) return;
    await RequestService.acceptOffer(requestId: requestId, offerId: offerId, offer: offer);
  }

  Widget _buildTopInfoCard() {
    if (_distanceKm == null && _etaMinutes == null) return const SizedBox.shrink();
    return Positioned(
      top: 16,
      left: 16,
      right: 16,
      child: Card(
        color: Colors.black87,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            'ETA: ${_etaMinutes ?? '-'} min   •   Distance: ${_distanceKm?.toStringAsFixed(1) ?? '-'} km',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomCard() {
    if (widget.requestId == null || widget.requestId!.isEmpty) return const SizedBox.shrink();

    if (_acceptedProviderId != null) {
      return Positioned(
        left: 12,
        right: 12,
        bottom: 12,
        child: Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(_acceptedProviderName ?? 'Provider'),
            subtitle: Text('${_acceptedProviderCar ?? 'N/A'} • ⭐ ${(_acceptedProviderRating ?? 0).toStringAsFixed(1)}'),
            trailing: Text('${_etaMinutes ?? '-'} min'),
          ),
        ),
      );
    }

    return Positioned(
      left: 12,
      right: 12,
      bottom: 12,
      child: SizedBox(
        height: 250,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Provider offers', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                const SizedBox(height: 8),
                Expanded(
                  child: _loadingOffers
                      ? const Center(child: CircularProgressIndicator())
                      : _offers.isEmpty
                          ? const Center(child: Text('No offers yet'))
                          : ListView.separated(
                              itemCount: _offers.length,
                              separatorBuilder: (_, __) => const Divider(),
                              itemBuilder: (context, index) {
                                final data = _offers[index];
                                final fare = data['fare'];
                                final rating = (data['rating'] is num) ? (data['rating'] as num).toDouble() : 0.0;
                                return ListTile(
                                  leading: const CircleAvatar(child: Icon(Icons.person)),
                                  title: Text((data['providerName'] ?? 'Provider').toString()),
                                  subtitle: Text('${data['car'] ?? 'N/A'} • ⭐ ${rating.toStringAsFixed(1)} • ETA ${data['etaMinutes'] ?? '-'} min'),
                                  trailing: ElevatedButton(
                                    onPressed: () => _acceptOffer(data),
                                    child: Text('OMR ${fare ?? '-'}'),
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        osm.OSMFlutter(
          controller: _mapController,
          osmOption: osm.OSMOption(
            zoomOption: const osm.ZoomOption(initZoom: 15, minZoomLevel: 3, maxZoomLevel: 18),
            userTrackingOption: const osm.UserTrackingOption(enableTracking: false),
            showZoomController: true,
          ),
          onMapIsReady: (ready) async {
            if (!mounted || !ready) return;
            setState(() => _mapReady = true);
            await _refreshEmployeeMarker();
            await _refreshCustomerMarker();
            await _refreshProviderMarker();
            await _drawRouteIfPossible();
          },
        ),
        _buildTopInfoCard(),
        _buildBottomCard(),
      ],
    );
  }
}
