import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'active_job_tab.dart';
import 'dashboard_home_tab.dart';
import 'map_tab.dart';
import 'request_tab.dart';
import 'session_utils.dart';
import 'settings_screen.dart';
import 'shared/models/service_request.dart';
import 'shared/services/location_tracking_service.dart';
import 'shared/services/request_service.dart';

class EmployeeDashboardScreen extends StatefulWidget {
  const EmployeeDashboardScreen({super.key});

  @override
  State<EmployeeDashboardScreen> createState() =>
      _EmployeeDashboardScreenState();
}

class _EmployeeDashboardScreenState extends State<EmployeeDashboardScreen> {
  final GlobalKey<MapTabState> _mapTabKey = GlobalKey<MapTabState>();
  final LocationTrackingService _locationService = LocationTrackingService();

  int _selectedIndex = 0;
  bool _isOnline = false;

  @override
  void initState() {
    super.initState();
    _locationService.startPublishing(role: 'employee');
  }

  @override
  void dispose() {
    _locationService.dispose();
    super.dispose();
  }

  Future<void> _onToggleOnline() async {
    final newValue = !_isOnline;
    setState(() => _isOnline = newValue);
    await RequestService.setProviderOnline(newValue);
  }

  void _openProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            const SettingsScreen(isEmployee: true, currentTheme: 'light'),
      ),
    );
  }

Future<void> acceptRequest(String requestId) async {
  final user = FirebaseAuth.instance.currentUser;

  final doc = await FirebaseFirestore.instance
      .collection('users')
      .doc(user!.uid)
      .get();

  final name = doc.data()?['name'] ?? 'Provider';

  await FirebaseFirestore.instance
      .collection('serviceRequests')
      .doc(requestId)
      .update({
    "status": "accepted",
    "providerId": user.uid,
    "providerName": name,
  });

  await _locationService.startTracking(requestId);
}
    await _locationService.startTrackingRequest(requestId);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Accepted request for $providerName')),
    );
    setState(() => _selectedIndex = 3);
  }

  Future<void> updateJobStatus(String requestId, String status) async {
    await FirebaseFirestore.instance
        .collection('serviceRequests')
        .doc(requestId)
        .update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (status == 'completed' || status == 'cancelled') {
      await _locationService.stopTrackingRequest();
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Job marked as $status')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.providerJobsStream(user?.uid ?? ''),
      builder: (context, snapshot) {
        final jobs = snapshot.data ?? const <ServiceRequestModel>[];
        final activeJobs = jobs.where((j) => j.isActive).length;
        final completedJobs = jobs.where((j) => j.isCompleted).length;
        final earnings = jobs
            .where((j) => j.isCompleted)
            .fold<double>(0, (sum, item) => sum + (item.displayFare ?? 0));

        final pages = [
          DashboardHomeTab(
            onRecenterMap: () => _mapTabKey.currentState?.centerToEmployee(),
            onProfile: _openProfile,
            onToggleOnline: _onToggleOnline,
            activeJobs: activeJobs,
            completedJobs: completedJobs,
            earnings: earnings,
            isOnline: _isOnline,
          ),
          MapTab(key: _mapTabKey),
          EmployeeRequestsTab(
            mapTabKey: _mapTabKey,
            onAcceptRequest: acceptRequest,
          ),
          ActiveJobTab(
            mapTabKey: _mapTabKey,
            onUpdateStatus: updateJobStatus,
          ),
          const SettingsScreen(isEmployee: true, currentTheme: 'light'),
        ];

        return Scaffold(
          appBar: AppBar(title: const Text('Employee Dashboard')),
          drawer: Drawer(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                UserAccountsDrawerHeader(
                  accountName: Text(user?.displayName ?? 'No Name'),
                  accountEmail: Text(user?.email ?? ''),
                  currentAccountPicture:
                      const CircleAvatar(child: Icon(Icons.person)),
                ),
                ListTile(
                  leading: const Icon(Icons.dashboard_outlined),
                  title: const Text('Dashboard'),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 0);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.map_outlined),
                  title: const Text('Map'),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 1);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.receipt_long_outlined),
                  title: const Text('Requests'),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 2);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.work_outline),
                  title: const Text('Active Job'),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 3);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.settings_outlined),
                  title: const Text('Settings'),
                  onTap: () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 4);
                  },
                ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Logout'),
                  onTap: () async {
                    Navigator.pop(context);
                    await SessionUtils.logout(context);
                  },
                ),
              ],
            ),
          ),
          body: pages[_selectedIndex],
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (index) => setState(() => _selectedIndex = index),
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.dashboard_outlined),
                label: 'Dashboard',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.map_outlined),
                label: 'Map',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.receipt_long_outlined),
                label: 'Requests',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.work_outline),
                label: 'Active Job',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.settings_outlined),
                label: 'Settings',
              ),
            ],
          ),
        );
      },
    );
  }
}