import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import 'package:firebase_auth/firebase_auth.dart';

import '../models/service_request.dart';

class RequestService {
  static final firestore.FirebaseFirestore _db = firestore.FirebaseFirestore.instance;

  static firestore.CollectionReference<Map<String, dynamic>> get _requests =>
      _db.collection('serviceRequests');

  static Stream<List<ServiceRequestModel>> openRequestsStream() {
    return _requests
        .where('status', whereIn: ['bidding', 'pending'])
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(ServiceRequestModel.fromDoc).toList());
  }

  static Stream<List<ServiceRequestModel>> customerRequestsStream(String customerId) {
    return _requests
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(ServiceRequestModel.fromDoc).toList());
  }

  static Stream<List<ServiceRequestModel>> providerJobsStream(String providerId) {
    return _requests
        .where('status', whereIn: ['accepted', 'arrived', 'ongoing'])
        .snapshots()
        .map((snap) => snap.docs
            .map(ServiceRequestModel.fromDoc)
            .where((r) => r.providerId == providerId || r.employeeId == providerId)
            .toList());
  }

  static Future<Map<String, dynamic>> currentUserProfile(String uid) async {
    final userDoc = await _db.collection('users').doc(uid).get();
    return userDoc.data() ?? const <String, dynamic>{};
  }

  static Future<String> createRequest({
    required String serviceType,
    required double fare,
    double? lat,
    double? lng,
    String? note,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not signed in');

    final payload = <String, dynamic>{
      'customerId': user.uid,
      'customerName': user.displayName ?? 'Customer',
      'customerEmail': user.email,
      'customerPhone': user.phoneNumber,
      'serviceType': serviceType,
      'priceOffer': fare,
      'status': 'bidding',
      'customerNote': (note ?? '').trim().isEmpty ? null : note!.trim(),
      'createdAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
      'customerLat': lat,
      'customerLng': lng,
      if (lat != null && lng != null) 'customerLocation': firestore.GeoPoint(lat, lng),
      'location': {
        'lat': lat,
        'lng': lng,
      },
    };

    final doc = await _requests.add(payload);
    return doc.id;
  }

  static Future<void> sendOffer({
    required String requestId,
    required double fare,
    int etaMinutes = 8,
    String? note,
  }) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not signed in');

    final profile = await currentUserProfile(user.uid);
    final providerName = (profile['name'] ??
            profile['fullName'] ??
            profile['username'] ??
            user.displayName ??
            'Provider')
        .toString();
    final car = (profile['car'] ??
            profile['vehicleName'] ??
            profile['vehicleModel'] ??
            profile['carPlate'] ??
            'N/A')
        .toString();
    final rating = (profile['rating'] is num) ? (profile['rating'] as num).toDouble() : 5.0;

    await _requests.doc(requestId).collection('offers').doc(user.uid).set({
      'providerId': user.uid,
      'employeeId': user.uid,
      'providerName': providerName,
      'employeeName': providerName,
      'car': car,
      'rating': rating,
      'fare': fare,
      'etaMinutes': etaMinutes,
      'note': (note ?? '').trim(),
      'status': 'pending',
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));

    await _requests.doc(requestId).set({
      'status': 'pending',
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  static Stream<firestore.QuerySnapshot<Map<String, dynamic>>> offersStream(String requestId) {
    return _requests
        .doc(requestId)
        .collection('offers')
        .where('status', isEqualTo: 'pending')
        .snapshots();
  }

  static Future<void> acceptOffer({
    required String requestId,
    required String offerId,
    required Map<String, dynamic> offer,
  }) async {
    final requestRef = _requests.doc(requestId);

    await requestRef.set({
      'status': 'accepted',
      'providerId': offer['providerId'] ?? offer['employeeId'],
      'employeeId': offer['employeeId'] ?? offer['providerId'],
      'providerName': offer['providerName'] ?? offer['employeeName'],
      'employeeName': offer['employeeName'] ?? offer['providerName'],
      'car': offer['car'],
      'rating': offer['rating'],
      'agreedFare': offer['fare'],
      'acceptedOfferId': offerId,
      'acceptedAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));

    final offers = await requestRef.collection('offers').get();
    for (final doc in offers.docs) {
      await doc.reference.set({
        'status': doc.id == offerId ? 'accepted' : 'rejected',
        'updatedAt': firestore.FieldValue.serverTimestamp(),
      }, firestore.SetOptions(merge: true));
    }
  }

  static Future<void> quickAcceptRequest(String requestId) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('User not signed in');

    final profile = await currentUserProfile(user.uid);
    final providerName = (profile['name'] ??
            profile['fullName'] ??
            profile['username'] ??
            user.displayName ??
            'Provider')
        .toString();
    final car = (profile['car'] ?? profile['vehicleName'] ?? profile['vehicleModel'] ?? 'N/A')
        .toString();
    final rating = (profile['rating'] is num) ? (profile['rating'] as num).toDouble() : 5.0;

    await _requests.doc(requestId).set({
      'status': 'accepted',
      'providerId': user.uid,
      'employeeId': user.uid,
      'providerName': providerName,
      'employeeName': providerName,
      'car': car,
      'rating': rating,
      'acceptedAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  static Future<void> rejectRequest(String requestId) async {
    await _requests.doc(requestId).set({
      'status': 'rejected',
      'rejectedAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  static Future<void> updateStatus(String requestId, String status) async {
    await _requests.doc(requestId).set({
      'status': status,
      if (status == 'ongoing') 'startedAt': firestore.FieldValue.serverTimestamp(),
      if (status == 'completed') 'completedAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  static Future<void> cancelRequest(String requestId) async {
    await _requests.doc(requestId).set({
      'status': 'cancelled',
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  static Future<void> setProviderOnline(bool isOnline) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await _db.collection('users').doc(user.uid).set({
      'isOnline': isOnline,
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }
}
