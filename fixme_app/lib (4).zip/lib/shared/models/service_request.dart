import 'package:cloud_firestore/cloud_firestore.dart';

class ServiceRequestModel {
  final String id;
  final String customerId;
  final String customerName;
  final String customerEmail;
  final String customerPhone;
  final String serviceType;
  final String status;
  final double? priceOffer;
  final double? agreedFare;
  final double? customerLat;
  final double? customerLng;
  final String providerId;
  final String providerName;
  final String employeeId;
  final String employeeName;
  final String car;
  final double rating;
  final Timestamp? createdAt;
  final Timestamp? updatedAt;
  final Map<String, dynamic> raw;

  const ServiceRequestModel({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.serviceType,
    required this.status,
    required this.priceOffer,
    required this.agreedFare,
    required this.customerLat,
    required this.customerLng,
    required this.providerId,
    required this.providerName,
    required this.employeeId,
    required this.employeeName,
    required this.car,
    required this.rating,
    required this.createdAt,
    required this.updatedAt,
    required this.raw,
  });

  String get assignedWorkerId => providerId.isNotEmpty ? providerId : employeeId;
  String get assignedWorkerName => providerName.isNotEmpty ? providerName : employeeName;
  double? get displayFare => agreedFare ?? priceOffer;
  bool get isOpen => status == 'bidding' || status == 'pending';
  bool get isActive => status == 'accepted' || status == 'arrived' || status == 'ongoing';

  factory ServiceRequestModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? const <String, dynamic>{};
    double? asDouble(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}');

    return ServiceRequestModel(
      id: doc.id,
      customerId: (data['customerId'] ?? '').toString(),
      customerName: (data['customerName'] ?? 'Customer').toString(),
      customerEmail: (data['customerEmail'] ?? '').toString(),
      customerPhone: (data['customerPhone'] ?? '').toString(),
      serviceType: (data['serviceType'] ?? 'Service').toString(),
      status: (data['status'] ?? 'pending').toString(),
      priceOffer: asDouble(data['priceOffer']),
      agreedFare: asDouble(data['agreedFare']),
      customerLat: asDouble(data['customerLat']),
      customerLng: asDouble(data['customerLng']),
      providerId: (data['providerId'] ?? '').toString(),
      providerName: (data['providerName'] ?? '').toString(),
      employeeId: (data['employeeId'] ?? '').toString(),
      employeeName: (data['employeeName'] ?? '').toString(),
      car: (data['car'] ?? data['vehicleName'] ?? data['vehicleModel'] ?? 'N/A').toString(),
      rating: asDouble(data['rating']) ?? 0,
      createdAt: data['createdAt'] as Timestamp?,
      updatedAt: data['updatedAt'] as Timestamp?,
      raw: Map<String, dynamic>.from(data),
    );
  }
}
