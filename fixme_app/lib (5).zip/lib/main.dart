import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show debugPrint, kReleaseMode;
import 'package:flutter/material.dart';

import 'admin_dashboard.dart';
import 'app_theme.dart';
import 'complete_profile_screen.dart';
import 'customer_dashboard.dart';
import 'employee_dashboard.dart';
import 'home_page.dart';
import 'shared/services/profile_bootstrap.dart';
import 'splash_screen.dart';

Future<void> _initFirebase() async {
  await Firebase.initializeApp();
  await FirebaseAppCheck.instance.activate(
    androidProvider: kReleaseMode ? AndroidProvider.playIntegrity : AndroidProvider.debug,
    appleProvider: kReleaseMode ? AppleProvider.deviceCheck : AppleProvider.debug,
  );

  final options = Firebase.app().options;
  debugPrint('Firebase project: ${options.projectId}');
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _initFirebase();

  final current = FirebaseAuth.instance.currentUser;
  if (current != null) {
    await ProfileBootstrap.ensureProfile();
  }

  FirebaseAuth.instance.authStateChanges().listen((user) {
    if (user != null) {
      ProfileBootstrap.ensureProfile().catchError((_) {});
    }
  });

  runApp(const PakistanFixMeApp());
}

class PakistanFixMeApp extends StatelessWidget {
  const PakistanFixMeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PakistanFixMe',
      theme: AppTheme.light,
      home: const SplashScreen(),
      routes: {
        '/home': (_) => const HomePage(),
        '/customer_dashboard': (_) => const CustomerDashboardScreen(),
        '/employee_dashboard': (_) => const EmployeeDashboardScreen(),
        '/admin_dashboard': (_) => const AdminDashboardScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/complete_profile') {
          final args = (settings.arguments ?? {}) as Map<dynamic, dynamic>;
          return MaterialPageRoute(
            builder: (_) => CompleteProfileScreen(
              email: (args['email'] as String?) ?? '',
              name: (args['name'] as String?) ?? 'User',
              role: (args['role'] as String?) ?? 'customer',
            ),
          );
        }
        return null;
      },
    );
  }
}
