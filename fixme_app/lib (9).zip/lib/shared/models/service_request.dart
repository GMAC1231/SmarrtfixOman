import 'package:cloud_firestore/cloud_firestore.dart';

class ServiceRequestModel {
  final String id;
  final String customerId;
  final String customerName;
  final String customerEmail;
  final String customerPhone;
  final String serviceType;
  final String status;
  final String customerNote;
  final double? priceOffer;
  final double? agreedFare;
  final double? customerLat;
  final double? customerLng;
  final String employeeId;
  final String employeeName;
  final String car;
  final double rating;
  final int offersCount;
  final Timestamp? createdAt;
  final Timestamp? updatedAt;
  final Map<String, dynamic> raw;

  const ServiceRequestModel({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.serviceType,
    required this.status,
    required this.customerNote,
    required this.priceOffer,
    required this.agreedFare,
    required this.customerLat,
    required this.customerLng,
    required this.employeeId,
    required this.employeeName,
    required this.car,
    required this.rating,
    required this.offersCount,
    required this.createdAt,
    required this.updatedAt,
    required this.raw,
  });

  String get assignedWorkerId => employeeId;
  String get assignedWorkerName => employeeName;
  double? get displayFare => agreedFare ?? priceOffer;

  bool get isOpen => status == 'bidding';
  bool get isAccepted => status == 'accepted';
  bool get isActive => status == 'accepted' || status == 'ongoing';
  bool get isCompleted => status == 'completed';

  static double? _asDouble(dynamic value) {
    if (value is num) return value.toDouble();
    if (value == null) return null;
    return double.tryParse(value.toString());
  }

  static int _asInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('${value ?? ''}') ?? 0;
  }

  factory ServiceRequestModel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = Map<String, dynamic>.from(doc.data() ?? const <String, dynamic>{});
    final customerLocation = data['customerLocation'];

    double? lat = _asDouble(data['customerLat']);
    double? lng = _asDouble(data['customerLng']);

    if (customerLocation is GeoPoint) {
      lat ??= customerLocation.latitude;
      lng ??= customerLocation.longitude;
    }

    return ServiceRequestModel(
      id: doc.id,
      customerId: (data['customerId'] ?? '').toString(),
      customerName: (data['customerName'] ?? 'Customer').toString(),
      customerEmail: (data['customerEmail'] ?? '').toString(),
      customerPhone: (data['customerPhone'] ?? '').toString(),
      serviceType: (data['serviceType'] ?? 'Service').toString(),
      status: (data['status'] ?? 'bidding').toString(),
      customerNote: (data['customerNote'] ?? '').toString(),
      priceOffer: _asDouble(data['priceOffer']),
      agreedFare: _asDouble(data['agreedFare']),
      customerLat: lat,
      customerLng: lng,
      employeeId: (data['employeeId'] ?? data['providerId'] ?? '').toString(),
      employeeName: (data['employeeName'] ?? data['providerName'] ?? '').toString(),
      car: (data['car'] ?? 'N/A').toString(),
      rating: _asDouble(data['rating']) ?? 0,
      offersCount: _asInt(data['offersCount']),
      createdAt: data['createdAt'] as Timestamp?,
      updatedAt: data['updatedAt'] as Timestamp?,
      raw: data,
    );
  }

  String? get note => null;
}
