import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class PushNotificationService {
  PushNotificationService._();

  static final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'fixme_channel',
    'FixMe Notifications',
    description: 'Alerts for requests, offers, chat, and trip updates.',
    importance: Importance.max,
  );

  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;

    await _firebaseMessaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);

    await _localNotifications.initialize(initSettings);

    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_channel);

    final token = await _firebaseMessaging.getToken();
    if (kDebugMode) {
      debugPrint('FCM TOKEN: $token');
    }

    FirebaseMessaging.onMessage.listen(_showNotification);
    _initialized = true;
  }

  static Future<void> _showNotification(RemoteMessage message) async {
    final notification = message.notification;
    if (notification == null) return;

    const androidDetails = AndroidNotificationDetails(
      'fixme_channel',
      'FixMe Notifications',
      channelDescription: 'Alerts for requests, offers, chat, and trip updates.',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
    );

    await _localNotifications.show(
      message.hashCode,
      notification.title,
      notification.body,
      const NotificationDetails(android: androidDetails),
    );
  }
}
