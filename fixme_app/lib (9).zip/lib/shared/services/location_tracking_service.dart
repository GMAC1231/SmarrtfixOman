import 'dart:async';

import 'package:geolocator/geolocator.dart';

import 'live_location_service.dart';

class LocationTrackingService {
  StreamSubscription<Position>? _sub;

  Future<bool> ensurePermission() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return false;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    return permission != LocationPermission.denied &&
        permission != LocationPermission.deniedForever;
  }

  Future<Position?> getCurrentPosition() async {
    final ok = await ensurePermission();
    if (!ok) return null;
    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.best,
    );
  }

  Future<void> startPublishing({
    String role = 'employee',
    bool isOnline = true,
    String? jobId,
  }) async {
    final ok = await ensurePermission();
    if (!ok) return;

    await _sub?.cancel();
    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 8,
      ),
    ).listen((pos) async {
      await LiveLocationService.publish(
        lat: pos.latitude,
        lng: pos.longitude,
        heading: pos.heading,
        speedKph: pos.speed >= 0 ? pos.speed * 3.6 : null,
        isOnline: isOnline,
        jobId: jobId,
        role: role,
      );
    });
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
  }

  Future<void> dispose() => stop();
}
