import 'dart:async';

import 'package:geolocator/geolocator.dart';

import 'live_location_service.dart';

class ProviderLiveLocationService {
  ProviderLiveLocationService._();

  static StreamSubscription<Position>? _positionSub;

  static Future<void> start({bool isOnline = true, String? jobId}) async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return;
    }

    await _positionSub?.cancel();

    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 8,
      ),
    ).listen((pos) async {
      await LiveLocationService.publish(
        lat: pos.latitude,
        lng: pos.longitude,
        heading: pos.heading,
        speedKph: pos.speed >= 0 ? pos.speed * 3.6 : null,
        isOnline: isOnline,
        jobId: jobId,
        role: 'employee',
      );
    });
  }

  static Future<void> stop() async {
    await _positionSub?.cancel();
    _positionSub = null;
  }
}
