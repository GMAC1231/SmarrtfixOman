import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

const Color kBrand = Color(0xFF01411C);

class MapScreen extends StatefulWidget {
  final String? requestId;
  final String? providerId;
  final double? customerLat;
  final double? customerLng;

  const MapScreen({
    super.key,
    this.requestId,
    this.providerId,
    this.customerLat,
    this.customerLng,
  });

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final MapController _mapController = MapController();

  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _providerSub;
  Timer? _routeRefreshTimer;

  LatLng? _providerPosition;
  LatLng? _customerPosition;
  LatLng? _animatedProviderPosition;

  List<LatLng> _routePoints = <LatLng>[];
  bool _loadingRoute = false;
  bool _didInitialFit = false;

  double? _distanceKm;
  int? _etaMinutes;
  String? _providerName;
  String _status = 'tracking';

  @override
  void initState() {
    super.initState();
    if (widget.customerLat != null && widget.customerLng != null) {
      _customerPosition = LatLng(widget.customerLat!, widget.customerLng!);
    }
    _listenProvider();
    _startRouteRefreshLoop();
  }

  @override
  void dispose() {
    _providerSub?.cancel();
    _routeRefreshTimer?.cancel();
    super.dispose();
  }

  void _listenProvider() {
    final providerId = widget.providerId;
    if (providerId == null || providerId.trim().isEmpty) return;

    _providerSub = FirebaseFirestore.instance
        .collection('liveLocations')
        .doc(providerId)
        .snapshots()
        .listen((doc) async {
      if (!doc.exists) return;
      final data = doc.data() ?? const <String, dynamic>{};

      final providerLat = _readLat(data);
      final providerLng = _readLng(data);
      if (providerLat == null || providerLng == null) return;

      final nextPosition = LatLng(providerLat, providerLng);
      _providerName = (data['name'] ?? data['providerName'] ?? 'Provider').toString();
      _status = (data['jobStatus'] ?? data['status'] ?? _status).toString();

      if (_animatedProviderPosition == null) {
        _animatedProviderPosition = nextPosition;
      } else {
        _animateProvider(from: _animatedProviderPosition!, to: nextPosition);
      }
      _providerPosition = nextPosition;

      if (_customerPosition != null) {
        await _fetchRoute();
      }

      if (!mounted) return;
      setState(() {});
      _fitOnceOrKeepVisible();
    });
  }

  void _startRouteRefreshLoop() {
    _routeRefreshTimer?.cancel();
    _routeRefreshTimer = Timer.periodic(const Duration(seconds: 12), (_) async {
      if (_providerPosition != null && _customerPosition != null) {
        await _fetchRoute();
      }
    });
  }

  Future<void> _fetchRoute() async {
    if (_providerPosition == null || _customerPosition == null || _loadingRoute) return;
    _loadingRoute = true;

    try {
      final from = _providerPosition!;
      final to = _customerPosition!;
      final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
        '?overview=full&geometries=geojson&steps=false',
      );

      final res = await http.get(uri);
      if (res.statusCode != 200) return;

      final json = jsonDecode(res.body) as Map<String, dynamic>;
      final routes = json['routes'] as List<dynamic>?;
      if (routes == null || routes.isEmpty) return;

      final route0 = routes.first as Map<String, dynamic>;
      final geometry = route0['geometry'] as Map<String, dynamic>;
      final coords = geometry['coordinates'] as List<dynamic>;

      final points = coords.map((point) {
        final p = point as List<dynamic>;
        return LatLng((p[1] as num).toDouble(), (p[0] as num).toDouble());
      }).toList();

      final distanceMeters = (route0['distance'] as num?)?.toDouble();
      final durationSeconds = (route0['duration'] as num?)?.toDouble();

      if (!mounted) return;
      setState(() {
        _routePoints = points;
        _distanceKm = distanceMeters == null ? null : distanceMeters / 1000.0;
        _etaMinutes = durationSeconds == null
            ? null
            : math.max(1, (durationSeconds / 60).round());
      });
    } catch (_) {
      // Fail silently; map still renders markers.
    } finally {
      _loadingRoute = false;
    }
  }

  double? _readLat(Map<String, dynamic> data) {
    final liveLocation = data['liveLocation'];
    if (liveLocation is GeoPoint) return liveLocation.latitude;
    if (liveLocation is Map<String, dynamic>) {
      final lat = liveLocation['lat'] ?? liveLocation['latitude'];
      if (lat is num) return lat.toDouble();
    }
    final lat = data['lat'] ?? data['latitude'];
    if (lat is num) return lat.toDouble();
    return null;
  }

  double? _readLng(Map<String, dynamic> data) {
    final liveLocation = data['liveLocation'];
    if (liveLocation is GeoPoint) return liveLocation.longitude;
    if (liveLocation is Map<String, dynamic>) {
      final lng = liveLocation['lng'] ?? liveLocation['longitude'];
      if (lng is num) return lng.toDouble();
    }
    final lng = data['lng'] ?? data['longitude'];
    if (lng is num) return lng.toDouble();
    return null;
  }

  void _animateProvider({required LatLng from, required LatLng to}) {
    const steps = 12;
    const stepDuration = Duration(milliseconds: 150);

    int current = 0;
    Timer.periodic(stepDuration, (timer) {
      current += 1;
      final t = current / steps;
      final lat = from.latitude + (to.latitude - from.latitude) * t;
      final lng = from.longitude + (to.longitude - from.longitude) * t;

      if (!mounted) {
        timer.cancel();
        return;
      }

      setState(() {
        _animatedProviderPosition = LatLng(lat, lng);
      });

      if (current >= steps) timer.cancel();
    });
  }

  void _fitOnceOrKeepVisible() {
    final provider = _animatedProviderPosition ?? _providerPosition;
    final customer = _customerPosition;
    if (provider == null && customer == null) return;

    if (!_didInitialFit && provider != null && customer != null) {
      _didInitialFit = true;
      _mapController.fitCamera(
        CameraFit.bounds(
          bounds: LatLngBounds.fromPoints(<LatLng>[provider, customer]),
          padding: const EdgeInsets.all(70),
        ),
      );
      return;
    }

    if (provider != null) {
      _mapController.move(provider, _mapController.camera.zoom);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = _animatedProviderPosition ?? _providerPosition;
    final center = provider ?? _customerPosition ?? const LatLng(23.5880, 58.3829);

    return Stack(
      children: [
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: center,
            initialZoom: 14,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.pakistanfixme.app',
            ),
            if (_routePoints.isNotEmpty)
              PolylineLayer(
                polylines: [
                  Polyline(points: _routePoints, strokeWidth: 5),
                ],
              ),
            MarkerLayer(
              markers: [
                if (_customerPosition != null)
                  Marker(
                    point: _customerPosition!,
                    width: 44,
                    height: 44,
                    child: const Icon(Icons.location_on, size: 40, color: Colors.red),
                  ),
                if (provider != null)
                  Marker(
                    point: provider,
                    width: 44,
                    height: 44,
                    child: const Icon(Icons.directions_car, size: 34, color: kBrand),
                  ),
              ],
            ),
          ],
        ),
        Positioned(
          left: 12,
          right: 12,
          top: 12,
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.95),
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 14, offset: Offset(0, 6)),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _providerName == null ? 'Tracking provider' : 'Tracking $_providerName',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 12,
                    runSpacing: 4,
                    children: [
                      Text('Status: $_status'),
                      if (_distanceKm != null) Text('Distance: ${_distanceKm!.toStringAsFixed(1)} km'),
                      if (_etaMinutes != null) Text('ETA: $_etaMinutes min'),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
