import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../constants/firestore_keys.dart';
import '../models/service_request.dart';

class RequestService {
  RequestService._();

  static final FirebaseFirestore _db = FirebaseFirestore.instance;
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static CollectionReference<Map<String, dynamic>> get _requests =>
      _db.collection(FirestoreCollections.serviceRequests);

  static DocumentReference<Map<String, dynamic>> requestRef(String requestId) =>
      _requests.doc(requestId);

  static CollectionReference<Map<String, dynamic>> offersRef(String requestId) =>
      requestRef(requestId).collection(FirestoreCollections.offers);

  static User get _requireUser {
    final user = _auth.currentUser;
    if (user == null) {
      throw StateError('User not signed in');
    }
    return user;
  }

  static Future<Map<String, dynamic>> currentUserProfile(String uid) async {
    final doc = await _db.collection(FirestoreCollections.users).doc(uid).get();
    return Map<String, dynamic>.from(doc.data() ?? const <String, dynamic>{});
  }

  static Future<String> _currentUserName() async {
    final user = _requireUser;
    final profile = await currentUserProfile(user.uid);
    final raw = profile['name'] ??
        profile['fullName'] ??
        profile['displayName'] ??
        profile['username'] ??
        user.displayName ??
        'User';
    final name = raw.toString().trim();
    return name.isEmpty ? 'User' : name;
  }

  static Stream<List<ServiceRequestModel>> customerRequestsStream(String customerId) {
    if (customerId.trim().isEmpty) {
      return const Stream<List<ServiceRequestModel>>.empty();
    }

    return _requests
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(ServiceRequestModel.fromDoc).toList());
  }

  static Stream<List<ServiceRequestModel>> openRequestsStream({String? serviceType}) {
    Query<Map<String, dynamic>> query =
        _requests.where('status', isEqualTo: 'bidding');

    final cleaned = serviceType?.trim();
    if (cleaned != null && cleaned.isNotEmpty) {
      query = query.where('serviceType', isEqualTo: cleaned);
    }

    return query
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(ServiceRequestModel.fromDoc).toList());
  }

  static Stream<List<ServiceRequestModel>> providerJobsStream(String employeeId) {
    if (employeeId.trim().isEmpty) {
      return const Stream<List<ServiceRequestModel>>.empty();
    }

    return _requests
        .where('employeeId', isEqualTo: employeeId)
        .orderBy('updatedAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map(ServiceRequestModel.fromDoc).toList());
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> offersStream(String requestId) {
    return offersRef(requestId)
        .orderBy('createdAt', descending: false)
        .snapshots();
  }

  static Stream<DocumentSnapshot<Map<String, dynamic>>> requestStream(String requestId) {
    return requestRef(requestId).snapshots();
  }

  static Future<String> createRequest({
    required String serviceType,
    required double fare,
    double? lat,
    double? lng,
    String? note,
  }) async {
    final user = _requireUser;
    final customerName = await _currentUserName();
    final trimmedServiceType = serviceType.trim();
    final trimmedNote = (note ?? '').trim();

    final doc = _requests.doc();
    await doc.set(<String, dynamic>{
      'id': doc.id,
      'customerId': user.uid,
      'customerName': customerName,
      'customerEmail': user.email ?? '',
      'customerPhone': user.phoneNumber ?? '',
      'serviceType': trimmedServiceType,
      'priceOffer': fare,
      'agreedFare': null,
      'status': 'bidding',
      'customerNote': trimmedNote,
      'employeeId': '',
      'employeeName': '',
      'providerId': '',
      'providerName': '',
      'assignedWorkerId': '',
      'assignedWorkerName': '',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'acceptedAt': null,
      'startedAt': null,
      'completedAt': null,
      'cancelledAt': null,
      'customerLat': lat,
      'customerLng': lng,
      'customerLocation': (lat != null && lng != null) ? GeoPoint(lat, lng) : null,
      'offersCount': 0,
      'lastOfferAt': null,
    });

    return doc.id;
  }

  static Future<void> sendOffer({
    required String requestId,
    required double fare,
    int? etaMinutes,
    double? distanceKm,
    String? note,
  }) async {
    final user = _requireUser;
    final providerName = await _currentUserName();
    final trimmedNote = (note ?? '').trim();

    await _db.runTransaction((tx) async {
      final reqRef = requestRef(requestId);
      final reqSnap = await tx.get(reqRef);

      if (!reqSnap.exists) {
        throw StateError('Request not found');
      }

      final reqData = reqSnap.data() ?? const <String, dynamic>{};
      final status = (reqData['status'] ?? '').toString();
      if (status != 'bidding') {
        throw StateError('This request is no longer open for offers');
      }

      final offerRef = offersRef(requestId).doc(user.uid);
      final offerSnap = await tx.get(offerRef);
      final isNewOffer = !offerSnap.exists;
      final existingCreatedAt = offerSnap.data()?['createdAt'];

      tx.set(offerRef, <String, dynamic>{
        'employeeId': user.uid,
        'employeeName': providerName,
        'providerId': user.uid,
        'providerName': providerName,
        'proposedFare': fare,
        'etaMinutes': etaMinutes,
        'distanceKm': distanceKm,
        'note': trimmedNote,
        'status': 'pending',
        'createdAt': existingCreatedAt ?? FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      final update = <String, dynamic>{
        'lastOfferAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      };
      if (isNewOffer) {
        update['offersCount'] = FieldValue.increment(1);
      }
      tx.set(reqRef, update, SetOptions(merge: true));
    });
  }

  static Future<void> acceptOffer({
    required String requestId,
    required String employeeId,
  }) async {
    await _db.runTransaction((tx) async {
      final reqRef = requestRef(requestId);
      final reqSnap = await tx.get(reqRef);
      if (!reqSnap.exists) throw StateError('Request not found');

      final req = reqSnap.data() ?? const <String, dynamic>{};
      final currentStatus = (req['status'] ?? '').toString();
      if (currentStatus != 'bidding') {
        throw StateError('Request has already been assigned');
      }

      final selectedOfferRef = offersRef(requestId).doc(employeeId);
      final selectedOfferSnap = await tx.get(selectedOfferRef);
      if (!selectedOfferSnap.exists) {
        throw StateError('Selected offer not found');
      }

      final offer = selectedOfferSnap.data() ?? const <String, dynamic>{};
      final providerName = (offer['employeeName'] ?? offer['providerName'] ?? 'Provider')
          .toString();
      final proposedFare = (offer['proposedFare'] as num?)?.toDouble();

      tx.set(reqRef, <String, dynamic>{
        'status': 'accepted',
        'employeeId': employeeId,
        'employeeName': providerName,
        'providerId': employeeId,
        'providerName': providerName,
        'assignedWorkerId': employeeId,
        'assignedWorkerName': providerName,
        'agreedFare': proposedFare,
        'acceptedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      tx.set(selectedOfferRef, <String, dynamic>{
        'status': 'accepted',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    });

    final allOffers = await offersRef(requestId).get();
    final batch = _db.batch();
    for (final doc in allOffers.docs) {
      if (doc.id == employeeId) continue;
      batch.set(doc.reference, <String, dynamic>{
        'status': 'rejected',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
    await batch.commit();
  }

  static Future<void> quickAcceptRequest(String requestId) async {
    final user = _requireUser;
    final providerName = await _currentUserName();

    await _db.runTransaction((tx) async {
      final reqRef = requestRef(requestId);
      final reqSnap = await tx.get(reqRef);
      if (!reqSnap.exists) throw StateError('Request not found');

      final req = reqSnap.data() ?? const <String, dynamic>{};
      final currentStatus = (req['status'] ?? '').toString();
      if (currentStatus != 'bidding') {
        throw StateError('Request has already been taken');
      }

      final offerRef = offersRef(requestId).doc(user.uid);
      final offerSnap = await tx.get(offerRef);
      final existingCreatedAt = offerSnap.data()?['createdAt'];
      final fare = (req['priceOffer'] as num?)?.toDouble();

      tx.set(reqRef, <String, dynamic>{
        'status': 'accepted',
        'employeeId': user.uid,
        'employeeName': providerName,
        'providerId': user.uid,
        'providerName': providerName,
        'assignedWorkerId': user.uid,
        'assignedWorkerName': providerName,
        'agreedFare': fare,
        'acceptedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      tx.set(offerRef, <String, dynamic>{
        'employeeId': user.uid,
        'employeeName': providerName,
        'providerId': user.uid,
        'providerName': providerName,
        'proposedFare': fare,
        'status': 'accepted',
        'createdAt': existingCreatedAt ?? FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    });

    final allOffers = await offersRef(requestId).get();
    final batch = _db.batch();
    for (final doc in allOffers.docs) {
      if (doc.id == user.uid) continue;
      batch.set(doc.reference, <String, dynamic>{
        'status': 'rejected',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
    await batch.commit();
  }

  static Future<void> rejectOwnOffer(String requestId) async {
    final user = _requireUser;
    final reqSnap = await requestRef(requestId).get();
    if (!reqSnap.exists) throw StateError('Request not found');

    final req = reqSnap.data() ?? const <String, dynamic>{};
    final status = (req['status'] ?? '').toString();
    if (status != 'bidding') {
      throw StateError('This request is no longer open');
    }

    await offersRef(requestId).doc(user.uid).set(<String, dynamic>{
      'employeeId': user.uid,
      'status': 'rejected',
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static Future<void> rejectRequest(String requestId) async {
    await rejectOwnOffer(requestId);
  }

  static Future<void> updateStatus(String requestId, String status) async {
    const allowed = <String>{
      'bidding',
      'accepted',
      'ongoing',
      'completed',
      'cancelled',
      'rejected',
    };
    if (!allowed.contains(status)) {
      throw StateError('Invalid status: $status');
    }

    final payload = <String, dynamic>{
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (status == 'ongoing') payload['startedAt'] = FieldValue.serverTimestamp();
    if (status == 'completed') payload['completedAt'] = FieldValue.serverTimestamp();
    if (status == 'cancelled') payload['cancelledAt'] = FieldValue.serverTimestamp();

    await requestRef(requestId).set(payload, SetOptions(merge: true));
  }

  static Future<void> cancelRequest(String requestId) async {
    final reqSnap = await requestRef(requestId).get();
    if (!reqSnap.exists) throw StateError('Request not found');

    final req = reqSnap.data() ?? const <String, dynamic>{};
    final currentStatus = (req['status'] ?? '').toString();
    if (currentStatus == 'completed') {
      throw StateError('Completed requests cannot be cancelled');
    }

    await requestRef(requestId).set(<String, dynamic>{
      'status': 'cancelled',
      'cancelledAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    final allOffers = await offersRef(requestId).get();
    final batch = _db.batch();
    for (final doc in allOffers.docs) {
      batch.set(doc.reference, <String, dynamic>{
        'status': 'cancelled',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
    await batch.commit();
  }

  static Future<void> setProviderOnline(bool isOnline) async {
    final user = _auth.currentUser;
    if (user == null) return;

    await _db.collection(FirestoreCollections.users).doc(user.uid).set(
      <String, dynamic>{
        'isOnline': isOnline,
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  static Future<void> publishLiveLocation({
    required double lat,
    required double lng,
  }) async {
    final user = _auth.currentUser;
    if (user == null) return;

    await _db.collection(FirestoreCollections.liveLocations).doc(user.uid).set(
      <String, dynamic>{
        'uid': user.uid,
        'lat': lat,
        'lng': lng,
        'liveLocation': GeoPoint(lat, lng),
        'role': 'employee',
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }
}
