import 'package:flutter/material.dart';

class RequestCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double price;
  final VoidCallback? onAccept;
  final VoidCallback? onReject;
  final VoidCallback? onOffer;
  final VoidCallback? onChat;
  final VoidCallback? onRoute;

  const RequestCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.price,
    this.onAccept,
    this.onReject,
    this.onOffer,
    this.onChat,
    this.onRoute,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// TITLE
            Text(
              title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 6),

            /// SUBTITLE
            Text(
              subtitle,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),

            const SizedBox(height: 10),

            /// PRICE
            Row(
              children: [
                Icon(Icons.attach_money, size: 18, color: scheme.primary),
                const SizedBox(width: 4),
                Text(
                  'OMR ${price.toStringAsFixed(2)}',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: scheme.primary,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 14),

            /// ACTIONS (GROUPED CLEANLY)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (onRoute != null)
                  OutlinedButton.icon(
                    onPressed: onRoute,
                    icon: const Icon(Icons.map_outlined),
                    label: const Text('Route'),
                  ),

                if (onChat != null)
                  FilledButton.tonal(
                    onPressed: onChat,
                    child: const Text('Chat'),
                  ),

                if (onOffer != null)
                  FilledButton.tonal(
                    onPressed: onOffer,
                    child: const Text('Offer'),
                  ),

                if (onAccept != null)
                  FilledButton(
                    onPressed: onAccept,
                    child: const Text('Accept'),
                  ),

                if (onReject != null)
                  FilledButton(
                    onPressed: onReject,
                    style: FilledButton.styleFrom(
                      backgroundColor: scheme.error,
                      foregroundColor: scheme.onError,
                    ),
                    child: const Text('Reject'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}