import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_service.dart';
import 'shared/services/request_service.dart';

/// ✅ FIXED NAME + STATEFUL (IMPORTANT)
class EmployeeActiveJobTab extends StatefulWidget {
  final GlobalKey<MapTabState> mapTabKey;
  final VoidCallback? onOpenMapTab;

  const EmployeeActiveJobTab({
    super.key,
    required this.mapTabKey,
    this.onOpenMapTab,
  });

  @override
  State<EmployeeActiveJobTab> createState() =>
      _EmployeeActiveJobTabState();
}

class _EmployeeActiveJobTabState extends State<EmployeeActiveJobTab> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.openRequestsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final requests = snapshot.data!;

        if (requests.isEmpty) {
          return const Center(child: Text('No open requests'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: requests.length,
          itemBuilder: (context, index) {
            final req = requests[index];

            return _RequestCard(
              request: req,
              busy: _busy,

              /// 🔥 ROUTE BUTTON
              onRoute: () async {
                final point = _extractPoint(req);

                if (point == null) {
                  _showSnack('Customer location not available');
                  return;
                }

                final mapState = widget.mapTabKey.currentState;
                if (mapState == null) {
                  _showSnack('Map not ready yet');
                  return;
                }

                await mapState.setCustomerLocation(point);
                widget.onOpenMapTab?.call();
              },

              onQuickAccept: () => _handleQuickAccept(req),
              onReject: () => _handleReject(req),
              onOffer: () => _showOfferDialog(req),

              onChat: req.customerId.isEmpty
                  ? null
                  : () => _openChat(
                        customerId: req.customerId,
                        requestId: req.id,
                        title: req.customerName.isEmpty
                            ? 'Customer'
                            : req.customerName,
                      ),
            );
          },
        );
      },
    );
  }

  /// 🔥 HELPERS

  void _showSnack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(text)));
  }

  LatLng? _extractPoint(ServiceRequestModel req) {
    if (req.customerLat != null && req.customerLng != null) {
      return LatLng(req.customerLat!, req.customerLng!);
    }
    return null;
  }

  Future<void> _handleQuickAccept(ServiceRequestModel req) async {
    await _runBusy(() async {
      if (req.status != 'bidding') {
        throw Exception('Already taken');
      }

      await RequestService.quickAcceptRequest(req.id);
      _showSnack('Request accepted');
    });
  }

  Future<void> _handleReject(ServiceRequestModel req) async {
    await _runBusy(() async {
      await RequestService.rejectRequest(req.id);
      _showSnack('Request rejected');
    });
  }

  Future<void> _runBusy(Future<void> Function() action) async {
    if (_busy) return;

    setState(() => _busy = true);

    try {
      await action();
    } catch (e) {
      _showSnack(e.toString());
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _showOfferDialog(ServiceRequestModel req) async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Send Offer'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Fare',
            prefixText: 'OMR ',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final fare = double.tryParse(controller.text);
              if (fare == null) return;

              Navigator.pop(context);

              await RequestService.sendOffer(
                requestId: req.id,
                fare: fare,
              );

              _showSnack('Offer sent');
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  Future<void> _openChat({
    required String customerId,
    required String requestId,
    required String title,
  }) async {
    final providerId = FirebaseAuth.instance.currentUser?.uid;
    if (providerId == null) return;

    final chatId = await ChatService.ensureChat(
      customerId: customerId,
      employeeId: providerId,
      requestId: requestId,
    );

    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          chatId: chatId,
          otherUserId: customerId,
          title: title,
          requestId: requestId,
          iAmCustomer: false,
          providerId: providerId,
        ),
      ),
    );
  }
}
class _RequestCard extends StatelessWidget {
  final dynamic request;
  final bool busy;
  final VoidCallback onRoute;
  final VoidCallback onQuickAccept;
  final VoidCallback onReject;
  final VoidCallback onOffer;
  final VoidCallback? onChat;

  const _RequestCard({
    required this.request,
    required this.busy,
    required this.onRoute,
    required this.onQuickAccept,
    required this.onReject,
    required this.onOffer,
    required this.onChat,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// 🔥 TITLE
          Text(
            request.serviceType ?? 'Service Request',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 6),

          /// 👤 CUSTOMER
          Text("👤 ${request.customerName ?? 'Customer'}"),

          /// 💰 PRICE
          Text("💰 OMR ${(request.displayFare ?? 0).toStringAsFixed(2)}"),

          /// 📌 STATUS
          Text("📌 ${request.status}"),

          const SizedBox(height: 12),

          /// 🔥 BUTTONS
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _btn(Icons.map, "Route", onRoute),
              _btn(Icons.check, "Accept", onQuickAccept),
              _btn(Icons.close, "Reject", onReject),
              _btn(Icons.local_offer, "Offer", onOffer),

              if (onChat != null)
                _btn(Icons.chat, "Chat", onChat!),
            ],
          ),
        ],
      ),
    );
  }

  Widget _btn(IconData icon, String label, VoidCallback onTap) {
    return ElevatedButton.icon(
      onPressed: busy ? null : onTap,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}