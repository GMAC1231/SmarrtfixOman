import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_service.dart';
import 'shared/services/request_service.dart';

class EmployeeRequestsTab extends StatefulWidget {
  final GlobalKey<MapTabState> mapTabKey;
  final VoidCallback? onOpenMapTab;

  const EmployeeRequestsTab({
    super.key,
    required this.mapTabKey,
    this.onOpenMapTab,
  });

  @override
  State<EmployeeRequestsTab> createState() => _EmployeeRequestsTabState();
}

class _EmployeeRequestsTabState extends State<EmployeeRequestsTab> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.openRequestsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final requests = snapshot.data!;
        if (requests.isEmpty) {
          return const Center(child: Text('No open requests'));
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final req = requests[index];

            return _RequestCard(
              request: req,
              busy: _busy,
              onRoute: () async {
                final point = _extractPoint(req);

                if (point == null) {
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Customer location not available'),
                    ),
                  );
                  return;
                }

                final mapState = widget.mapTabKey.currentState;
                if (mapState == null) {
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Map not ready yet')),
                  );
                  return;
                }

                try {
                  await mapState.setCustomerLocation(point);
                  widget.onOpenMapTab?.call();
                } catch (e) {
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Failed to load route: $e')),
                  );
                }
              },
              onQuickAccept: () => _handleQuickAccept(req),
              onReject: () => _handleReject(req),
              onOffer: () => _showOfferDialog(req),
              onChat: req.customerId.isEmpty
                  ? null
                  : () => _openChat(
                        customerId: req.customerId,
                        requestId: req.id,
                        title: req.customerName.isEmpty
                            ? 'Customer'
                            : req.customerName,
                      ),
            );
          },
        );
      },
    );
  }

  LatLng? _extractPoint(ServiceRequestModel req) {
    if (req.customerLat != null && req.customerLng != null) {
      return LatLng(req.customerLat!, req.customerLng!);
    }
    return null;
  }

  Future<void> _handleQuickAccept(ServiceRequestModel req) async {
    await _runBusy(() async {
      if (req.status != 'bidding') {
        throw Exception('This request is no longer available');
      }

      await RequestService.quickAcceptRequest(req.id);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request accepted')),
      );
    });
  }

  Future<void> _handleReject(ServiceRequestModel req) async {
    await _runBusy(() async {
      if (req.status != 'bidding') {
        throw Exception('This request is no longer open');
      }

      await RequestService.rejectRequest(req.id);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request rejected')),
      );
    });
  }

  Future<void> _runBusy(Future<void> Function() action) async {
    if (_busy) return;
    setState(() => _busy = true);

    try {
      await action();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$e')),
      );
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _showOfferDialog(ServiceRequestModel req) async {
    final fareController = TextEditingController(
      text: (req.displayFare ?? 0).toStringAsFixed(2),
    );
    final noteController = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        bool submitting = false;

        return StatefulBuilder(
          builder: (dialogInnerContext, setStateDialog) {
            return AlertDialog(
              title: const Text('Send offer'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: fareController,
                    enabled: !submitting,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Your fare',
                      prefixText: 'OMR ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: noteController,
                    enabled: !submitting,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      labelText: 'Optional note',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed:
                      submitting ? null : () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: submitting
                      ? null
                      : () async {
                          final fare =
                              double.tryParse(fareController.text.trim());

                          if (fare == null || fare <= 0) {
                            ScaffoldMessenger.of(dialogInnerContext)
                                .showSnackBar(
                              const SnackBar(
                                content: Text('Enter a valid fare'),
                              ),
                            );
                            return;
                          }

                          setStateDialog(() => submitting = true);
                          Navigator.pop(dialogContext);

                          await _runBusy(() async {
                            if (req.status != 'bidding') {
                              throw Exception('Request already taken');
                            }

                            await RequestService.sendOffer(
                              requestId: req.id,
                              fare: fare,
                              note: noteController.text.trim().isEmpty
                                  ? null
                                  : noteController.text.trim(),
                            );

                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Offer sent')),
                            );
                          });
                        },
                  child: const Text('Send'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _openChat({
    required String customerId,
    required String requestId,
    required String title,
  }) async {
    final providerId = FirebaseAuth.instance.currentUser?.uid;
    if (providerId == null) return;

    try {
      final chatId = await ChatService.ensureChat(
        customerId: customerId,
        employeeId: providerId,
        requestId: requestId,
      );

      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChatScreen(
            chatId: chatId,
            otherUserId: customerId,
            title: title,
            requestId: requestId,
            iAmCustomer: false,
            providerId: providerId,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open chat: $e')),
      );
    }
  }
}

class _RequestCard extends StatelessWidget {
  final ServiceRequestModel request;
  final bool busy;
  final VoidCallback onRoute;
  final VoidCallback onQuickAccept;
  final VoidCallback onReject;
  final VoidCallback onOffer;
  final VoidCallback? onChat;

  const _RequestCard({
    required this.request,
    required this.busy,
    required this.onRoute,
    required this.onQuickAccept,
    required this.onReject,
    required this.onOffer,
    required this.onChat,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: theme.cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              request.serviceType.isEmpty
                  ? 'Service Request'
                  : request.serviceType,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '👤 ${request.customerName.isEmpty ? 'Customer' : request.customerName}',
            ),
            const SizedBox(height: 4),
            Text('💰 OMR ${(request.displayFare ?? 0).toStringAsFixed(2)}'),
            const SizedBox(height: 4),
            Text('📌 ${request.status}'),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _actionButton(
                  onPressed: busy ? null : onRoute,
                  icon: Icons.map,
                  label: 'Route',
                ),
                _actionButton(
                  onPressed: busy ? null : onQuickAccept,
                  icon: Icons.check,
                  label: 'Accept',
                ),
                _actionButton(
                  onPressed: busy ? null : onReject,
                  icon: Icons.close,
                  label: 'Reject',
                ),
                _actionButton(
                  onPressed: busy ? null : onOffer,
                  icon: Icons.local_offer,
                  label: 'Offer',
                ),
                if (onChat != null)
                  _actionButton(
                    onPressed: busy ? null : onChat,
                    icon: Icons.chat_bubble_outline,
                    label: 'Chat',
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionButton({
    required VoidCallback? onPressed,
    required IconData icon,
    required String label,
  }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }
}