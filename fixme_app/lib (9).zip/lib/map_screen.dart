import 'package:flutter/material.dart';
import 'map_tab.dart';

class MapScreen extends StatelessWidget {
  final String? requestId;
  final String? providerId;
  final double? customerLat;
  final double? customerLng;
  final bool trackLiveDriver;
  final bool listenToAssignedRequest;

  const MapScreen({
    super.key,
    this.requestId,
    this.providerId,
    this.customerLat,
    this.customerLng,
    this.trackLiveDriver = true,
    this.listenToAssignedRequest = true,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      /// 🔥 Uber-style minimal top bar
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.black,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Live Tracking',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: Colors.white,
          ),
        ),
      ),

      /// ✅ Safe wrapper to avoid UI overflow
      body: SafeArea(
        child: _buildMap(),
      ),
    );
  }

  Widget _buildMap() {
    try {
      return MapTab(
        requestId: requestId,
        providerId: providerId,
        customerLat: customerLat,
        customerLng: customerLng,
      );
    } catch (e) {
      /// ❌ fallback UI (VERY IMPORTANT)
      return Center(
        child: Text(
          'Map failed to load\n$e',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white),
        ),
      );
    }
  }
}