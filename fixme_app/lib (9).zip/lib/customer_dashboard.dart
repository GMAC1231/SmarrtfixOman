import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'chat_screen.dart';
import 'main.dart';
import 'map_screen.dart';
import 'session_utils.dart';
import 'settings_screen.dart';
import 'shared/models/service_request.dart';
import 'shared/services/chat_service.dart';
import 'shared/services/location_tracking_service.dart';
import 'shared/services/request_service.dart';

const List<Map<String, String>> kServiceCategories = [
  {'key': 'Technician', 'emoji': '🔧'},
  {'key': 'Plumber', 'emoji': '🚰'},
  {'key': 'Electrician', 'emoji': '💡'},
  {'key': 'Carpenter', 'emoji': '🪚'},
  {'key': 'Painter', 'emoji': '🎨'},
  {'key': 'Handyman', 'emoji': '🛠️'},
  {'key': 'Cleaner', 'emoji': '🧹'},
];

class CustomerDashboardScreen extends StatefulWidget {
  const CustomerDashboardScreen({super.key});

  @override
  State<CustomerDashboardScreen> createState() =>
      _CustomerDashboardScreenState();
}

class _CustomerDashboardScreenState extends State<CustomerDashboardScreen> {
  final LocationTrackingService _locationService = LocationTrackingService();

  int _currentIndex = 0;
  Position? _position;
  bool _loadingLocation = false;
  bool _creatingRequest = false;

  User? get _user => FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  @override
  void dispose() {
    _locationService.dispose();
    super.dispose();
  }

  String _themeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  void _showSnack(String text, {bool error = false}) {
    if (!mounted) return;

    final scheme = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(text),
          behavior: SnackBarBehavior.floating,
          backgroundColor: error ? scheme.error : null,
        ),
      );
  }

  Future<void> _loadLocation() async {
    if (!mounted) return;
    setState(() => _loadingLocation = true);

    try {
      final pos = await _locationService.getCurrentPosition();
      if (!mounted) return;
      setState(() => _position = pos);
    } catch (e) {
      _showSnack('Failed to load location: $e', error: true);
    } finally {
      if (mounted) {
        setState(() => _loadingLocation = false);
      }
    }
  }

  Future<void> _createRequest({
    required String serviceType,
    required double fare,
    String? note,
  }) async {
    if (_creatingRequest) return;

    if (_position == null) {
      _showSnack(
        'Location not available yet. Please refresh location first.',
        error: true,
      );
      return;
    }

    setState(() => _creatingRequest = true);

    try {
      await RequestService.createRequest(
        serviceType: serviceType,
        fare: fare,
        lat: _position!.latitude,
        lng: _position!.longitude,
        note: note,
      );

      if (!mounted) return;
      _showSnack('Request created successfully');
      setState(() => _currentIndex = 1);
    } catch (e) {
      _showSnack('Failed to create request: $e', error: true);
    } finally {
      if (mounted) {
        setState(() => _creatingRequest = false);
      }
    }
  }

  Future<void> _openRequestDialog([String? preset]) async {
    if (_creatingRequest) return;

    final result = await showModalBottomSheet<_RequestSheetResult>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _RequestSheet(
        preset: preset,
        categories: kServiceCategories,
      ),
    );

    if (result == null) return;

    await _createRequest(
      serviceType: result.serviceType,
      fare: result.fare,
      note: result.note,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please sign in first')),
      );
    }

    final appState = AppStateScope.of(context);

    final pages = <Widget>[
      _CustomerHomeTab(
        user: user,
        position: _position,
        loadingLocation: _loadingLocation,
        onRefreshLocation: _loadLocation,
        onBookNow: _openRequestDialog,
      ),
      _CustomerRequestsTab(
        userId: user.uid,
        customerPosition: _position,
        onBookAnother: _openRequestDialog,
      ),
      MapScreen(
        customerLat: _position?.latitude,
        customerLng: _position?.longitude,
      ),
      SettingsScreen(
        isEmployee: false,
        currentTheme: _themeToString(appState.themeMode),
        currentLanguage: appState.locale.languageCode,
      ),
    ];

    return Scaffold(
      backgroundColor: scheme.surface,
      drawer: Drawer(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(right: Radius.circular(24)),
        ),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: scheme.primary),
              accountName: Text(user.displayName ?? 'Customer'),
              accountEmail: Text(user.email ?? ''),
              currentAccountPicture: CircleAvatar(
                backgroundColor: scheme.onPrimary,
                child: Text(
                  (user.displayName?.isNotEmpty == true
                          ? user.displayName![0]
                          : 'C')
                      .toUpperCase(),
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: scheme.primary,
                  ),
                ),
              ),
            ),
            _DrawerTile(
              icon: Icons.home_outlined,
              title: 'Home',
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 0);
              },
            ),
            _DrawerTile(
              icon: Icons.receipt_long_outlined,
              title: 'My Requests',
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 1);
              },
            ),
            _DrawerTile(
              icon: Icons.map_outlined,
              title: 'Map',
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 2);
              },
            ),
            _DrawerTile(
              icon: Icons.settings_outlined,
              title: 'Settings',
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 3);
              },
            ),
            const Divider(),
            _DrawerTile(
              icon: Icons.add_circle_outline,
              title: 'New Request',
              onTap: () async {
                Navigator.pop(context);
                await _openRequestDialog();
              },
            ),
            _DrawerTile(
              icon: Icons.logout,
              title: 'Logout',
              iconColor: scheme.error,
              textColor: scheme.error,
              onTap: () async {
                Navigator.pop(context);
                await SessionUtils.logout(context);
              },
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: IndexedStack(
          index: _currentIndex,
          children: pages,
        ),
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _creatingRequest ? null : () => _openRequestDialog(),
              icon: _creatingRequest
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.add),
              label: Text(_creatingRequest ? 'Creating...' : 'Book now'),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() => _currentIndex = index);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            label: 'Requests',
          ),
          NavigationDestination(
            icon: Icon(Icons.map_outlined),
            label: 'Map',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class _RequestSheetResult {
  final String serviceType;
  final double fare;
  final String? note;

  const _RequestSheetResult({
    required this.serviceType,
    required this.fare,
    required this.note,
  });
}

class _RequestSheet extends StatefulWidget {
  final String? preset;
  final List<Map<String, String>> categories;

  const _RequestSheet({
    required this.preset,
    required this.categories,
  });

  @override
  State<_RequestSheet> createState() => _RequestSheetState();
}

class _RequestSheetState extends State<_RequestSheet> {
  late final TextEditingController _fareController;
  late final TextEditingController _noteController;
  late String _selected;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _fareController = TextEditingController();
    _noteController = TextEditingController();
    _selected = widget.preset ?? widget.categories.first['key']!;
  }

  @override
  void dispose() {
    _fareController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  InputDecoration _inputDecoration(
    BuildContext context, {
    required String label,
    String? prefixText,
  }) {
    final scheme = Theme.of(context).colorScheme;

    return InputDecoration(
      labelText: label,
      prefixText: prefixText,
      filled: true,
      fillColor: scheme.surfaceContainerHighest,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
    );
  }

  void _submit() {
    final fare = double.tryParse(_fareController.text.trim());

    if (fare == null || fare <= 0) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(
            content: Text('Enter a valid fare amount'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      return;
    }

    setState(() => _submitting = true);

    Navigator.of(context).pop(
      _RequestSheetResult(
        serviceType: _selected,
        fare: fare,
        note: _noteController.text.trim().isEmpty
            ? null
            : _noteController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return AnimatedPadding(
      duration: const Duration(milliseconds: 180),
      padding: EdgeInsets.only(bottom: bottomInset),
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 42,
                height: 5,
                decoration: BoxDecoration(
                  color: scheme.outlineVariant,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
              const SizedBox(height: 14),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Book a service',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selected,
                decoration: _inputDecoration(
                  context,
                  label: 'Service category',
                ),
                items: widget.categories
                    .map(
                      (item) => DropdownMenuItem<String>(
                        value: item['key'],
                        child: Text('${item['emoji']} ${item['key']}'),
                      ),
                    )
                    .toList(),
                onChanged: _submitting
                    ? null
                    : (value) {
                        if (value != null) {
                          setState(() => _selected = value);
                        }
                      },
              ),
              const SizedBox(height: 12),
              TextField(
                key: const ValueKey('request_fare_input'),
                controller: _fareController,
                enabled: !_submitting,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: _inputDecoration(
                  context,
                  label: 'Your budget / fare offer',
                  prefixText: 'OMR ',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                key: const ValueKey('request_note_input'),
                controller: _noteController,
                enabled: !_submitting,
                maxLines: 3,
                decoration: _inputDecoration(
                  context,
                  label: 'Describe the issue',
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: _submitting ? null : _submit,
                  icon: _submitting
                      ? SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: scheme.onPrimary,
                          ),
                        )
                      : const Icon(Icons.handyman_outlined),
                  label: Text(_submitting ? 'Sending...' : 'Confirm request'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CustomerHomeTab extends StatelessWidget {
  final User user;
  final Position? position;
  final bool loadingLocation;
  final Future<void> Function() onRefreshLocation;
  final Future<void> Function([String? preset]) onBookNow;

  const _CustomerHomeTab({
    required this.user,
    required this.position,
    required this.loadingLocation,
    required this.onRefreshLocation,
    required this.onBookNow,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return RefreshIndicator(
      onRefresh: onRefreshLocation,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [scheme.primary, scheme.primaryContainer],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: scheme.shadow.withOpacity(0.16),
                  blurRadius: 18,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Hi, ${user.displayName ?? 'Customer'} 👋',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    color: scheme.onPrimary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  user.email ?? '',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: scheme.onPrimary.withOpacity(0.85),
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: scheme.onPrimary.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.my_location, color: scheme.onPrimary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          loadingLocation
                              ? 'Detecting your location...'
                              : position == null
                                  ? 'Location unavailable'
                                  : 'Lat ${position!.latitude.toStringAsFixed(5)}, '
                                      'Lng ${position!.longitude.toStringAsFixed(5)}',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: scheme.onPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Choose a service',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            itemCount: kServiceCategories.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisExtent: 112,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemBuilder: (context, index) {
              final item = kServiceCategories[index];

              return InkWell(
                borderRadius: BorderRadius.circular(22),
                onTap: () => onBookNow(item['key']),
                child: Ink(
                  decoration: BoxDecoration(
                    color: scheme.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: scheme.shadow.withOpacity(0.08),
                        blurRadius: 14,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Text(
                          item['emoji']!,
                          style: const TextStyle(fontSize: 30),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            item['key']!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 16,
                          color: scheme.onSurfaceVariant,
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: onRefreshLocation,
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh location'),
          ),
        ],
      ),
    );
  }
}

class _CustomerRequestsTab extends StatelessWidget {
  final String userId;
  final Position? customerPosition;
  final Future<void> Function([String? preset]) onBookAnother;

  const _CustomerRequestsTab({
    required this.userId,
    required this.customerPosition,
    required this.onBookAnother,
  });

  String _providerNameFrom(ServiceRequestModel req) {
    if (req.assignedWorkerName.trim().isNotEmpty) {
      return req.assignedWorkerName;
    }
    return 'Waiting for provider';
  }

  String _statusLabel(String raw) {
    if (raw.trim().isEmpty) return 'pending';
    return raw.replaceAll('_', ' ');
  }

  Color _statusColor(BuildContext context, String raw) {
    final scheme = Theme.of(context).colorScheme;

    switch (raw.toLowerCase()) {
      case 'accepted':
      case 'assigned':
      case 'ongoing':
      case 'in_progress':
        return scheme.primary;
      case 'cancelled':
      case 'rejected':
        return scheme.error;
      case 'completed':
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  bool _canCancel(String status) {
    final s = status.toLowerCase();
    return s != 'completed' && s != 'cancelled';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.customerRequestsStream(userId),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (snapshot.connectionState == ConnectionState.waiting &&
            !snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final requests = snapshot.data ?? [];

        if (requests.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.receipt_long_outlined,
                    size: 56,
                    color: scheme.onSurfaceVariant,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No requests yet',
                    style: theme.textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Book your first service and nearby providers will start bidding.',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () => onBookAnother(),
                    icon: const Icon(Icons.add),
                    label: const Text('Book now'),
                  ),
                ],
              ),
            ),
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 110),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final req = requests[index];
            final providerName = _providerNameFrom(req);
            final status = _statusLabel(req.status);
            final statusColor = _statusColor(context, req.status);
            final fare = req.priceOffer ?? 0.0;
            final liveNote = (req.note ?? '').trim();
            final assignedWorkerId = req.assignedWorkerId.trim();

            final hasTrackingTarget =
                assignedWorkerId.isNotEmpty && customerPosition != null;

            return Container(
              decoration: BoxDecoration(
                color: scheme.surfaceContainerLow,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: scheme.shadow.withOpacity(0.08),
                    blurRadius: 14,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            req.serviceType.isEmpty
                                ? 'Service request'
                                : req.serviceType,
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            status,
                            style: theme.textTheme.labelLarge?.copyWith(
                              color: statusColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    _InfoRow(
                      icon: Icons.person_outline,
                      text: providerName,
                    ),
                    const SizedBox(height: 8),
                    _InfoRow(
                      icon: Icons.attach_money,
                      text: 'OMR ${fare.toStringAsFixed(2)}',
                    ),
                    if (liveNote.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      _InfoRow(
                        icon: Icons.notes_outlined,
                        text: liveNote,
                      ),
                    ],
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        if (hasTrackingTarget)
                          OutlinedButton.icon(
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => MapScreen
                                  (
                                    requestId: req.id,
                                    providerId: assignedWorkerId,
                                    customerLat: customerPosition!.latitude,
                                    customerLng: customerPosition!.longitude,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.map_outlined),
                            label: const Text('Track'),
                          ),
                        if (assignedWorkerId.isNotEmpty)
                          OutlinedButton.icon(
                            onPressed: () {
                              final me = FirebaseAuth.instance.currentUser?.uid;
                              if (me == null) return;

                              final chatId =
                                  ChatService.pairId(me, assignedWorkerId);

                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    chatId: chatId,
                                    otherUserId: assignedWorkerId,
                                    title: providerName,
                                    requestId: req.id,
                                    iAmCustomer: true,
                                    providerId: assignedWorkerId,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.chat_bubble_outline),
                            label: const Text('Chat'),
                          ),
                        if (_canCancel(req.status))
                          FilledButton(
                            style: FilledButton.styleFrom(
                              backgroundColor: scheme.error,
                              foregroundColor: scheme.onError,
                            ),
                            onPressed: () async {
                              try {
                                await RequestService.cancelRequest(req.id);
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context)
                                    ..hideCurrentSnackBar()
                                    ..showSnackBar(
                                      const SnackBar(
                                        content: Text('Request cancelled'),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                }
                              } catch (e) {
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context)
                                    ..hideCurrentSnackBar()
                                    ..showSnackBar(
                                      SnackBar(
                                        content: Text('Cancel failed: $e'),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                }
                              }
                            },
                            child: const Text('Cancel'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _DrawerTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Color? iconColor;
  final Color? textColor;

  const _DrawerTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.iconColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: iconColor),
      title: Text(
        title,
        style: TextStyle(color: textColor),
      ),
      onTap: onTap,
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _InfoRow({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 18,
          color: scheme.onSurfaceVariant,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: textTheme.bodyMedium?.copyWith(
              color: scheme.onSurface,
            ),
          ),
        ),
      ],
    );
  }
}