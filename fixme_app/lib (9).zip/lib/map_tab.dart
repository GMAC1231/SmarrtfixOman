import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

class MapTab extends StatefulWidget {
  final String? requestId;
  final String? providerId;
  final double? customerLat;
  final double? customerLng;

  const MapTab({
    super.key,
    this.requestId,
    this.providerId,
    this.customerLat,
    this.customerLng,
  });

  @override
  State<MapTab> createState() => MapTabState();
}

class MapTabState extends State<MapTab> {
  final MapController _mapController = MapController();

  LatLng? _driver;
  LatLng? _customer;
  List<LatLng> _route = [];

  String _eta = '--';
  String _distance = '--';

  StreamSubscription? _driverSub;
  Timer? _routeTimer;

  @override
  void initState() {
    super.initState();
    _initCustomer();
    _listenDriver();
  }

  @override
  void dispose() {
    _driverSub?.cancel();
    _routeTimer?.cancel();
    super.dispose();
  }

  void _initCustomer() {
    if (widget.customerLat != null && widget.customerLng != null) {
      _customer = LatLng(widget.customerLat!, widget.customerLng!);
    }
  }

  /// 🔥 REAL-TIME DRIVER TRACKING
  void _listenDriver() {
    if (widget.providerId == null) return;

    _driverSub = FirebaseFirestore.instance
        .collection('users')
        .doc(widget.providerId)
        .snapshots()
        .listen((doc) {
      final data = doc.data();
      if (data == null) return;

      final lat = data['liveLat'];
      final lng = data['liveLng'];

      if (lat is num && lng is num) {
        final newPos = LatLng(lat.toDouble(), lng.toDouble());

        if (_driver == null) {
          _driver = newPos;
        } else {
          /// 🔥 SMOOTH ANIMATION
          _driver = LatLng(
            _driver!.latitude + (newPos.latitude - _driver!.latitude) * 0.2,
            _driver!.longitude + (newPos.longitude - _driver!.longitude) * 0.2,
          );
        }

        if (mounted) setState(() {});
        _updateRoute();
      }
    });
  }

  // ✅ FIX: compatibility methods
Future<void> centerToEmployee() async {
  if (_driver != null) {
    _mapController.move(_driver!, 16);
  }
}

Future<void> setCustomerLocation(LatLng point) async {
  setState(() {
    _customer = point;
  });
  await _updateRoute();
}

  /// 🔥 ROUTE + ETA
  Future<void> _updateRoute() async {
    if (_driver == null || _customer == null) return;

    final url = Uri.parse(
      'https://router.project-osrm.org/route/v1/driving/'
      '${_driver!.longitude},${_driver!.latitude};'
      '${_customer!.longitude},${_customer!.latitude}'
      '?overview=full&geometries=geojson',
    );

    final res = await http.get(url);
    if (res.statusCode != 200) return;

    final data = jsonDecode(res.body);
    final route = data['routes'][0];

    final coords = route['geometry']['coordinates'];

    final points = coords.map<LatLng>((c) {
      return LatLng(c[1], c[0]);
    }).toList();

    final distKm = route['distance'] / 1000;
    final durationMin = (route['duration'] / 60).round();

    if (!mounted) return;

    setState(() {
      _route = List<LatLng>.from(points);
      _distance = '${distKm.toStringAsFixed(1)} km';
      _eta = '$durationMin min';
    });

    _fit();
  }

  void _fit() {
    if (_route.isEmpty) return;

    final bounds = LatLngBounds.fromPoints(_route);

    _mapController.fitCamera(
      CameraFit.bounds(
        bounds: bounds,
        padding: const EdgeInsets.all(80),
      ),
    );
  }

  /// 🔥 BUTTONS
  void _recenter() {
    if (_driver != null) {
      _mapController.move(_driver!, 16);
    }
  }

  void _fitAll() {
    _fit();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        /// 🔥 MAP
        FlutterMap(
          mapController: _mapController,
          options: const MapOptions(
            initialCenter: LatLng(23.5880, 58.3829),
            initialZoom: 14,
          ),
          children: [
            TileLayer(
              urlTemplate:
                  'https://api.maptiler.com/maps/streets/{z}/{x}/{y}.png?key=YOUR_KEY',
            ),

            /// ROUTE
            if (_route.isNotEmpty)
              PolylineLayer(
                polylines: [
                  Polyline(
                    points: _route,
                    strokeWidth: 6,
                    color: Colors.greenAccent,
                  ),
                ],
              ),

            /// DRIVER
            if (_driver != null)
              MarkerLayer(
                markers: [
                  Marker(
                    point: _driver!,
                    width: 70,
                    height: 70,
                    child: const Icon(Icons.local_taxi,
                        size: 36, color: Colors.black),
                  ),
                ],
              ),

            /// CUSTOMER
            if (_customer != null)
              MarkerLayer(
                markers: [
                  Marker(
                    point: _customer!,
                    width: 60,
                    height: 60,
                    child: const Icon(Icons.location_on,
                        size: 36, color: Colors.red),
                  ),
                ],
              ),
          ],
        ),

        /// 🔥 CONTROL BUTTONS
        Positioned(
          right: 15,
          top: 20,
          child: Column(
            children: [
              _btn(Icons.my_location, _recenter),
              const SizedBox(height: 10),
              _btn(Icons.fit_screen, _fitAll),
            ],
          ),
        ),

        /// 🔥 DRIVER CARD
        Positioned(
          bottom: 120,
          left: 16,
          right: 16,
          child: _driverCard(),
        ),

        /// 🔥 ETA CARD
        Positioned(
          bottom: 20,
          left: 16,
          right: 16,
          child: _etaCard(),
        ),
      ],
    );
  }

  Widget _btn(IconData icon, VoidCallback onTap) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 4,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 50,
          height: 50,
          child: Icon(icon),
        ),
      ),
    );
  }

  /// 🔥 DRIVER INFO UI
  Widget _driverCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: const [
          CircleAvatar(
            radius: 22,
            child: Icon(Icons.person),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              "Driver is on the way 🚗",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  /// 🔥 ETA CARD
  Widget _etaCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Expanded(child: _metric("ETA", _eta)),
          Expanded(child: _metric("Distance", _distance)),
        ],
      ),
    );
  }

  Widget _metric(String title, String value) {
    return Column(
      children: [
        Text(title, style: const TextStyle(color: Colors.white54)),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.bold)),
      ],
    );
  }
}