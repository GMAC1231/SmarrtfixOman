import 'dart:async';
import 'dart:convert';
import 'dart:developer' as dev;

import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geoflutterfire_plus/geoflutterfire_plus.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'chat_screen.dart';
import 'settings_screen.dart';
import 'shared/services/chat_services.dart';
import 'session_utils.dart';

void _elog(String msg, [Object? err, StackTrace? st]) {
  dev.log(msg, name: 'CustomerDashboard', error: err, stackTrace: st);
}

const _brand = Color(0xFF01411C);
const String kBackendBase = 'http://192.168.100.15:5000';

const List<Map<String, String>> _serviceCategories = [
  {'key': 'Technician', 'emoji': '🔧'},
  {'key': 'Plumber', 'emoji': '🚰'},
  {'key': 'Electrician', 'emoji': '💡'},
  {'key': 'Carpenter', 'emoji': '🪚'},
  {'key': 'Painter', 'emoji': '🎨'},
  {'key': 'Handyman', 'emoji': '🛠'},
];

class CustomerDashboardScreen extends StatefulWidget {
  const CustomerDashboardScreen({super.key});

  @override
  State<CustomerDashboardScreen> createState() =>
      _CustomerDashboardScreenState();
}

class _CustomerDashboardScreenState extends State<CustomerDashboardScreen>
    with SingleTickerProviderStateMixin {
  final osm.MapController _map =
      osm.MapController(initMapWithUserPosition: const osm.UserTrackingOption());

  final FlutterLocalNotificationsPlugin _localNotif =
      FlutterLocalNotificationsPlugin();

  final Completer<void> _mapReadyOnce = Completer<void>();

  bool _mapReady = false;
  Position? _myPos;
  String? _address;

  osm.GeoPoint? _providerPoint;
  osm.GeoPoint? _selfPoint;
  List<osm.GeoPoint>? _activeRoute;

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _initLocation();
    _initNotifications();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _initLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) return;

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }

    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return;
    }

    try {
      _myPos = await Geolocator.getCurrentPosition();
      _selfPoint = osm.GeoPoint(
        latitude: _myPos!.latitude,
        longitude: _myPos!.longitude,
      );

      final placemarks =
          await placemarkFromCoordinates(_myPos!.latitude, _myPos!.longitude);

      if (placemarks.isNotEmpty) {
        final p = placemarks.first;
        setState(() => _address = "📍 ${p.street}, ${p.locality}");
      }
    } catch (e, s) {
      _elog('initLocation', e, s);
    }
  }

  Future<void> _initNotifications() async {
    await FirebaseMessaging.instance.requestPermission();

    const androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();

    const initSettings = InitializationSettings(
      android: androidInit,
      iOS: iosInit,
    );

    await _localNotif.initialize(initSettings);

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final notif = message.notification;
      if (notif != null) {
        _showLocalNotif(notif.title ?? "New Offer", notif.body ?? "");
      }
    });
  }

  Future<void> _showLocalNotif(String title, String body) async {
    const androidDetails = AndroidNotificationDetails(
      'offers_channel',
      'Provider Offers',
      channelDescription: 'Notifications for provider offers',
      importance: Importance.high,
      priority: Priority.high,
    );

    const details = NotificationDetails(android: androidDetails);

    final id = DateTime.now().millisecondsSinceEpoch.remainder(100000);

    await _localNotif.show(id, title, body, details);
  }

  Future<void> _sendRequest(String serviceType, double priceOffer) async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) return;

    try {
      final docRef = firestore.FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc();

      await docRef.set({
        'customerId': me.uid,
        'customerName': me.displayName ?? me.email,
        'customerEmail': me.email,
        'customerPhone': me.phoneNumber,
        'serviceType': serviceType,
        'priceOffer': priceOffer,
        'status': 'bidding',
        'location': {
          'lat': _myPos?.latitude,
          'lng': _myPos?.longitude,
          'address': _address,
        },
        'createdAt': firestore.FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("✅ $serviceType request sent")),
      );
    } catch (e, s) {
      _elog('sendRequest', e, s);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Failed to send request: $e")),
      );
    }
  }

  Future<void> publishUserLocation(String uid, double lat, double lng) async {
    final geo = GeoFirePoint(firestore.GeoPoint(lat, lng));

    await firestore.FirebaseFirestore.instance
        .collection('liveLocations')
        .doc(uid)
        .set({
      'position': geo.data,
      'lat': lat,
      'lng': lng,
      'ts': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  Stream<List<Map<String, dynamic>>> queryNearbyProviders(
      double lat, double lng, double radiusKm) {
    final center = GeoFirePoint(firestore.GeoPoint(lat, lng));

    return GeoCollectionReference<Map<String, dynamic>>(
      firestore.FirebaseFirestore.instance.collection('liveLocations'),
    )
        .subscribeWithin(
          center: center,
          radiusInKm: radiusKm,
          field: 'position',
          strictMode: true,
          geopointFrom: (Map<String, Object?> map) {
            final gp = map['geopoint'];
            if (gp is firestore.GeoPoint) return gp;
            return const firestore.GeoPoint(0, 0);
          },
        )
        .map((snapshots) {
          return snapshots.map((doc) {
            final d = doc.data();
            return {
              'id': doc.id,
              'lat': d?['lat'],
              'lng': d?['lng'],
              ...?d,
            };
          }).toList();
        });
  }

  Future<void> _openRequestDialog() async {
    String? selectedService;
    final ctrl = TextEditingController();

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setStateDialog) => AlertDialog(
          title: const Text("Request a Service"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: selectedService,
                decoration: const InputDecoration(labelText: "Select Service"),
                items: _serviceCategories.map((c) {
                  return DropdownMenuItem(
                    value: c['key'],
                    child: Text("${c['emoji']} ${c['key']}"),
                  );
                }).toList(),
                onChanged: (v) => setStateDialog(() => selectedService = v),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Price Offer (PKR)",
                  prefixText: "💲 ",
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                final val = double.tryParse(ctrl.text.trim());
                if (selectedService != null && val != null) {
                  Navigator.pop(ctx);
                  _sendRequest(selectedService!, val);
                }
              },
              child: const Text("Send"),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectProvider(
      String requestId, String providerId, double fare) async {
    try {
      final empDoc = await firestore.FirebaseFirestore.instance
          .collection('publicUsers')
          .doc(providerId)
          .get();

      final empData = empDoc.data() ?? {};

      await firestore.FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(requestId)
          .update({
        'status': 'accepted',
        'employeeId': providerId,
        'acceptedFare': fare,
        'acceptedAt': firestore.FieldValue.serverTimestamp(),
        'employeeName': empData['name'] ?? '',
        'employeeEmail': empData['email'] ?? '',
        'employeePhone': empData['phone'] ?? '',
        'employeeProfession': empData['profession'] ?? '',
        'employeePhotoUrl': empData['photoUrl'] ?? '',
      });

      _listenProviderLocation(providerId);
    } catch (e, s) {
      _elog('selectProvider', e, s);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Could not select provider: $e")),
      );
    }
  }

  Future<void> submitOffer(
      String requestId, double fare, int etaSec, double distance) async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) return;

    final userDoc = await firestore.FirebaseFirestore.instance
        .collection('publicUsers')
        .doc(me.uid)
        .get();

    final userData = userDoc.data() ?? {};
    final name = userData['name'] ?? 'Unknown';
    final phone = userData['phone'] ?? 'N/A';
    final rating = (userData['rating'] ?? 4.5).toDouble();

    await firestore.FirebaseFirestore.instance
        .collection('bids')
        .doc(requestId)
        .collection('offers')
        .doc(me.uid)
        .set({
      'requestId': requestId,
      'employeeId': me.uid,
      'employeeName': name,
      'employeePhone': phone,
      'etaSec': etaSec,
      'proposedFare': fare,
      'rating': rating,
      'distanceKm': distance,
      'createdAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));
  }

  Future<void> _showRatingDialog(String providerId, String requestId) async {
    double rating = 3;

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Rate your provider"),
        content: StatefulBuilder(
          builder: (ctx, setStateDialog) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Slider(
                value: rating,
                min: 1,
                max: 5,
                divisions: 4,
                label: rating.toString(),
                onChanged: (val) => setStateDialog(() => rating = val),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              final uid = FirebaseAuth.instance.currentUser?.uid;
              if (uid != null) {
                await firestore.FirebaseFirestore.instance.collection('ratings').add({
                  'providerId': providerId,
                  'customerId': uid,
                  'requestId': requestId,
                  'rating': rating,
                  'createdAt': firestore.FieldValue.serverTimestamp(),
                });
              }
              if (context.mounted) Navigator.pop(ctx);
            },
            child: const Text("Submit"),
          ),
        ],
      ),
    );
  }

  List<osm.GeoPoint> _decodePolylineGeo(String poly) {
    final pts = <osm.GeoPoint>[];
    int index = 0, lat = 0, lng = 0;

    while (index < poly.length) {
      int b, shift = 0, result = 0;
      do {
        b = poly.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      lat += (result & 1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        b = poly.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      lng += (result & 1) != 0 ? ~(result >> 1) : (result >> 1);

      pts.add(osm.GeoPoint(latitude: lat / 1e5, longitude: lng / 1e5));
    }

    return pts;
  }

  Future<List<osm.GeoPoint>?> _fetchRoute(
      osm.GeoPoint from, osm.GeoPoint to) async {
    final url = Uri.parse(
      '$kBackendBase/route?from=${from.latitude},${from.longitude}&to=${to.latitude},${to.longitude}',
    );

    try {
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;

      final body = jsonDecode(res.body) as Map<String, dynamic>;
      final poly = body['polyline'] as String?;
      if (poly == null) return null;

      return _decodePolylineGeo(poly);
    } catch (e, s) {
      _elog('fetchRoute failed', e, s);
      return null;
    }
  }

  Future<void> _drawRouteToProvider() async {
    if (_selfPoint == null || _providerPoint == null) return;

    try {
      final poly = await _fetchRoute(_selfPoint!, _providerPoint!);
      if (poly != null && poly.length > 1) {
        _activeRoute = poly;
        await _map.drawRoad(
          poly.first,
          poly.last,
          roadOption: const osm.RoadOption(
            roadColor: Colors.greenAccent,
            roadWidth: 10,
          ),
        );
      }
    } catch (e, s) {
      _elog('drawRouteToProvider error', e, s);
    }
  }

  void _listenProviderLocation(String providerId) {
    firestore.FirebaseFirestore.instance
        .collection('liveLocations')
        .doc(providerId)
        .snapshots()
        .listen((snap) async {
      final data = snap.data();
      if (data == null) return;

      final lat = (data['lat'] as num?)?.toDouble();
      final lng = (data['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) return;

      _providerPoint = osm.GeoPoint(latitude: lat, longitude: lng);

      if (_mapReady) {
        await _map.addMarker(_providerPoint!);
        await _drawRouteToProvider();
      }

      if (mounted) setState(() {});
    });
  }

  Future<void> _openChat(String requestId, String providerId) async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) return;

    try {
      final chatId = await ChatService.ensureChat(
        customerId: me.uid,
        employeeId: providerId,
        requestId: requestId,
      );

      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChatScreen(
            chatId: chatId,
            otherUserId: providerId,
            title: "Chat with Provider",
            requestId: requestId,
            iAmCustomer: true,
            providerId: providerId,
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Could not open chat: $e")),
      );
    }
  }

  Widget _buildMapTab() {
    return Stack(
      children: [
        Positioned.fill(
          child: osm.OSMFlutter(
            controller: _map,
            osmOption: const osm.OSMOption(
              zoomOption: osm.ZoomOption(initZoom: 15),
              showZoomController: true,
            ),
            onMapIsReady: (ready) async {
              if (ready && !_mapReadyOnce.isCompleted) {
                _mapReady = true;
                _mapReadyOnce.complete();
              }

              if (_selfPoint != null) {
                await _map.addMarker(_selfPoint!);
                await _map.goToLocation(_selfPoint!);
              }

              if (_providerPoint != null) {
                await _map.addMarker(_providerPoint!);
                await _drawRouteToProvider();
              }
            },
          ),
        ),
        if (_activeRoute != null)
          Positioned(
            left: 10,
            top: 10,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                "🟢 Route Active",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildRequestCard(String id, Map<String, dynamic> data) {
    final service = data['serviceType'] ?? 'Service';
    final addr =
        ((data['location'] as Map<String, dynamic>?)?['address'] as String?) ??
            '';
    final status = data['status'];

    return Card(
      margin: const EdgeInsets.all(8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "📌 $service (${status.toString().toUpperCase()})",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            if (addr.isNotEmpty)
              Text(
                "📍 $addr",
                style: const TextStyle(color: Colors.black54),
              ),
            const SizedBox(height: 8),
            if (status == 'bidding') _buildOffersList(id, data, status),
            if (status == 'accepted') _buildProviderDetails(id, data),
            if (status == 'completed') _buildCompletedSection(id, data),
            if (status == 'cancelled') _buildCancelledSection(),
            if (status == 'bidding') _buildCancelButton(id),
          ],
        ),
      ),
    );
  }

  Widget _buildProviderDetails(String id, Map<String, dynamic> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(),
        const Text(
          "👷 Provider Details",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(data['employeeName'] ?? "Unknown"),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("📞 ${data['employeePhone'] ?? 'N/A'}"),
              Text("💲 ${data['acceptedFare'] ?? 'N/A'} PKR"),
              Text("⏱ ${(data['employeeEta'] ?? 0)} min"),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            OutlinedButton.icon(
              onPressed: () => _openChat(id, data['employeeId']),
              icon: const Icon(Icons.chat),
              label: const Text("Chat"),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: () async {
                final phone = data['employeePhone'];
                if (phone != null && phone.toString().isNotEmpty) {
                  final uri = Uri.parse("tel:$phone");
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri);
                  }
                }
              },
              icon: const Icon(Icons.phone),
              label: const Text("Call"),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildOffersList(String id, Map<String, dynamic> data, String status) {
    return StreamBuilder<firestore.QuerySnapshot>(
      stream: firestore.FirebaseFirestore.instance
          .collection('bids')
          .doc(id)
          .collection('offers')
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(strokeWidth: 2));
        }

        if (!snap.hasData || snap.data!.docs.isEmpty) {
          return const Center(child: Text("📭 No offers yet"));
        }

        final offers = snap.data!.docs;
        final activeOffers = offers.where((doc) {
          final od = doc.data() as Map<String, dynamic>;
          return (od['status'] ?? 'active') != 'declined';
        }).toList();

        if (activeOffers.isEmpty) {
          return const Center(child: Text("📭 No active offers"));
        }

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: activeOffers.length,
          itemBuilder: (context, i) {
            final od = activeOffers[i].data() as Map<String, dynamic>;
            final provId = activeOffers[i].id;

            final fare = (od['proposedFare'] ?? 0).toDouble();
            final eta = (od['etaSec'] ?? 0) ~/ 60;
            final rating = (od['rating'] ?? 4.5).toDouble();

            return FutureBuilder<firestore.DocumentSnapshot>(
              future: firestore.FirebaseFirestore.instance
                  .collection('publicUsers')
                  .doc(provId)
                  .get(),
              builder: (context, empSnap) {
                if (!empSnap.hasData) {
                  return const ListTile(
                    leading: CircleAvatar(child: Icon(Icons.person)),
                    title: Text("Loading..."),
                  );
                }

                final empData =
                    empSnap.data?.data() as Map<String, dynamic>? ?? {};
                final name = empData['name'] ?? "Unknown";
                final phone = empData['phone'] ?? "N/A";

                return Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const CircleAvatar(child: Icon(Icons.person)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "👷 $name",
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                    ),
                                  ),
                                  Text("📞 $phone"),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text("💲 $fare PKR"),
                        Text("⏱ $eta min • ⭐ $rating"),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton(
                              onPressed: () =>
                                  _selectProvider(id, provId, fare),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                              ),
                              child: const Text("Select"),
                            ),
                            const SizedBox(width: 8),
                            OutlinedButton(
                              onPressed: () async {
                                try {
                                  await firestore.FirebaseFirestore.instance
                                      .collection('bids')
                                      .doc(id)
                                      .collection('offers')
                                      .doc(provId)
                                      .update({'status': 'declined'});

                                  if (!context.mounted) return;
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text("✅ Offer declined"),
                                    ),
                                  );
                                } catch (e) {
                                  if (!context.mounted) return;
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content:
                                          Text("❌ Failed to decline: $e"),
                                    ),
                                  );
                                }
                              },
                              style: OutlinedButton.styleFrom(
                                foregroundColor: Colors.red,
                                side: const BorderSide(color: Colors.red),
                              ),
                              child: const Text("Decline"),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildCompletedSection(String id, Map<String, dynamic> data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("✅ Completed at: ${data['completedAt'] ?? ''}"),
        const SizedBox(height: 6),
        ElevatedButton.icon(
          onPressed: () => _showRatingDialog(data['employeeId'] ?? '', id),
          icon: const Icon(Icons.star, color: Colors.white),
          label: const Text("Rate Provider"),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
        ),
      ],
    );
  }

  Widget _buildCancelledSection() {
    return const Text(
      "❌ Request cancelled",
      style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600),
    );
  }

  Widget _buildCancelButton(String id) {
    return Align(
      alignment: Alignment.centerRight,
      child: TextButton.icon(
        onPressed: () async {
          await firestore.FirebaseFirestore.instance
              .collection('serviceRequests')
              .doc(id)
              .update({'status': 'cancelled'});
        },
        icon: const Icon(Icons.cancel, color: Colors.red),
        label: const Text("Cancel"),
      ),
    );
  }

  Widget _buildRequestsList(String? uid, List<String> statuses) {
    if (uid == null) {
      return const Center(child: Text("Not logged in"));
    }

    return StreamBuilder<firestore.QuerySnapshot>(
      stream: firestore.FirebaseFirestore.instance
          .collection('serviceRequests')
          .where('customerId', isEqualTo: uid)
          .where('status', whereIn: statuses)
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snap.data!.docs;
        if (docs.isEmpty) {
          return const Center(child: Text("📭 No requests"));
        }

        return ListView(
          children: docs.map((d) {
            final data = d.data() as Map<String, dynamic>;
            return _buildRequestCard(d.id, data);
          }).toList(),
        );
      },
    );
  }

  Widget _buildBottomNavItem(IconData icon, String label, int index) {
    final isSelected = _tabController.index == index;

    return InkWell(
      onTap: () {
        setState(() {
          _tabController.index = index;
        });
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: isSelected ? _brand : Colors.grey[500],
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight:
                  isSelected ? FontWeight.bold : FontWeight.normal,
              color: isSelected ? _brand : Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: TabBarView(
        controller: _tabController,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          _buildMapTab(),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: _buildRequestsList(uid, ['bidding', 'accepted']),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: _buildRequestsList(uid, ['completed', 'cancelled']),
          ),
          SettingsScreen(
            isEmployee: false,
            onThemeChanged: (mode) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Theme changed to ${mode.name}")),
              );
            },
            onLanguageChanged: (locale) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text("Language set: ${locale.languageCode}"),
                ),
              );
            },
            onRoleSwitch: (role) async {
              await SessionUtils.switchRole(context, targetRole: role);
            },
            onLogout: () async {
              await SessionUtils.logout(context);
            },
            currentTheme: '',
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(),
        notchMargin: 8.0,
        elevation: 8,
        child: SizedBox(
          height: 70,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildBottomNavItem(Icons.map, "Map", 0),
              _buildBottomNavItem(Icons.work, "Active", 1),
              const SizedBox(width: 48),
              _buildBottomNavItem(Icons.history, "History", 2),
              _buildBottomNavItem(Icons.settings, "Settings", 3),
            ],
          ),
        ),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton(
            backgroundColor: Colors.green.shade600,
            elevation: 6,
            onPressed: _openRequestDialog,
            child: const Icon(Icons.add, size: 32, color: Colors.white),
          ),
          const SizedBox(height: 4),
          const Text(
            "New Service",
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}