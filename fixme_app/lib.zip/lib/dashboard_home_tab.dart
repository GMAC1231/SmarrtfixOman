import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DashboardHomeTab extends StatelessWidget {
  final VoidCallback onRecenterMap;
  final VoidCallback onProfile;
  final VoidCallback onToggleOnline;
  final int activeJobs;
  final int completedJobs;
  final double earnings;
  final bool isOnline;

  const DashboardHomeTab({
    super.key,
    required this.onRecenterMap,
    required this.onProfile,
    required this.onToggleOnline,
    required this.activeJobs,
    required this.completedJobs,
    required this.earnings,
    required this.isOnline,
  });

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final userName = user?.displayName ?? user?.email?.split('@').first ?? 'Friend';

    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          Text(
            "👋 Welcome back, $userName!",
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),

          _buildStatsRow(),

          const SizedBox(height: 32),
          const Text(
            "Quick Actions",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),

          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _quickAction(
                context,
                icon: Icons.my_location,
                label: "Recenter Map",
                color: Colors.blue,
                onTap: onRecenterMap,
              ),
              _quickAction(
                context,
                icon: Icons.person,
                label: "Profile",
                color: Colors.green,
                onTap: onProfile,
              ),
              _quickAction(
                context,
                icon: isOnline ? Icons.toggle_on : Icons.toggle_off,
                label: isOnline ? "Go Offline" : "Go Online",
                color: Colors.teal,
                onTap: onToggleOnline,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(
      children: [
        _statCard("🧰 Active Jobs", activeJobs.toString()),
        _statCard("✅ Completed", completedJobs.toString()),
        _statCard("💰 Earnings", "\$${earnings.toStringAsFixed(2)}"),
      ],
    );
  }

  Widget _statCard(String title, String value) {
    return Expanded(
      child: Card(
        elevation: 2,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, color: Colors.black54),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quickAction(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 130,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(color: color, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
