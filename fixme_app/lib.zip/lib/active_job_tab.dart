import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ActiveJobTab extends StatelessWidget {
  final GlobalKey? mapTabKey;

  const ActiveJobTab({super.key, this.mapTabKey});

  Future<void> _updateStatus(
    BuildContext context,
    String requestId,
    String status,
  ) async {
    try {
      await FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(requestId)
          .update({
        'status': status,
        if (status == 'ongoing') 'startedAt': FieldValue.serverTimestamp(),
        if (status == 'completed') 'completedAt': FieldValue.serverTimestamp(),
      });

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Job marked as $status')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Center(child: Text('Please log in'));
    }

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('serviceRequests')

          /// ✅ FIXED FIELD NAME
          .where('employeeId', isEqualTo: user.uid)

          .where('status', whereIn: ['accepted', 'ongoing'])
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return const Center(child: Text('No active job'));
        }

        final doc = docs.first;
        final data = doc.data();

        /// 🔥 SAFE DATA EXTRACTION
        final status = data['status']?.toString() ?? 'unknown';
        final service = data['serviceType']?.toString() ?? 'Service';
        final customerName = data['customerName']?.toString() ?? 'Customer';
        final price = data['priceOffer'] ?? 0;

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Card(
            elevation: 6,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// SERVICE NAME
                  Text(
                    service,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  /// CUSTOMER INFO
                  Text('👤 $customerName'),
                  Text('💰 $price OMR'),
                  Text('📌 Status: $status'),

                  const SizedBox(height: 20),

                  /// BUTTONS
                  if (status == 'accepted')
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () =>
                            _updateStatus(context, doc.id, 'ongoing'),
                        child: const Text('Start Job'),
                      ),
                    ),

                  if (status == 'ongoing') ...[
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                        ),
                        onPressed: () =>
                            _updateStatus(context, doc.id, 'completed'),
                        child: const Text('Complete Job'),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}