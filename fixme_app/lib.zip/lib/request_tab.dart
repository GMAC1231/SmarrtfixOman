import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;
import 'package:firebase_auth/firebase_auth.dart';

import 'chat_screen.dart';
import 'map_tab.dart';

class EmployeeRequestsTab extends StatefulWidget {
  final GlobalKey<MapTabState> mapTabKey;

  const EmployeeRequestsTab({super.key, required this.mapTabKey});

  @override
  State<EmployeeRequestsTab> createState() => _EmployeeRequestsTabState();
}

class _EmployeeRequestsTabState extends State<EmployeeRequestsTab> {
  @override
  Widget build(BuildContext context) {
    final q = FirebaseFirestore.instance
        .collection('serviceRequests')
        .where('status', whereIn: ['bidding', 'pending'])
        .orderBy('createdAt', descending: true);

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: q.snapshots(),
      builder: (ctx, snap) {
        if (snap.hasError) {
          return Center(child: Text('Error: ${snap.error}'));
        }

        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snap.data!.docs;

        if (docs.isEmpty) {
          return const Center(child: Text('📭 No open requests'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: docs.length,
          itemBuilder: (context, i) {
            final reqDoc = docs[i];
            final id = reqDoc.id;
            final data = reqDoc.data();

            final customerName =
                (data['customerName'] ?? data['customerEmail'] ?? 'Customer')
                    .toString();
            final customerPhone = data['customerPhone']?.toString();
            final customerEmail = data['customerEmail']?.toString();
            final serviceType = (data['serviceType'] ?? '').toString();
            final priceOffer = data['priceOffer']?.toString() ?? '-';

            final location = data['location'];
            final addr = (location is Map && location['address'] != null)
                ? location['address'].toString()
                : '';

            osm.GeoPoint? gp;

            if (location is Map) {
              final geo = location['geopoint'];

              if (geo is GeoPoint) {
                gp = osm.GeoPoint(
                  latitude: geo.latitude,
                  longitude: geo.longitude,
                );
              } else if (geo is Map) {
                final lat = geo['lat'];
                final lng = geo['lng'];
                if (lat is num && lng is num) {
                  gp = osm.GeoPoint(
                    latitude: lat.toDouble(),
                    longitude: lng.toDouble(),
                  );
                }
              }
            }

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      serviceType.isEmpty ? 'Service Request' : serviceType,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text('👤 $customerName'),
                    if ((customerEmail ?? '').isNotEmpty)
                      Text('✉️ $customerEmail'),
                    if ((customerPhone ?? '').isNotEmpty)
                      Text('📞 $customerPhone'),
                    const SizedBox(height: 4),
                    Text('💲 Customer offer: $priceOffer'),
                    if (addr.isNotEmpty) Text('📍 $addr'),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        if (gp != null)
                          ElevatedButton.icon(
                            onPressed: () {
                              widget.mapTabKey.currentState
                                  ?.setCustomerLocation(gp!);
                            },
                            icon: const Icon(Icons.route),
                            label: const Text('Route'),
                          ),
                        ElevatedButton.icon(
                          onPressed: () => acceptRequest(id),
                          icon: const Icon(Icons.check_circle),
                          label: const Text('Accept'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => _rejectRequest(id),
                          icon: const Icon(Icons.cancel),
                          label: const Text('Reject'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.redAccent,
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => _showOfferDialog(id, gp),
                          icon: const Icon(Icons.local_offer),
                          label: const Text('Offer'),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => _openChat(
                            data['customerId']?.toString() ?? '',
                            id,
                            customerName,
                          ),
                          icon: const Icon(Icons.chat_bubble),
                          label: const Text('Chat'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> acceptRequest(String requestId) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    await FirebaseFirestore.instance
        .collection('serviceRequests')
        .doc(requestId)
        .update({
      'status': 'accepted',
      'employeeId': uid,
      'acceptedAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request accepted')),
      );
    }
  }

  Future<void> _rejectRequest(String requestId) async {
    try {
      await FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(requestId)
          .update({
        'status': 'rejected',
        'rejectedAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Request rejected')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to reject: $e')),
        );
      }
    }
  }

  Future<void> _showOfferDialog(String requestId, osm.GeoPoint? gp) async {
    final ctrl = TextEditingController();
    double? value;

    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Send your offer'),
        content: TextField(
          controller: ctrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Proposed fare',
            prefixText: '💲 ',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              value = double.tryParse(ctrl.text.trim());
              if (value != null) {
                Navigator.pop(context);
              }
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );

    if (value != null && gp != null) {
      widget.mapTabKey.currentState?.setCustomerLocation(gp);

      try {
        final me = FirebaseAuth.instance.currentUser;
        if (me != null) {
          await FirebaseFirestore.instance
              .collection('bids')
              .doc(requestId)
              .collection('offers')
              .doc(me.uid)
              .set({
            'proposedFare': value,
            'updatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));

          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('✅ Offer sent!')),
            );
          }
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('❌ Failed to send offer: $e')),
          );
        }
      }
    }
  }

  void _openChat(String customerId, String requestId, String title) {
    if (customerId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Customer ID missing')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          chatId: '$requestId-$customerId',
          otherUserId: customerId,
          title: title,
          requestId: requestId,
          iAmCustomer: false,
          providerId: '',
        ),
      ),
    );
  }
}