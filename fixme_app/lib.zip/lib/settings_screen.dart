import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:fixme_app/feedback_screen.dart';
import 'package:fixme_app/complete_profile_screen.dart';
import 'package:fixme_app/customer_dashboard.dart';
import 'package:fixme_app/employee_dashboard.dart';
import 'package:fixme_app/employee_registration.dart';

typedef ThemeChanged = void Function(ThemeMode mode);
typedef LanguageChanged = void Function(Locale locale);
typedef RoleSwitched = void Function(String newRole);
typedef LogoutRequested = Future<void> Function();

class SettingsScreen extends StatefulWidget {
  final bool isEmployee;
  final ThemeChanged? onThemeChanged;
  final LanguageChanged? onLanguageChanged;
  final RoleSwitched? onRoleSwitch;
  final LogoutRequested? onLogout;

  final bool autoLogout;
  final String? autoSwitchRole; // 'employee' or 'customer'

  const SettingsScreen({
    super.key,
    required this.isEmployee,
    this.onThemeChanged,
    this.onLanguageChanged,
    this.onRoleSwitch,
    this.onLogout,
    this.autoLogout = false,
    this.autoSwitchRole, required String currentTheme,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // ── SharedPreferences keys
  static const _kTheme = 'pref_theme';
  static const _kLang = 'pref_lang';
  static const _kNotif = 'pref_notif_enabled';
  static const _kVibrate = 'pref_vibrate';
  static const _kLocationShare = 'pref_share_location';
  static const _kEmployeeOnline = 'pref_employee_online';
  static const _kIsEmployee = 'isEmployee';

  // ── Local state
  String _theme = 'system';
  String _lang = 'en';
  bool _notifEnabled = true;
  bool _vibrate = true;
  bool _shareLocation = true;
  bool _employeeOnline = true;

  bool _busy = false;

  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();

  static const List<String> _professionOptions = <String>[
    'Plumber', 'Technician', 'Electrician', 'Handyman', 'Painter', 'Carpenter',
  ];
  String? _profession;

  String? _photoUrl; // read-only display
  User? get _user => FirebaseAuth.instance.currentUser;

  String _emojiFor(String keyLower) {
    switch (keyLower) {
      case 'plumber': return '🔧';
      case 'electrician': return '⚡';
      case 'technician': return '💻';
      case 'painter': return '🎨';
      case 'carpenter': return '🪚';
      case 'handyman': return '🛠';
      default: return '👷';
    }
  }

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _loadProfile();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      if (widget.autoSwitchRole != null) {
        await _switchRoleAndRoute(widget.autoSwitchRole!);
        return;
      }
      if (widget.autoLogout) {
        await _handleLogout();
      }
    });
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _cityCtrl.dispose();
    _addressCtrl.dispose();
    super.dispose();
  }

  // ───────────────────────────────── Prefs ─────────────────────────────────
  Future<void> _loadPrefs() async {
    final sp = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _theme = sp.getString(_kTheme) ?? 'system';
      _lang = sp.getString(_kLang) ?? 'en';
      _notifEnabled = sp.getBool(_kNotif) ?? true;
      _vibrate = sp.getBool(_kVibrate) ?? true;
      _shareLocation = sp.getBool(_kLocationShare) ?? true;
      _employeeOnline = sp.getBool(_kEmployeeOnline) ?? true;
    });
  }

  Future<void> _savePrefString(String key, String value) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(key, value);
  }

  Future<void> _savePrefBool(String key, bool value) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool(key, value);
  }

  // ─────────────────────────────── Profile (FS) ───────────────────────────────
  Future<void> _loadProfile() async {
    if (_user == null) return;
    try {
      final uid = _user!.uid;

      final userDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final userData = userDoc.data() ?? {};

      String? photoUrl =
          (userData['photoUrl'] as String?) ??
          (userData['profileImage'] as String?) ??
          _user?.photoURL;

      if (photoUrl == null || photoUrl.isEmpty) {
        final pubDoc = await FirebaseFirestore.instance.collection('publicUsers').doc(uid).get();
        final pubData = pubDoc.data() ?? {};
        photoUrl = (pubData['photoUrl'] as String?) ?? photoUrl;
      }

      if (!mounted) return;
      setState(() {
        _nameCtrl.text = (userData['name'] ?? userData['fullName'] ?? _user?.displayName ?? '') as String;
        _phoneCtrl.text = (userData['phone'] ?? '') as String;
        _cityCtrl.text = (userData['city'] ?? '') as String;
        _addressCtrl.text = (userData['address'] ?? '') as String;
        _photoUrl = photoUrl;

        if (widget.isEmployee) {
          final prof = (userData['profession'] ?? '') as String;
          if (_professionOptions.contains(prof)) {
            _profession = prof;
          } else {
            _profession = null;
          }
        }
      });
    } catch (e) {
      debugPrint('⚠️ Profile load failed: $e');
    }
  }

  Future<void> _saveProfile() async {
    if (_user == null) return;
    try {
      setState(() => _busy = true);

      final uid = _user!.uid;
      final payload = <String, dynamic>{
        'name': _nameCtrl.text.trim(),
        'fullName': _nameCtrl.text.trim(),
        'phone': _phoneCtrl.text.trim(),
        'city': _cityCtrl.text.trim(),
        'address': _addressCtrl.text.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      };

      if (widget.isEmployee) {
        final key = (_profession ?? '').toLowerCase().trim();
        if (key.isEmpty) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Please select your Profession')),
            );
          }
          return;
        }
        payload.addAll({
          'profession': _profession!,
          'professionEmoji': _emojiFor(key),
        });
      }

      if (_photoUrl != null && _photoUrl!.isNotEmpty) {
        payload['photoUrl'] = _photoUrl;
      }

      await FirebaseFirestore.instance.collection('users').doc(uid)
          .set(payload, SetOptions(merge: true));

      final publicPayload = <String, dynamic>{
        'name': _nameCtrl.text.trim(),
        'city': _cityCtrl.text.trim(),
        'role': widget.isEmployee ? 'employee' : 'customer',
        if (widget.isEmployee && _profession != null) ...{
          'profession': _profession,
          'professionEmoji': _emojiFor((_profession ?? '').toLowerCase()),
        },
        if (_photoUrl != null && _photoUrl!.isNotEmpty) 'photoUrl': _photoUrl,
      };

      await FirebaseFirestore.instance.collection('publicUsers').doc(uid)
          .set(publicPayload, SetOptions(merge: true));

      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Profile saved')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Save failed: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _mirrorPrivacyToFirestore() async {
    if (_user == null) return;
    try {
      final uid = _user!.uid;

      final privacyData = {
        'shareLocation': _shareLocation,
        if (widget.isEmployee) 'isOnline': _employeeOnline,
        'privacyUpdatedAt': FieldValue.serverTimestamp(),
      };
      await FirebaseFirestore.instance.collection('users').doc(uid)
          .set(privacyData, SetOptions(merge: true));

      final publicPrivacy = <String, dynamic>{
        if (_photoUrl != null && _photoUrl!.isNotEmpty) 'photoUrl': _photoUrl,
      };
      await FirebaseFirestore.instance.collection('publicUsers').doc(uid)
          .set(publicPrivacy, SetOptions(merge: true));
    } catch (e) {
      debugPrint('⚠️ Privacy sync failed: $e');
    }
  }

  // ───────── Role switching → route to registration if employee data missing ─────────
  Future<void> _switchRoleAndRoute(String targetRole) async {
    if (_busy) return;
    setState(() => _busy = true);

    try {
      final isEmployeeTarget = targetRole == 'employee';

      // Persist locally
      final sp = await SharedPreferences.getInstance();
      await sp.setBool(_kIsEmployee, isEmployeeTarget);

      if (_user == null) return;
      final uid = _user!.uid;

      // Update Firestore role first
      final userRef = FirebaseFirestore.instance.collection('users').doc(uid);
      final pubRef  = FirebaseFirestore.instance.collection('publicUsers').doc(uid);

      final batch = FirebaseFirestore.instance.batch();
      batch.set(
        userRef,
        {
          'role': targetRole,
          if (!isEmployeeTarget) 'isOnline': false,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      batch.set(pubRef, {'role': targetRole}, SetOptions(merge: true));
      await batch.commit();

      // Fetch fresh snapshot and decide
      final fresh = await userRef.get();
      final data  = (fresh.data() ?? {}) as Map<String, dynamic>;

      if (isEmployeeTarget) {
        // If employee profile complete → send to EmployeeDashboard
        if (_isEmployeeProfileComplete(data)) {
          _routeToDashboard('employee');
        } else {
          // Let the dedicated employee_registration handle photo + required fields
          final name = (data['name'] ?? data['fullName'] ?? _user?.displayName ?? 'User').toString();
          final email = _user?.email ?? '';
          await Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(
              builder: (_) => EmployeeRegistrationScreen(
                email: email,
                name: name,
              ),
            ),
            (route) => false,
          );
        }
      } else {
        // Switching to customer
        if (_isCustomerProfileComplete(data)) {
          _routeToDashboard('customer');
        } else {
          // Complete customer basics in CompleteProfileScreen
          final name = (data['name'] ?? data['fullName'] ?? _user?.displayName ?? 'User').toString();
          final email = _user?.email ?? '';
          await Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(
              builder: (_) => CompleteProfileScreen(
                email: email,
                name: name,
                role: 'customer',
              ),
            ),
            (route) => false,
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Switch failed: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _routeToDashboard(String role) {
    final target = role == 'employee'
        ? const EmployeeDashboardScreen()
        : const CustomerDashboardScreen();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => target),
      (route) => false,
    );
  }

  // Minimal completeness rules
  bool _isCustomerProfileComplete(Map<String, dynamic> u) {
    String _s(v) => (v ?? '').toString().trim();
    final name    = _s(u['name'] ?? u['fullName']);
    final phone   = _s(u['phone']);
    final city    = _s(u['city']);
    final address = _s(u['address']);
    // Customer photo is OPTIONAL
    return name.isNotEmpty && phone.length >= 7 && city.isNotEmpty && address.isNotEmpty;
  }

  bool _isEmployeeProfileComplete(Map<String, dynamic> u) {
    String _s(v) => (v ?? '').toString().trim();
    final name       = _s(u['name'] ?? u['fullName']);
    final phone      = _s(u['phone']);
    final city       = _s(u['city']);
    final address    = _s(u['address']);
    final profession = _s(u['profession']);
    final photoUrl   = _s(u['photoUrl']); // REQUIRED for employees (comes from employee_registration.dart)
    return name.isNotEmpty &&
           phone.length >= 7 &&
           city.isNotEmpty &&
           address.isNotEmpty &&
           profession.isNotEmpty &&
           photoUrl.isNotEmpty;
  }

  // ───────────────────────────────── Misc ─────────────────────────────────
  ThemeMode _themeModeFromString(String v) {
    switch (v) {
      case 'light': return ThemeMode.light;
      case 'dark': return ThemeMode.dark;
      default: return ThemeMode.system;
    }
  }

  Locale _localeFromString(String v) {
    switch (v) {
      case 'ur': return const Locale('ur');
      default:   return const Locale('en');
    }
  }

  Future<void> _openNativeSettings() async {
    final uri = Uri.parse('app-settings:');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Unable to open system settings')));
    }
  }

  Future<void> _handleLogout() async {
    try {
      if (widget.onLogout != null) {
        await widget.onLogout!();
      } else {
        await FirebaseAuth.instance.signOut();
      }
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Logout failed: $e')));
    }
  }

  // ───────────────────────────────── UI ─────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final roleLabel = widget.isEmployee ? 'Employee' : 'Customer';
    final email = _user?.email ?? '';

    return Stack(
      children: [
        Scaffold(
          appBar: AppBar(title: Text('Settings • $roleLabel')),
          body: ListView(
            padding: const EdgeInsets.all(12),
            children: [
              _sectionHeader('Account'),
              _card(children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 36,
                        backgroundColor: Colors.grey.shade200,
                        backgroundImage: (_photoUrl != null && _photoUrl!.isNotEmpty)
                            ? NetworkImage(_photoUrl!)
                            : null,
                        child: (_photoUrl == null || _photoUrl!.isEmpty)
                            ? const Icon(Icons.person, color: Colors.black45, size: 36)
                            : null,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _nameCtrl.text.isNotEmpty
                                  ? _nameCtrl.text
                                  : (_user?.displayName ?? 'User'),
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(email, style: const TextStyle(color: Colors.black54),
                              overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const Divider(height: 0),
                _textFieldTile(label: 'Name', controller: _nameCtrl, icon: Icons.person),
                if (email.isNotEmpty)
                  ListTile(
                    leading: const Icon(Icons.alternate_email),
                    title: Text(email),
                    subtitle: const Text('Email'),
                  ),
                _textFieldTile(
                  label: 'Phone',
                  controller: _phoneCtrl,
                  icon: Icons.phone,
                  keyboardType: TextInputType.phone,
                ),
                _textFieldTile(label: 'City', controller: _cityCtrl, icon: Icons.location_city),
                _textFieldTile(label: 'Address', controller: _addressCtrl, icon: Icons.home),

                if (widget.isEmployee)
                  ListTile(
                    leading: const Icon(Icons.work),
                    title: const Text('Profession'),
                    subtitle: const Text('Pick the category you work in'),
                    trailing: DropdownButton<String>(
                      value: _profession,
                      hint: const Text('Select'),
                      items: _professionOptions
                          .map((p) => DropdownMenuItem<String>(value: p, child: Text(p)))
                          .toList(),
                      onChanged: (value) {
                        setState(() => _profession = value);
                      },
                    ),
                  ),

                const Divider(height: 0),
                ListTile(
                  leading: const Icon(Icons.save),
                  title: const Text('Save profile'),
                  subtitle: Text(widget.isEmployee
                      ? 'Profession required (photo is handled in registration)'
                      : 'Store your profile details securely'),
                  onTap: _busy ? null : _saveProfile,
                ),

                const Divider(height: 0),
                ListTile(
                  leading: const Icon(Icons.swap_horiz),
                  title: const Text('Switch role'),
                  subtitle: Text(widget.isEmployee ? 'Switch to Customer' : 'Switch to Employee'),
                  onTap: _busy ? null : () {
                    final targetRole = widget.isEmployee ? 'customer' : 'employee';
                    _switchRoleAndRoute(targetRole);
                  },
                ),
              ]),

              _sectionHeader('Preferences'),
              _card(children: [
                ListTile(
                  leading: const Icon(Icons.dark_mode),
                  title: const Text('Theme'),
                  subtitle: Text(_theme.toUpperCase()),
                  trailing: DropdownButton<String>(
                    value: _theme,
                    items: const [
                      DropdownMenuItem(value: 'system', child: Text('System')),
                      DropdownMenuItem(value: 'light', child: Text('Light')),
                      DropdownMenuItem(value: 'dark', child: Text('Dark')),
                    ],
                    onChanged: (v) async {
                      if (v == null) return;
                      setState(() => _theme = v);
                      await _savePrefString(_kTheme, v);
                      widget.onThemeChanged?.call(_themeModeFromString(v));
                    },
                  ),
                ),
                const Divider(height: 0),
                ListTile(
                  leading: const Icon(Icons.language),
                  title: const Text('Language'),
                  subtitle: Text(_lang.toUpperCase()),
                  trailing: DropdownButton<String>(
                    value: _lang,
                    items: const [
                      DropdownMenuItem(value: 'en', child: Text('English')),
                      DropdownMenuItem(value: 'ur', child: Text('Urdu')),
                    ],
                    onChanged: (v) async {
                      if (v == null) return;
                      setState(() => _lang = v);
                      await _savePrefString(_kLang, v);
                      widget.onLanguageChanged?.call(_localeFromString(v));
                    },
                  ),
                ),
                const Divider(height: 0),
                SwitchListTile.adaptive(
                  value: _notifEnabled,
                  onChanged: (v) async {
                    setState(() => _notifEnabled = v);
                    await _savePrefBool(_kNotif, v);
                  },
                  secondary: const Icon(Icons.notifications_active),
                  title: const Text('Notifications'),
                  subtitle: const Text('Enable push & local notifications'),
                ),
                const Divider(height: 0),
                SwitchListTile.adaptive(
                  value: _vibrate,
                  onChanged: (v) async {
                    setState(() => _vibrate = v);
                    await _savePrefBool(_kVibrate, v);
                  },
                  secondary: const Icon(Icons.vibration),
                  title: const Text('Vibrate'),
                  subtitle: const Text('Haptic feedback for alerts'),
                ),
              ]),

              _sectionHeader('Location & Privacy'),
              _card(children: [
                SwitchListTile.adaptive(
                  value: _shareLocation,
                  onChanged: (v) async {
                    setState(() => _shareLocation = v);
                    await _savePrefBool(_kLocationShare, v);
                    await _mirrorPrivacyToFirestore();
                  },
                  secondary: const Icon(Icons.location_on),
                  title: const Text('Share live location'),
                  subtitle: const Text('Allow real-time tracking for jobs'),
                ),
                if (widget.isEmployee) ...[
                  const Divider(height: 0),
                  SwitchListTile.adaptive(
                    value: _employeeOnline,
                    onChanged: (v) async {
                      setState(() => _employeeOnline = v);
                      await _savePrefBool(_kEmployeeOnline, v);
                      await _mirrorPrivacyToFirestore();
                    },
                    secondary: const Icon(Icons.toggle_on),
                    title: const Text('Online status'),
                    subtitle: const Text('Appear available to receive jobs'),
                  ),
                ],
                const Divider(height: 0),
                ListTile(
                  leading: const Icon(Icons.settings_applications),
                  title: const Text('System app permissions'),
                  subtitle: const Text('Open device settings to manage permissions'),
                  onTap: _openNativeSettings,
                ),
              ]),

              _sectionHeader(widget.isEmployee ? 'Earnings' : 'Payments'),
              _card(children: [
                if (widget.isEmployee)
                  ListTile(
                    leading: const Icon(Icons.account_balance_wallet),
                    title: const Text('Earnings & Payouts'),
                    subtitle: const Text('View earnings, link bank account'),
                    onTap: () {},
                  )
                else
                  ListTile(
                    leading: const Icon(Icons.credit_card),
                    title: const Text('Payment Methods'),
                    subtitle: const Text('Add/Remove saved cards'),
                    onTap: () {},
                  ),
                const Divider(height: 0),
                ListTile(
                  leading: const Icon(Icons.receipt_long),
                  title: const Text('History'),
                  subtitle: Text(widget.isEmployee
                      ? 'Job history and payouts'
                      : 'Maintenance & payments history'),
                  onTap: () {},
                ),
              ]),

              _sectionHeader('Ratings & Feedback'),
              _card(children: [
                ListTile(
                  leading: const Icon(Icons.star_rate),
                  title: const Text('My ratings'),
                  subtitle: const Text('View received/given ratings'),
                  onTap: () {},
                ),
                const Divider(height: 0),
                ListTile(
                  leading: const Icon(Icons.feedback),
                  title: const Text('Send feedback'),
                  subtitle: const Text('Tell us how we can improve'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const FeedbackScreen()),
                    );
                  },
                ),
              ]),

              _sectionHeader('Session'),
              _card(children: [
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.red),
                  title: const Text('Logout', style: TextStyle(color: Colors.red)),
                  onTap: _busy ? null : _handleLogout,
                ),
              ]),

              const SizedBox(height: 24),
              _about(),
              const SizedBox(height: 24),
            ],
          ),
        ),

        if (_busy)
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(0.08),
              child: const Center(child: CircularProgressIndicator()),
            ),
          ),
      ],
    );
  }

  // ── UI helpers
  Widget _sectionHeader(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
        child: Text(
          title,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.grey),
        ),
      );

Widget _card({required List<Widget> children}) => Card(
      elevation: 0, // 👈 removes shadow
      color: Colors.transparent, // 👈 removes white background
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide.none, // 👈 no border line
      ),
      child: Column(children: children),
    );


  Widget _textFieldTile({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType? keyboardType,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: const InputDecoration(
          isDense: true,
          border: OutlineInputBorder(),
        ).copyWith(labelText: label),
      ),
    );
  }

  Widget _about() => Center(
        child: Column(
          children: [
            const Text('PakistanFixMe • v1.0.0', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('© ${DateTime.now().year} Your Company'),
          ],
        ),
      );
}