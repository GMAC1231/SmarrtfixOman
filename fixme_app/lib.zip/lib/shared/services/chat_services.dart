import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  static String pairId(String a, String b) =>
      (a.compareTo(b) <= 0) ? '${a}__${b}' : '${b}__${a}';

  /// CREATE-first (rules-safe): try to create the chat with the caller in `members`.
  /// If it already exists (so the create is treated as an UPDATE and denied),
  /// fall back to the tiny allowed update (lastMessageAt/lastMessageSnippet).
  static Future<String> ensureChat({
    required String customerId,
    required String employeeId,
    required String requestId,
  }) async {
    final chatId = pairId(customerId, employeeId);
    final ref = FirebaseFirestore.instance.collection('chats').doc(chatId);

    // This payload satisfies your CREATE rule:
    // - members (2 users including me())
    // - createdAt is timestamp
    // Your rule doesn’t restrict extra keys on CREATE, so requestId is fine.
    final payload = <String, dynamic>{
      'members': [customerId, employeeId],
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessageAt': FieldValue.serverTimestamp(),
      'lastMessageSnippet': '',
      'requestId': requestId,
    };

    try {
      // If the doc doesn't exist, this is a CREATE and will pass.
      // If it does exist, Firestore treats it like an UPDATE and your UPDATE rule
      // will likely deny (since only 2 fields are allowed) — we catch & handle that.
      await ref.set(payload, SetOptions(merge: false));
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        // Doc probably already exists; do the tiny allowed update.
        await ref.update({
          'lastMessageAt': FieldValue.serverTimestamp(),
          'lastMessageSnippet': '',
        });
      } else {
        rethrow;
      }
    }

    return chatId;
  }

  static Future<String?> sendMessage({
    required String chatId,
    required String text,
  }) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final trimmed = text.trim();
    if (uid == null || trimmed.isEmpty) return null;

    final chatRef = FirebaseFirestore.instance.collection('chats').doc(chatId);
    final msgRef = chatRef.collection('messages').doc();

    // Keys must match your message CREATE rule exactly.
    await msgRef.set({
      'senderId': uid,
      'text': trimmed,
      'createdAt': FieldValue.serverTimestamp(),
      'deliveredAt': null,
      'readAt': null,
    });

    // Only these two fields are allowed by your chat UPDATE rule.
    await chatRef.update({
      'lastMessageAt': FieldValue.serverTimestamp(),
      'lastMessageSnippet': trimmed,
    });

    return msgRef.id;
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> messagesStream(String chatId) {
    return FirebaseFirestore.instance
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('createdAt')
        .snapshots();
  }

  static Future<void> markMessageRead({
    required String chatId,
    required String msgId,
    bool delivered = false,
  }) async {
    final field = delivered ? 'deliveredAt' : 'readAt';
    await FirebaseFirestore.instance
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc(msgId)
        .update({field: FieldValue.serverTimestamp()});
  }
}
