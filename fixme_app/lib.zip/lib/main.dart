import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kReleaseMode, debugPrint;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fixme_app/admin_dashboard.dart';
// screens
import 'package:fixme_app/splash_screen.dart';
import 'package:fixme_app/home_page.dart';
import 'package:fixme_app/customer_dashboard.dart';
import 'package:fixme_app/employee_dashboard.dart';
import 'package:fixme_app/complete_profile_screen.dart';

// bootstrap helper
import 'package:fixme_app/shared/services/profile_bootstrap.dart';

/// Print which Firebase project this build is using (compare with Console).
void logProject() {
  final o = Firebase.app().options;
  debugPrint('🔥 Firebase projectId=${o.projectId}');
  debugPrint('🔥 Firebase appId=${o.appId}');
  debugPrint('🔥 Firebase dbUrl=${o.databaseURL}');
}

/// Initialize Firebase and App Check early.
Future<void> initFirebaseAndAppCheck() async {
  await Firebase.initializeApp();

  // In debug builds, use the Debug provider (logs a debug token you must allow-list in Console).
  // In release, use Play Integrity on Android; DeviceCheck is fine on iOS unless you’ve set up App Attest.
  await FirebaseAppCheck.instance.activate(
    androidProvider: kReleaseMode ? AndroidProvider.playIntegrity : AndroidProvider.debug,
    appleProvider: kReleaseMode ? AppleProvider.deviceCheck : AppleProvider.debug,
  );

  logProject();
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1) Init Firebase + App Check BEFORE doing anything else
  await initFirebaseAndAppCheck();

  // 2) If already signed in, ensure profile exists
  final current = FirebaseAuth.instance.currentUser;
  if (current != null) {
    await ProfileBootstrap.ensureProfile();
  }

  // 3) Keep profile in sync for sign-ins during the session
  FirebaseAuth.instance.authStateChanges().listen((u) {
    if (u != null) {
      // ignore: body_might_complete_normally_catch_error
      ProfileBootstrap.ensureProfile().catchError((_) {});
    }
  });

  runApp(const PakistanFixMeApp());
}

class PakistanFixMeApp extends StatelessWidget {
  const PakistanFixMeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PakistanFixMe',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF01411C),
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
      ),
      home: const SplashScreen(),
routes: {
  '/home': (_) => const HomePage(),
  '/customer_dashboard': (_) => const CustomerDashboardScreen(),
  '/employee_dashboard': (_) => const EmployeeDashboardScreen(),
  '/admin_dashboard': (_) => const AdminDashboardScreen(),
},
      onGenerateRoute: (settings) {
        if (settings.name == '/complete_profile') {
          final args = (settings.arguments ?? {}) as Map<dynamic, dynamic>;
          return MaterialPageRoute(
            builder: (_) => CompleteProfileScreen(
              email: (args['email'] as String?) ?? '',
              name:  (args['name']  as String?) ?? 'User',
              role:  (args['role']  as String?) ?? 'customer',
            ),
          );
        }
        return null;
      },
    );
  }
}