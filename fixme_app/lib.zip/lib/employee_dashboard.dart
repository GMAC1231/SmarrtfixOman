import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'map_tab.dart';
import 'request_tab.dart';
import 'active_job_tab.dart';
import 'dashboard_home_tab.dart';
import 'settings_screen.dart';
import 'session_utils.dart';

class EmployeeDashboardScreen extends StatefulWidget {
  const EmployeeDashboardScreen({super.key});

  @override
  State<EmployeeDashboardScreen> createState() =>
      _EmployeeDashboardScreenState();
}

class _EmployeeDashboardScreenState extends State<EmployeeDashboardScreen> {
  int _selectedIndex = 0;

  final GlobalKey<MapTabState> _mapTabKey = GlobalKey<MapTabState>();

  bool _isOnline = false;
  int _activeJobs = 0;
  int _completedJobs = 0;
  double _earnings = 0.0;

  late List<Widget> _tabs;

  @override
  void initState() {
    super.initState();
    _buildTabs();
  }

  void _buildTabs() {
    _tabs = [
      DashboardHomeTab(
        onRecenterMap: _onRecenterMap,
        onProfile: _onOpenProfile,
        onToggleOnline: _onToggleOnline,
        activeJobs: _activeJobs,
        completedJobs: _completedJobs,
        earnings: _earnings,
        isOnline: _isOnline,
      ),
      MapTab(key: _mapTabKey),

      // Fixed: your actual widget class is EmployeeRequestsTab
      EmployeeRequestsTab(mapTabKey: _mapTabKey),

      ActiveJobTab(mapTabKey: _mapTabKey),
      const SettingsScreen(isEmployee: true, currentTheme: 'light'),
    ];
  }

  void _onRecenterMap() {
    _mapTabKey.currentState?.centerToEmployee();
  }

  void _onOpenProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            const SettingsScreen(isEmployee: true, currentTheme: 'light'),
      ),
    );
  }

  void _onToggleOnline() {
    setState(() {
      _isOnline = !_isOnline;
      _buildTabs();
    });

    // TODO: save online/offline state to backend if needed
  }

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  void _navigateFromDrawer(int index) {
    Navigator.pop(context);
    _onItemTapped(index);
  }

  void _openDrawerSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            const SettingsScreen(isEmployee: true, currentTheme: 'light'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _openDrawerSettings,
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(user?.displayName ?? 'No Name'),
              accountEmail: Text(user?.email ?? ''),
              currentAccountPicture: const CircleAvatar(
                child: Icon(Icons.person),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text('Dashboard'),
              onTap: () => _navigateFromDrawer(0),
            ),
            ListTile(
              leading: const Icon(Icons.map),
              title: const Text('Map'),
              onTap: () => _navigateFromDrawer(1),
            ),
            ListTile(
              leading: const Icon(Icons.receipt_long),
              title: const Text('Requests'),
              onTap: () => _navigateFromDrawer(2),
            ),
            ListTile(
              leading: const Icon(Icons.work),
              title: const Text('Active Job'),
              onTap: () => _navigateFromDrawer(3),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () => _navigateFromDrawer(4),
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () async {
                Navigator.pop(context);
                await SessionUtils.logout(context);
              },
            ),
          ],
        ),
      ),
      body: _tabs[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_outlined),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map_outlined),
            label: 'Map',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt_long_outlined),
            label: 'Requests',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.work_outline),
            label: 'Active Job',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings_outlined),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}