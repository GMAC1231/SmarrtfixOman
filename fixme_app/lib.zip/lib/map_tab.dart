import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart';
import 'package:geolocator/geolocator.dart';

class MapTab extends StatefulWidget {
  const MapTab({super.key});

  @override
  MapTabState createState() => MapTabState();
}

class MapTabState extends State<MapTab> {
  final MapController _mapController = MapController(
    initMapWithUserPosition: const UserTrackingOption(),
  );

  bool _mapReady = false;
  bool _sheetExpanded = false;

  GeoPoint? _employeePoint;
  GeoPoint? _customerPoint;
  GeoPoint? _carMarkerPoint;

  StreamSubscription<Position>? _positionSub;

  int? _etaSeconds;
  double? _distanceKm;

  // ───────────────────────── LIFECYCLE ─────────────────────────

  @override
  void initState() {
    super.initState();
    _startLocationTracking();
  }

  @override
  void dispose() {
    _positionSub?.cancel(); // ✅ stop GPS updates
    super.dispose();        // ❌ DO NOT dispose mapController
  }

  // ───────────────────────── GPS TRACKING ─────────────────────────

  void _startLocationTracking() {
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),
    ).listen((pos) async {
      if (!mounted || !_mapReady) return;

      final newPoint = GeoPoint(
        latitude: pos.latitude,
        longitude: pos.longitude,
      );

      _employeePoint = newPoint;

      await _updateCarMarker(newPoint);

      if (!_sheetExpanded) {
        await _centerOn(newPoint);
      }
    });
  }

  Future<void> _updateCarMarker(GeoPoint point) async {
    if (!mounted || !_mapReady) return;

    try {
      if (_carMarkerPoint != null) {
        await _mapController.removeMarker(_carMarkerPoint!);
      }

      await _mapController.addMarker(
        point,
        markerIcon: const MarkerIcon(
          icon: Icon(
            Icons.directions_car,
            color: Colors.red,
            size: 42,
          ),
        ),
      );

      _carMarkerPoint = point;
    } catch (_) {
      // ignore safely
    }
  }

  // ───────────────────────── MAP HELPERS ─────────────────────────

  Future<void> _centerOn(GeoPoint point) async {
    if (!mounted || !_mapReady) return;
    try {
      await _mapController.goToLocation(point);
      await _mapController.setZoom(zoomLevel: 16);
    } catch (_) {}
  }

  void centerToEmployee() {
    if (_employeePoint != null) {
      _centerOn(_employeePoint!);
    }
  }

  // ───────────────────────── ROUTING ─────────────────────────

  Future<void> _drawRoute() async {
    if (!mounted || !_mapReady) return;
    if (_employeePoint == null || _customerPoint == null) return;

    try {
      await _mapController.clearAllRoads();
      await _mapController.drawRoad(
        _employeePoint!,
        _customerPoint!,
      );

      final meters = Geolocator.distanceBetween(
        _employeePoint!.latitude,
        _employeePoint!.longitude,
        _customerPoint!.latitude,
        _customerPoint!.longitude,
      );

      setState(() {
        _distanceKm = meters / 1000;
        _etaSeconds = ((_distanceKm! / 25) * 3600).round();
      });
    } catch (_) {}
  }

  /// 🔑 Called from RequestsTab / ActiveJobTab
  void setCustomerLocation(GeoPoint pt) async {
    if (!mounted) return;

    _customerPoint = pt;

    if (_mapReady) {
      try {
        await _mapController.addMarker(pt);
        await _centerOn(pt);
      } catch (_) {}
    }

    await _drawRoute();
  }

  // ───────────────────────── UI ─────────────────────────

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: _buildMap()),
        _buildRouteInfoBubble(),
        _buildBottomSheet(),
        _buildFloatingCenterButton(),
      ],
    );
  }

  Widget _buildMap() {
    return OSMFlutter(
      controller: _mapController,
      osmOption: OSMOption(
        zoomOption: const ZoomOption(
          initZoom: 16,
          minZoomLevel: 2,
          maxZoomLevel: 18,
        ),
        userTrackingOption: const UserTrackingOption(
          enableTracking: false, // ❗ we handle tracking ourselves
          unFollowUser: false,
        ),
        showZoomController: true,
      ),
      onMapIsReady: (ready) {
        if (!mounted || !ready) return;
        setState(() => _mapReady = true);
      },
    );
  }

  Widget _buildRouteInfoBubble() {
    if (_etaSeconds == null && _distanceKm == null) {
      return const SizedBox();
    }

    return Positioned(
      top: 16,
      left: 16,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.deepPurple,
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [
            BoxShadow(color: Colors.black26, blurRadius: 6),
          ],
        ),
        child: Text(
          '⏱ ${(_etaSeconds! / 60).ceil()} min • 📏 ${_distanceKm!.toStringAsFixed(1)} km',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildBottomSheet() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: _sheetExpanded ? 240 : 80,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
          boxShadow: [
            BoxShadow(color: Colors.black26, blurRadius: 6),
          ],
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              GestureDetector(
                onTap: () =>
                    setState(() => _sheetExpanded = !_sheetExpanded),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Icon(
                    _sheetExpanded
                        ? Icons.expand_more
                        : Icons.expand_less,
                  ),
                ),
              ),
              if (_sheetExpanded) ...[
                if (_distanceKm != null)
                  Text(
                    'Distance: ${_distanceKm!.toStringAsFixed(1)} km',
                  ),
                if (_etaSeconds != null)
                  Text(
                    'ETA: ${(_etaSeconds! / 60).ceil()} min',
                  ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: centerToEmployee,
                  icon: const Icon(Icons.my_location),
                  label: const Text('Center on Me'),
                ),
                if (_customerPoint != null)
                  ElevatedButton.icon(
                    onPressed: () => _centerOn(_customerPoint!),
                    icon: const Icon(Icons.location_pin),
                    label: const Text('Center on Customer'),
                  ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFloatingCenterButton() {
    return Positioned(
      right: 16,
      bottom: _sheetExpanded ? 250 : 120,
      child: FloatingActionButton(
        backgroundColor: Colors.blue,
        onPressed: centerToEmployee,
        child: const Icon(Icons.my_location),
      ),
    );
  }
}
