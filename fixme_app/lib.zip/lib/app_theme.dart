import 'package:flutter/material.dart';

class AppTheme {
  // Brand
  static const Color primary = Color.fromARGB(255, 5, 77, 35);
  static const Color lightText = Colors.white;

  // UI
  static const Radius sheetRadius = Radius.circular(22);

  // Map
  static const double tightZoom = 18.5;
}
