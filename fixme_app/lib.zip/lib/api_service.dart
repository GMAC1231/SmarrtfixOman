// lib/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

/// 🔧 Backend API Service (Flask + Postgres)
class ApiService {
  /// Change this depending on emulator / device
  static const String baseUrl = "http://192.168.100.15:5000"; // Android emulator
  // static const String baseUrl = "http://192.168.1.100:5000"; // Physical device (LAN IP)

  /// 🔹 Register user
  static Future<Map<String, dynamic>> registerUser({
    required String email,
    required String name,
    required String role,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/register"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "name": name, "role": role}),
    );

    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    } else {
      throw Exception("Register failed: ${res.body}");
    }
  }

  /// 🔹 Update customer profile
  static Future<Map<String, dynamic>> updateCustomerProfile({
    required String email,
    required String name,
    required String phone,
    required String city,
    required String address,
    required String gender,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/update-profile"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "email": email,
        "name": name,
        "role": "customer",
        "phone": phone,
        "city": city,
        "address": address,
        "gender": gender,
      }),
    );

    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    } else {
      throw Exception("Customer update failed: ${res.body}");
    }
  }

  /// 🔹 Update employee profile
  static Future<Map<String, dynamic>> updateEmployeeProfile({
    required String email,
    required String name,
    required String profession,
    required String professionEmoji,
    required double fare,
    required String license,
    required String carPlate,
    required String? profileImage,
    required String phone,
    required String city,
    required String address,
    required String gender,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/update-profile"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "email": email,
        "name": name,
        "role": "employee",
        "phone": phone,
        "city": city,
        "address": address,
        "gender": gender,
        "profession": profession,
        "professionEmoji": professionEmoji,
        "fare": fare,
        "license": license,
        "carPlate": carPlate,
        "profileImage": profileImage,
      }),
    );

    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    } else {
      throw Exception("Employee update failed: ${res.body}");
    }
  }
}
