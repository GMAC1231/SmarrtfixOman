import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/request_service.dart';

class EmployeeRequestsTab extends StatefulWidget {
  final GlobalKey<MapTabState> mapTabKey;

  const EmployeeRequestsTab({super.key, required this.mapTabKey});

  @override
  State<EmployeeRequestsTab> createState() => _EmployeeRequestsTabState();
}

class _EmployeeRequestsTabState extends State<EmployeeRequestsTab> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.openRequestsStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final requests = snapshot.data!;
        if (requests.isEmpty) {
          return const Center(child: Text('No open requests'));
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final req = requests[index];
            return _RequestCard(
              request: req,
              onRoute: () async {
                final gp = _extractPoint(req);
                if (gp != null) {
                  await widget.mapTabKey.currentState?.setCustomerLocation(gp);
                }
              },
              onQuickAccept: () async {
                await RequestService.quickAcceptRequest(req.id);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Request accepted')),
                );
              },
              onReject: () async {
                await RequestService.rejectRequest(req.id);
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Request rejected')),
                );
              },
              onOffer: () => _showOfferDialog(req),
              onChat: req.customerId.isEmpty
                  ? null
                  : () => _openChat(
                        customerId: req.customerId,
                        requestId: req.id,
                        title: req.customerName,
                      ),
            );
          },
        );
      },
    );
  }

  osm.GeoPoint? _extractPoint(ServiceRequestModel req) {
    if (req.customerLat != null && req.customerLng != null) {
      return osm.GeoPoint(latitude: req.customerLat!, longitude: req.customerLng!);
    }
    return null;
  }

  Future<void> _showOfferDialog(ServiceRequestModel req) async {
    final fareController = TextEditingController(
      text: req.displayFare?.toStringAsFixed(2) ?? '',
    );
    final noteController = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Send offer'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: fareController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Your fare',
                prefixText: 'OMR ',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Optional note'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final fare = double.tryParse(fareController.text.trim());
              if (fare == null || fare <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Enter a valid fare amount')),
                );
                return;
              }
              Navigator.pop(dialogContext);
              await RequestService.sendOffer(
                requestId: req.id,
                fare: fare,
                note: noteController.text,
              );
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Offer sent')),
              );
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  void _openChat({
    required String customerId,
    required String requestId,
    required String title,
  }) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          chatId: '$requestId-$customerId',
          otherUserId: customerId,
          title: title,
          requestId: requestId,
          iAmCustomer: false,
          providerId: FirebaseAuth.instance.currentUser?.uid,
        ),
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  final ServiceRequestModel request;
  final VoidCallback onRoute;
  final VoidCallback onQuickAccept;
  final VoidCallback onReject;
  final VoidCallback onOffer;
  final VoidCallback? onChat;

  const _RequestCard({
    required this.request,
    required this.onRoute,
    required this.onQuickAccept,
    required this.onReject,
    required this.onOffer,
    required this.onChat,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    request.serviceType,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                _StatusChip(status: request.status),
              ],
            ),
            const SizedBox(height: 10),
            Text('Customer: ${request.customerName}'),
            if (request.customerEmail.isNotEmpty) Text('Email: ${request.customerEmail}'),
            if (request.customerPhone.isNotEmpty) Text('Phone: ${request.customerPhone}'),
            Text('Budget: OMR ${(request.displayFare ?? 0).toStringAsFixed(2)}'),
            if (request.createdAt != null) Text('Created: ${request.createdAt!.toDate()}'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: onRoute,
                  icon: const Icon(Icons.route_outlined),
                  label: const Text('Route'),
                ),
                ElevatedButton.icon(
                  onPressed: onQuickAccept,
                  icon: const Icon(Icons.check_circle_outline),
                  label: const Text('Accept'),
                ),
                OutlinedButton.icon(
                  onPressed: onOffer,
                  icon: const Icon(Icons.local_offer_outlined),
                  label: const Text('Offer'),
                ),
                OutlinedButton.icon(
                  onPressed: onReject,
                  icon: const Icon(Icons.close),
                  label: const Text('Reject'),
                ),
                if (onChat != null)
                  ElevatedButton.icon(
                    onPressed: onChat,
                    icon: const Icon(Icons.chat_bubble_outline),
                    label: const Text('Chat'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case 'accepted':
      case 'ongoing':
        color = Colors.green;
        break;
      case 'pending':
      case 'bidding':
        color = Colors.orange;
        break;
      case 'rejected':
      case 'cancelled':
        color = Colors.red;
        break;
      default:
        color = Colors.blueGrey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12),
      ),
    );
  }
}
