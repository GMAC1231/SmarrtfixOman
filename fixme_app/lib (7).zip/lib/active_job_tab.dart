import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'map_tab.dart';
import 'shared/models/service_request.dart';
import 'shared/services/request_service.dart';

class ActiveJobTab extends StatelessWidget {
  final GlobalKey<MapTabState>? mapTabKey;

  const ActiveJobTab({super.key, this.mapTabKey});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Center(child: Text('Please sign in'));

    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.providerJobsStream(user.uid),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final jobs = snapshot.data!;
        if (jobs.isEmpty) {
          return const Center(child: Text('No active job'));
        }

        final job = jobs.first;

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          job.serviceType,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                      ),
                      _JobStatusBadge(status: job.status),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text('Customer: ${job.customerName}'),
                  Text('Provider: ${job.assignedWorkerName.isEmpty ? 'You' : job.assignedWorkerName}'),
                  Text('Fare: OMR ${(job.displayFare ?? 0).toStringAsFixed(2)}'),
                  if (job.customerPhone.isNotEmpty) Text('Phone: ${job.customerPhone}'),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () {
                          if (job.customerLat != null && job.customerLng != null) {
                            mapTabKey?.currentState?.setCustomerLocationFromMap({
                              'lat': job.customerLat,
                              'lng': job.customerLng,
                            });
                          }
                        },
                        icon: const Icon(Icons.route),
                        label: const Text('Show route'),
                      ),
                      if (job.customerId.isNotEmpty)
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  chatId: '${job.id}-${job.customerId}',
                                  otherUserId: job.customerId,
                                  title: job.customerName,
                                  requestId: job.id,
                                  iAmCustomer: false,
                                  providerId: user.uid,
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('Chat'),
                        ),
                    ],
                  ),
                  const Spacer(),
                  if (job.status == 'accepted')
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => RequestService.updateStatus(job.id, 'ongoing'),
                        child: const Text('Start job'),
                      ),
                    ),
                  if (job.status == 'ongoing')
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => RequestService.updateStatus(job.id, 'completed'),
                        child: const Text('Complete job'),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _JobStatusBadge extends StatelessWidget {
  final String status;

  const _JobStatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    final color = status == 'ongoing'
        ? Colors.green
        : status == 'accepted'
            ? Colors.orange
            : Colors.blueGrey;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(color: color, fontWeight: FontWeight.bold),
      ),
    );
  }
}
