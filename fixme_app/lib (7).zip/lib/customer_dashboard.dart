import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'chat_screen.dart';
import 'main.dart';
import 'map_tab.dart';
import 'session_utils.dart';
import 'settings_screen.dart';
import 'shared/models/service_request.dart';
import 'shared/services/location_tracking_service.dart';
import 'shared/services/request_service.dart';

const Color _brand = Color(0xFF01411C);

const List<Map<String, String>> _serviceCategories = [
  {'key': 'Technician', 'emoji': '🔧'},
  {'key': 'Plumber', 'emoji': '🚰'},
  {'key': 'Electrician', 'emoji': '💡'},
  {'key': 'Carpenter', 'emoji': '🪚'},
  {'key': 'Painter', 'emoji': '🎨'},
  {'key': 'Handyman', 'emoji': '🛠️'},
  {'key': 'Cleaner', 'emoji': '🧹'},
];

class CustomerDashboardScreen extends StatefulWidget {
  const CustomerDashboardScreen({super.key});

  @override
  State<CustomerDashboardScreen> createState() =>
      _CustomerDashboardScreenState();
}

class _CustomerDashboardScreenState extends State<CustomerDashboardScreen> {
  final LocationTrackingService _locationService = LocationTrackingService();

  int _currentIndex = 0;
  Position? _position;
  bool _loadingLocation = false;

  User? get _user => FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  @override
  void dispose() {
    _locationService.dispose();
    super.dispose();
  }

  String _themeToString(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  Future<void> _loadLocation() async {
    setState(() => _loadingLocation = true);
    try {
      final pos = await _locationService.getCurrentPosition();
      if (mounted) setState(() => _position = pos);
    } finally {
      if (mounted) setState(() => _loadingLocation = false);
    }
  }

  Future<void> _createRequest({
    required String serviceType,
    required double fare,
    String? note,
  }) async {
    try {
      await RequestService.createRequest(
        serviceType: serviceType,
        fare: fare,
        lat: _position?.latitude,
        lng: _position?.longitude,
        note: note,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request created successfully')),
      );
      setState(() => _currentIndex = 1);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to create request: $e')),
      );
    }
  }

  Future<void> _openRequestDialog([String? preset]) async {
    final fareController = TextEditingController();
    final noteController = TextEditingController();
    String selected = preset ?? _serviceCategories.first['key']!;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: const Text('Book a service'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selected,
                      decoration: const InputDecoration(
                        labelText: 'Service category',
                      ),
                      items: _serviceCategories
                          .map(
                            (item) => DropdownMenuItem<String>(
                              value: item['key'],
                              child: Text('${item['emoji']} ${item['key']}'),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setStateDialog(() => selected = value);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: fareController,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Your budget / fare offer',
                        prefixText: 'OMR ',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: noteController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Describe the issue',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final fare = double.tryParse(fareController.text.trim());
                    if (fare == null || fare <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Enter a valid fare amount'),
                        ),
                      );
                      return;
                    }
                    Navigator.pop(dialogContext);
                    await _createRequest(
                      serviceType: selected,
                      fare: fare,
                      note: noteController.text.trim(),
                    );
                  },
                  child: const Text('Send request'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please sign in first')),
      );
    }

    final appState = AppStateScope.of(context);

    final pages = [
      _CustomerHomeTab(
        user: user,
        position: _position,
        loadingLocation: _loadingLocation,
        onRefreshLocation: _loadLocation,
        onBookNow: _openRequestDialog,
      ),
      _CustomerRequestsTab(
        userId: user.uid,
        onBookAnother: _openRequestDialog,
      ),
      SettingsScreen(
        isEmployee: false,
        currentTheme: _themeToString(appState.themeMode),
        currentLanguage: appState.locale.languageCode,
        onThemeChanged: (mode) async {
          await appState.setTheme(mode);
        },
        onLanguageChanged: (locale) async {
          await appState.setLocale(locale);
        },
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Customer Dashboard')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: const BoxDecoration(color: _brand),
              accountName: Text(user.displayName ?? 'Customer'),
              accountEmail: Text(user.email ?? ''),
              currentAccountPicture:
                  const CircleAvatar(child: Icon(Icons.person)),
            ),
            ListTile(
              leading: const Icon(Icons.home_outlined),
              title: const Text('Home'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.work_outline),
              title: const Text('My Requests'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 1);
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('Settings'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 2);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.add_circle_outline),
              title: const Text('New Request'),
              onTap: () async {
                Navigator.pop(context);
                await _openRequestDialog();
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () async {
                Navigator.pop(context);
                await SessionUtils.logout(context);
              },
            ),
          ],
        ),
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _openRequestDialog,
              backgroundColor: _brand,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('Request service'),
            )
          : null,
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (value) => setState(() => _currentIndex = value),
        selectedItemColor: _brand,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.work), label: 'Requests'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class _CustomerHomeTab extends StatelessWidget {
  final User user;
  final Position? position;
  final bool loadingLocation;
  final Future<void> Function() onRefreshLocation;
  final Future<void> Function([String? preset]) onBookNow;

  const _CustomerHomeTab({
    required this.user,
    required this.position,
    required this.loadingLocation,
    required this.onRefreshLocation,
    required this.onBookNow,
  });

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: onRefreshLocation,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _brand,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome, ${user.displayName ?? 'Customer'}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  user.email ?? '',
                  style: const TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Icon(Icons.my_location, color: Colors.white),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        loadingLocation
                            ? 'Detecting your location...'
                            : position == null
                                ? 'Location unavailable'
                                : 'Lat ${position!.latitude.toStringAsFixed(5)}, Lng ${position!.longitude.toStringAsFixed(5)}',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Available services',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ..._serviceCategories.map(
            (item) => Card(
              child: ListTile(
                leading: Text(
                  item['emoji']!,
                  style: const TextStyle(fontSize: 26),
                ),
                title: Text(item['key']!),
                subtitle: const Text('Tap to create a request quickly'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 18),
                onTap: () => onBookNow(item['key']),
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: onRefreshLocation,
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh location'),
          ),
        ],
      ),
    );
  }
}

class _CustomerRequestsTab extends StatelessWidget {
  final String userId;
  final Future<void> Function([String? preset]) onBookAnother;

  const _CustomerRequestsTab({
    required this.userId,
    required this.onBookAnother,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ServiceRequestModel>>(
      stream: RequestService.customerRequestsStream(userId),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final requests = snapshot.data!;
        if (requests.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('No requests yet'),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: () => onBookAnother(),
                  icon: const Icon(Icons.add),
                  label: const Text('Book a service'),
                ),
              ],
            ),
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: requests.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final req = requests[index];
            final providerId = req.assignedWorkerId;
            final providerName = req.assignedWorkerName.isEmpty
                ? 'Waiting for provider'
                : req.assignedWorkerName;

            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            req.serviceType,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        _RequestStatusChip(status: req.status),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('Fare: OMR ${(req.displayFare ?? 0).toStringAsFixed(2)}'),
                    Text('Provider: $providerName'),
                    if (req.createdAt != null)
                      Text('Created: ${req.createdAt!.toDate()}'),
                    const SizedBox(height: 12),
                    if (req.isOpen) ...[
                      SizedBox(
                        height: 360,
                        child: MapTab(requestId: req.id),
                      ),
                      const SizedBox(height: 12),
                    ],
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        if (providerId.isNotEmpty)
                          ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    chatId: '${req.id}-$providerId',
                                    otherUserId: providerId,
                                    title: providerName,
                                    requestId: req.id,
                                    iAmCustomer: true,
                                    providerId: providerId,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.chat),
                            label: const Text('Chat'),
                          ),
                        if (req.isOpen)
                          OutlinedButton.icon(
                            onPressed: () => RequestService.cancelRequest(req.id),
                            icon: const Icon(Icons.cancel_outlined),
                            label: const Text('Cancel'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _RequestStatusChip extends StatelessWidget {
  final String status;

  const _RequestStatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case 'accepted':
      case 'ongoing':
        color = Colors.green;
        break;
      case 'pending':
      case 'bidding':
        color = Colors.orange;
        break;
      case 'cancelled':
      case 'rejected':
        color = Colors.red;
        break;
      case 'completed':
        color = Colors.blue;
        break;
      default:
        color = Colors.blueGrey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w700,
          fontSize: 12,
        ),
      ),
    );
  }
}