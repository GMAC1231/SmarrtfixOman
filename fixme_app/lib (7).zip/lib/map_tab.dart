import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;

import 'shared/services/request_service.dart';

class MapTab extends StatefulWidget {
  final String? requestId;

  const MapTab({
    super.key,
    this.requestId,
  });

  @override
  MapTabState createState() => MapTabState();
}

class MapTabState extends State<MapTab> {
  final osm.MapController _mapController = osm.MapController(
    initMapWithUserPosition: const osm.UserTrackingOption(),
  );

  StreamSubscription<Position>? _positionSub;
  StreamSubscription<firestore.DocumentSnapshot<Map<String, dynamic>>>? _requestSub;
  StreamSubscription<firestore.QuerySnapshot<Map<String, dynamic>>>? _offersSub;
  StreamSubscription<firestore.DocumentSnapshot<Map<String, dynamic>>>? _providerLiveSub;

  osm.GeoPoint? _employeePoint;
  osm.GeoPoint? _customerPoint;
  osm.GeoPoint? _providerPoint;

  osm.GeoPoint? _employeeMarkerPoint;
  osm.GeoPoint? _customerMarkerPoint;
  osm.GeoPoint? _providerMarkerPoint;

  bool _mapReady = false;
  bool _loadingOffers = false;
  bool _isAnimatingProvider = false;

  double? _distanceKm;
  int? _etaMinutes;

  String? _acceptedProviderId;
  String? _acceptedProviderName;
  String? _acceptedProviderCar;
  double? _acceptedProviderRating;
  List<Map<String, dynamic>> _offers = [];

  @override
  void initState() {
    super.initState();
    _startOwnLocationTracking();
    _listenToRequestIfNeeded();
  }

  @override
  void didUpdateWidget(covariant MapTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.requestId != widget.requestId) {
      _cancelRequestListeners();
      _offers = [];
      _acceptedProviderId = null;
      _acceptedProviderName = null;
      _acceptedProviderCar = null;
      _acceptedProviderRating = null;
      _providerPoint = null;
      _providerMarkerPoint = null;
      _listenToRequestIfNeeded();
    }
  }

  @override
  void dispose() {
    _positionSub?.cancel();
    _cancelRequestListeners();
    super.dispose();
  }

  void _cancelRequestListeners() {
    _requestSub?.cancel();
    _offersSub?.cancel();
    _providerLiveSub?.cancel();
  }

  void _startOwnLocationTracking() {
    _positionSub?.cancel();
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),
    ).listen((pos) async {
      final point = osm.GeoPoint(latitude: pos.latitude, longitude: pos.longitude);
      _employeePoint = point;
      await _publishOwnLiveLocation(point);
      await _refreshEmployeeMarker();
      await _drawRouteIfPossible();
    });
  }

  void _listenToRequestIfNeeded() {
    final requestId = widget.requestId;
    if (requestId == null || requestId.isEmpty) return;

    final requestRef = firestore.FirebaseFirestore.instance
        .collection('serviceRequests')
        .doc(requestId);

    _loadingOffers = true;

    _requestSub = requestRef.snapshots().listen((doc) async {
      final data = doc.data();
      if (data == null) return;

      final point = _extractPointFromRequest(data);
      if (point != null) {
        _customerPoint = point;
        await _refreshCustomerMarker();
        await _drawRouteIfPossible();
      }

      final status = (data['status'] ?? '').toString();
      final providerId = (data['providerId'] ?? data['employeeId'] ?? '').toString();
      if ((status == 'accepted' || status == 'ongoing' || status == 'arrived') &&
          providerId.isNotEmpty) {
        _acceptedProviderId = providerId;
        _acceptedProviderName =
            (data['providerName'] ?? data['employeeName'] ?? 'Provider').toString();
        _acceptedProviderCar =
            (data['car'] ?? data['vehicleName'] ?? data['vehicleModel'] ?? 'N/A').toString();
        final raw = data['rating'];
        _acceptedProviderRating = raw is num ? raw.toDouble() : 0.0;
        _listenToAcceptedProvider(providerId);
      } else {
        _acceptedProviderId = null;
        _acceptedProviderName = null;
        _acceptedProviderCar = null;
        _acceptedProviderRating = null;
        _providerLiveSub?.cancel();
        _providerLiveSub = null;
      }

      if (mounted) setState(() {});
    });

    _offersSub = requestRef
        .collection('offers')
        .where('status', isEqualTo: 'pending')
        .snapshots()
        .listen((snapshot) {
      _offers = snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      _loadingOffers = false;
      if (mounted) setState(() {});
    });
  }

  osm.GeoPoint? _extractPointFromRequest(Map<String, dynamic> data) {
    final customerLat = data['customerLat'];
    final customerLng = data['customerLng'];
    if (customerLat is num && customerLng is num) {
      return osm.GeoPoint(
        latitude: customerLat.toDouble(),
        longitude: customerLng.toDouble(),
      );
    }

    final location = data['location'];
    if (location is Map) {
      final lat = location['lat'];
      final lng = location['lng'];
      if (lat is num && lng is num) {
        return osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble());
      }
      final geo = location['geopoint'];
      if (geo is firestore.GeoPoint) {
        return osm.GeoPoint(latitude: geo.latitude, longitude: geo.longitude);
      }
    }

    final customerLocation = data['customerLocation'];
    if (customerLocation is firestore.GeoPoint) {
      return osm.GeoPoint(
        latitude: customerLocation.latitude,
        longitude: customerLocation.longitude,
      );
    }

    return null;
  }

  void _listenToAcceptedProvider(String providerId) {
    _providerLiveSub?.cancel();
    _providerLiveSub = firestore.FirebaseFirestore.instance
        .collection('liveLocations')
        .doc(providerId)
        .snapshots()
        .listen((doc) async {
      final data = doc.data();
      if (data == null) return;
      final lat = data['lat'];
      final lng = data['lng'];
      if (lat is num && lng is num) {
        await _animateProviderTo(
          osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble()),
        );
      }
    });
  }

  Future<void> _publishOwnLiveLocation(osm.GeoPoint point) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    try {
      await firestore.FirebaseFirestore.instance
          .collection('liveLocations')
          .doc(uid)
          .set({
        'lat': point.latitude,
        'lng': point.longitude,
        'updatedAt': firestore.FieldValue.serverTimestamp(),
      }, firestore.SetOptions(merge: true));
    } catch (_) {}
  }

  Future<void> _refreshEmployeeMarker() async {
    if (!_mapReady || _employeePoint == null) return;

    try {
      if (_employeeMarkerPoint != null) {
        await _mapController.removeMarker(_employeeMarkerPoint!);
      }
    } catch (_) {}

    try {
      await _mapController.addMarker(
        _employeePoint!,
        markerIcon: const osm.MarkerIcon(
          icon: Icon(Icons.directions_car, color: Colors.red, size: 42),
        ),
      );
      _employeeMarkerPoint = _employeePoint;
    } catch (_) {}
  }

  Future<void> _refreshCustomerMarker() async {
    if (!_mapReady || _customerPoint == null) return;

    try {
      if (_customerMarkerPoint != null) {
        await _mapController.removeMarker(_customerMarkerPoint!);
      }
    } catch (_) {}

    try {
      await _mapController.addMarker(
        _customerPoint!,
        markerIcon: const osm.MarkerIcon(
          icon: Icon(Icons.location_on, color: Colors.green, size: 44),
        ),
      );
      _customerMarkerPoint = _customerPoint;
    } catch (_) {}
  }

  Future<void> _refreshProviderMarker() async {
    if (!_mapReady || _providerPoint == null) return;

    try {
      if (_providerMarkerPoint != null) {
        await _mapController.removeMarker(_providerMarkerPoint!);
      }
    } catch (_) {}

    try {
      await _mapController.addMarker(
        _providerPoint!,
        markerIcon: const osm.MarkerIcon(
          icon: Icon(Icons.local_taxi, color: Colors.blue, size: 42),
        ),
      );
      _providerMarkerPoint = _providerPoint;
    } catch (_) {}
  }

  Future<void> _animateProviderTo(osm.GeoPoint newPoint) async {
    if (_isAnimatingProvider) return;

    if (_providerPoint == null) {
      _providerPoint = newPoint;
      await _refreshProviderMarker();
      await _drawRouteIfPossible();
      return;
    }

    _isAnimatingProvider = true;
    final start = _providerPoint!;
    const steps = 10;

    for (int i = 1; i <= steps; i++) {
      final lat = start.latitude + (newPoint.latitude - start.latitude) * (i / steps);
      final lng = start.longitude + (newPoint.longitude - start.longitude) * (i / steps);
      _providerPoint = osm.GeoPoint(latitude: lat, longitude: lng);
      await _refreshProviderMarker();
      if (i == steps || i % 3 == 0) {
        await _drawRouteIfPossible();
      }
      await Future.delayed(const Duration(milliseconds: 80));
    }

    _providerPoint = newPoint;
    await _refreshProviderMarker();
    await _drawRouteIfPossible();
    _isAnimatingProvider = false;
  }

  Future<void> _drawRouteIfPossible() async {
    if (!_mapReady) return;

    final from = _providerPoint ?? _employeePoint;
    final to = _customerPoint;
    if (from == null || to == null) return;

    try {
      await _mapController.clearAllRoads();
    } catch (_) {}

    try {
      await _mapController.drawRoad(
        from,
        to,
        roadOption: const osm.RoadOption(
          roadColor: Colors.green,
          roadWidth: 7,
        ),
      );
    } catch (_) {}

    final meters = Geolocator.distanceBetween(
      from.latitude,
      from.longitude,
      to.latitude,
      to.longitude,
    );

    if (!mounted) return;
    setState(() {
      _distanceKm = meters / 1000.0;
      _etaMinutes = ((_distanceKm! / 25.0) * 60.0).ceil();
    });
  }

  Future<void> centerToEmployee() async {
    if (!_mapReady || _employeePoint == null) return;
    try {
      await _mapController.goToLocation(_employeePoint!);
      await _mapController.setZoom(zoomLevel: 16);
    } catch (_) {}
  }

  Future<void> centerToProvider() async {
    if (!_mapReady || _providerPoint == null) return;
    try {
      await _mapController.goToLocation(_providerPoint!);
      await _mapController.setZoom(zoomLevel: 16);
    } catch (_) {}
  }

  Future<void> setCustomerLocation(osm.GeoPoint point) async {
    _customerPoint = point;
    await _refreshCustomerMarker();
    await _drawRouteIfPossible();
    if (_mapReady) {
      try {
        await _mapController.goToLocation(point);
      } catch (_) {}
    }
  }

  Future<void> setCustomerLocationFromMap(dynamic location) async {
    if (location is! Map) return;

    final lat = location['lat'];
    final lng = location['lng'];
    if (lat is num && lng is num) {
      await setCustomerLocation(
        osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble()),
      );
      return;
    }

    final geo = location['geopoint'];
    if (geo is firestore.GeoPoint) {
      await setCustomerLocation(
        osm.GeoPoint(latitude: geo.latitude, longitude: geo.longitude),
      );
    }
  }

  Future<void> _acceptOffer(Map<String, dynamic> offer) async {
    final requestId = widget.requestId;
    if (requestId == null || requestId.isEmpty) return;

    final offerId = (offer['id'] ?? '').toString();
    if (offerId.isEmpty) return;

    try {
      await RequestService.acceptOffer(
        requestId: requestId,
        offerId: offerId,
        offer: offer,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${offer['providerName'] ?? 'Driver'} accepted')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to accept offer: $e')),
      );
    }
  }

  Future<void> _rejectOffer(String offerId) async {
    final requestId = widget.requestId;
    if (requestId == null || requestId.isEmpty) return;

    try {
      await firestore.FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(requestId)
          .collection('offers')
          .doc(offerId)
          .set({
        'status': 'rejected',
        'updatedAt': firestore.FieldValue.serverTimestamp(),
      }, firestore.SetOptions(merge: true));
    } catch (_) {}
  }

  Widget _buildTopInfoCard() {
    if (_distanceKm == null && _etaMinutes == null) return const SizedBox.shrink();

    return Positioned(
      top: 16,
      left: 16,
      right: 16,
      child: Card(
        color: Colors.black87,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            'ETA: ${_etaMinutes ?? '-'} min   •   Distance: ${_distanceKm?.toStringAsFixed(1) ?? '-'} km',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAcceptedDriverCard() {
    return Positioned(
      left: 12,
      right: 12,
      bottom: 12,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const CircleAvatar(
                  radius: 24,
                  child: Icon(Icons.person),
                ),
                title: Text(_acceptedProviderName ?? 'Driver'),
                subtitle: Text(
                  '${_acceptedProviderCar ?? 'N/A'} • ⭐ ${(_acceptedProviderRating ?? 0).toStringAsFixed(1)}',
                ),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${_etaMinutes ?? '-'} min',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const Text('ETA'),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: centerToEmployee,
                      icon: const Icon(Icons.my_location),
                      label: const Text('My location'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: centerToProvider,
                      icon: const Icon(Icons.local_taxi),
                      label: const Text('Driver'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOffersCard() {
    if (widget.requestId == null || widget.requestId!.isEmpty) {
      return const SizedBox.shrink();
    }

    if (_acceptedProviderId != null) {
      return _buildAcceptedDriverCard();
    }

    return Positioned(
      left: 12,
      right: 12,
      bottom: 12,
      child: SizedBox(
        height: 260,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 14),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Driver offers',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: _loadingOffers
                      ? const Center(child: CircularProgressIndicator())
                      : _offers.isEmpty
                          ? const Center(child: Text('No offers yet. Waiting for nearby drivers...'))
                          : ListView.separated(
                              itemCount: _offers.length,
                              separatorBuilder: (_, __) => const Divider(height: 1),
                              itemBuilder: (context, index) {
                                final data = _offers[index];
                                final name = (data['providerName'] ?? 'Driver').toString();
                                final car = (data['car'] ?? 'N/A').toString();
                                final eta = data['etaMinutes']?.toString() ?? '-';
                                final fare = data['fare']?.toString() ?? '-';
                                final ratingRaw = data['rating'];
                                final rating = ratingRaw is num ? ratingRaw.toDouble() : 0.0;

                                return ListTile(
                                  leading: const CircleAvatar(child: Icon(Icons.person)),
                                  title: Text(name),
                                  subtitle: Text('$car • ⭐ ${rating.toStringAsFixed(1)} • ETA $eta min'),
                                  trailing: Wrap(
                                    spacing: 6,
                                    children: [
                                      TextButton(
                                        onPressed: () => _rejectOffer((data['id'] ?? '').toString()),
                                        child: const Text('Reject'),
                                      ),
                                      ElevatedButton(
                                        onPressed: () => _acceptOffer(data),
                                        child: Text('Accept $fare'),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        osm.OSMFlutter(
          controller: _mapController,
          osmOption: osm.OSMOption(
            zoomOption: const osm.ZoomOption(
              initZoom: 15,
              minZoomLevel: 3,
              maxZoomLevel: 18,
            ),
            userTrackingOption: const osm.UserTrackingOption(enableTracking: false),
            showZoomController: true,
          ),
          onMapIsReady: (ready) async {
            if (!mounted || !ready) return;
            setState(() => _mapReady = true);
            await _refreshEmployeeMarker();
            await _refreshCustomerMarker();
            await _refreshProviderMarker();
            await _drawRouteIfPossible();
          },
        ),
        _buildTopInfoCard(),
        _buildOffersCard(),
      ],
    );
  }
}
