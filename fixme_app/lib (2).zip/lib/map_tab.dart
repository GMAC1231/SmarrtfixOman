import 'dart:async';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';

import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;

class MapTab extends StatefulWidget {
  final String? requestId; // ✅ OPTIONAL now

  const MapTab({
    super.key,
    this.requestId,
  });

  @override
  MapTabState createState() => MapTabState();
}

class MapTabState extends State<MapTab> {
  final osm.MapController _mapController = osm.MapController(
    initMapWithUserPosition: const osm.UserTrackingOption(),
  );

  StreamSubscription<Position>? _positionSub;

  osm.GeoPoint? _employeePoint;
  osm.GeoPoint? _customerPoint;

  bool _mapReady = false;

  double? _distanceKm;
  int? _etaMinutes;

  @override
  void initState() {
    super.initState();
    _startTracking();
  }

  @override
  void dispose() {
    _positionSub?.cancel();
    super.dispose();
  }

  // ✅ TRACK EMPLOYEE
  void _startTracking() {
    _positionSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),
    ).listen((pos) async {
      final point = osm.GeoPoint(
        latitude: pos.latitude,
        longitude: pos.longitude,
      );

      _employeePoint = point;

      await _publishLocation(point);
      await _updateMarker();
      await _drawRoute();
    });
  }

  // ✅ FIRESTORE
  Future<void> _publishLocation(osm.GeoPoint point) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    await firestore.FirebaseFirestore.instance
        .collection('liveLocations')
        .doc(uid)
        .set({
      'lat': point.latitude,
      'lng': point.longitude,
    }, firestore.SetOptions(merge: true));
  }

  // ✅ UPDATE MARKER
  Future<void> _updateMarker() async {
    if (!_mapReady || _employeePoint == null) return;

    await _mapController.removeMarker(_employeePoint!);

    await _mapController.addMarker(
      _employeePoint!,
      markerIcon: const osm.MarkerIcon(
        icon: Icon(Icons.directions_car, color: Colors.red, size: 42),
      ),
    );
  }

  // ✅ DRAW ROUTE
  Future<void> _drawRoute() async {
    if (!_mapReady || _employeePoint == null || _customerPoint == null) return;

    await _mapController.clearAllRoads();

    await _mapController.drawRoad(
      _employeePoint!,
      _customerPoint!,
      roadOption: const osm.RoadOption(
        roadColor: Colors.green,
        roadWidth: 6,
      ),
    );

    final meters = Geolocator.distanceBetween(
      _employeePoint!.latitude,
      _employeePoint!.longitude,
      _customerPoint!.latitude,
      _customerPoint!.longitude,
    );

    if (!mounted) return;

    setState(() {
      _distanceKm = meters / 1000;
      _etaMinutes = ((_distanceKm! / 25) * 60).ceil();
    });
  }

  // ✅ REQUIRED BY DASHBOARD
  Future<void> centerToEmployee() async {
    if (!_mapReady || _employeePoint == null) return;

    await _mapController.goToLocation(_employeePoint!);
    await _mapController.setZoom(zoomLevel: 16);
  }

  // ✅ REQUIRED BY REQUEST TAB
  Future<void> setCustomerLocation(osm.GeoPoint point) async {
    _customerPoint = point;

    await _mapController.addMarker(
      point,
      markerIcon: const osm.MarkerIcon(
        icon: Icon(Icons.location_on, color: Colors.green, size: 42),
      ),
    );

    await _drawRoute();
  }

  // ✅ SAFE CONVERTER
  Future<void> setCustomerLocationFromMap(dynamic location) async {
    if (location is! Map) return;

    final lat = location['lat'];
    final lng = location['lng'];

    if (lat is num && lng is num) {
      await setCustomerLocation(
        osm.GeoPoint(
          latitude: lat.toDouble(),
          longitude: lng.toDouble(),
        ),
      );
    }

    final geo = location['geopoint'];

    if (geo is firestore.GeoPoint) {
      await setCustomerLocation(
        osm.GeoPoint(
          latitude: geo.latitude,
          longitude: geo.longitude,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        osm.OSMFlutter(
          controller: _mapController,
          osmOption: osm.OSMOption(
            zoomOption: const osm.ZoomOption(initZoom: 15),
          ),
          onMapIsReady: (ready) {
            if (ready) setState(() => _mapReady = true);
          },
        ),

        if (_distanceKm != null)
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              color: Colors.black87,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'ETA: ${_etaMinutes ?? '-'} min • ${_distanceKm!.toStringAsFixed(2)} km',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
      ],
    );
  }
}