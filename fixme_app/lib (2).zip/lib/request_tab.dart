import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_osm_plugin/flutter_osm_plugin.dart' as osm;

import 'chat_screen.dart';
import 'map_tab.dart';

class EmployeeRequestsTab extends StatefulWidget {
  final GlobalKey<MapTabState> mapTabKey;

  const EmployeeRequestsTab({super.key, required this.mapTabKey});

  @override
  State<EmployeeRequestsTab> createState() => _EmployeeRequestsTabState();
}

class _EmployeeRequestsTabState extends State<EmployeeRequestsTab> {
  @override
  Widget build(BuildContext context) {
    final query = FirebaseFirestore.instance
        .collection('serviceRequests')
        .where('status', whereIn: ['bidding', 'pending'])
        .orderBy('createdAt', descending: true);

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(child: Text('Error: ${snap.error}'));
        }
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snap.data!.docs;
        if (docs.isEmpty) {
          return const Center(child: Text('No open requests'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final reqDoc = docs[index];
            final data = reqDoc.data();
            final customerName =
                (data['customerName'] ?? data['customerEmail'] ?? 'Customer').toString();
            final customerEmail = (data['customerEmail'] ?? '').toString();
            final customerPhone = (data['customerPhone'] ?? '').toString();
            final serviceType = (data['serviceType'] ?? 'Service').toString();
            final priceOffer = (data['priceOffer'] ?? '-').toString();
            final customerId = (data['customerId'] ?? '').toString();
            final location = data['location'];
            final address = location is Map ? (location['address'] ?? '').toString() : '';
            final gp = _extractGeoPoint(location);

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      serviceType,
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text('Customer: $customerName'),
                    if (customerEmail.isNotEmpty) Text('Email: $customerEmail'),
                    if (customerPhone.isNotEmpty) Text('Phone: $customerPhone'),
                    Text('Offer: $priceOffer'),
                    if (address.isNotEmpty) Text('Address: $address'),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        if (gp != null)
                          OutlinedButton.icon(
                            onPressed: () {
                              widget.mapTabKey.currentState?.setCustomerLocation(gp);
                            },
                            icon: const Icon(Icons.route),
                            label: const Text('Route'),
                          ),
                        ElevatedButton.icon(
                          onPressed: () => _acceptRequest(reqDoc.id, data),
                          icon: const Icon(Icons.check_circle),
                          label: const Text('Accept'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => _rejectRequest(reqDoc.id),
                          icon: const Icon(Icons.cancel),
                          label: const Text('Reject'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => _showOfferDialog(reqDoc.id, gp),
                          icon: const Icon(Icons.local_offer_outlined),
                          label: const Text('Offer'),
                        ),
                        if (customerId.isNotEmpty)
                          ElevatedButton.icon(
                            onPressed: () => _openChat(customerId, reqDoc.id, customerName),
                            icon: const Icon(Icons.chat_bubble_outline),
                            label: const Text('Chat'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  osm.GeoPoint? _extractGeoPoint(dynamic location) {
    if (location is! Map) return null;

    final latValue = location['lat'];
    final lngValue = location['lng'];
    if (latValue is num && lngValue is num) {
      return osm.GeoPoint(latitude: latValue.toDouble(), longitude: lngValue.toDouble());
    }

    final geo = location['geopoint'];
    if (geo is GeoPoint) {
      return osm.GeoPoint(latitude: geo.latitude, longitude: geo.longitude);
    }

    if (geo is Map) {
      final lat = geo['lat'];
      final lng = geo['lng'];
      if (lat is num && lng is num) {
        return osm.GeoPoint(latitude: lat.toDouble(), longitude: lng.toDouble());
      }
    }
    return null;
  }

  Future<void> _acceptRequest(String requestId, Map<String, dynamic> data) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final employeeDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    final employeeData = employeeDoc.data() ?? <String, dynamic>{};

    await FirebaseFirestore.instance.collection('serviceRequests').doc(requestId).update({
      'status': 'accepted',
      'employeeId': uid,
      'employeeName': employeeData['name'] ?? employeeData['fullName'] ?? employeeData['username'] ?? 'Provider',
      'acceptedAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Request accepted')),
    );
  }

  Future<void> _rejectRequest(String requestId) async {
    try {
      await FirebaseFirestore.instance.collection('serviceRequests').doc(requestId).update({
        'status': 'rejected',
        'rejectedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Request rejected')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to reject: $e')),
      );
    }
  }

  Future<void> _showOfferDialog(String requestId, osm.GeoPoint? gp) async {
    final controller = TextEditingController();
    double? value;

    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Send your offer'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Proposed fare',
            prefixText: 'PKR ',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              value = double.tryParse(controller.text.trim());
              if (value != null) {
                Navigator.pop(context);
              }
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );

    if (value == null) return;
    if (gp != null) {
      widget.mapTabKey.currentState?.setCustomerLocation(gp);
    }

    try {
      final me = FirebaseAuth.instance.currentUser;
      if (me == null) return;
      await FirebaseFirestore.instance
          .collection('bids')
          .doc(requestId)
          .collection('offers')
          .doc(me.uid)
          .set({
        'proposedFare': value,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Offer sent')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to send offer: $e')),
      );
    }
  }

  void _openChat(String customerId, String requestId, String title) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          chatId: '$requestId-$customerId',
          otherUserId: customerId,
          title: title,
          requestId: requestId,
          iAmCustomer: false,
          providerId: FirebaseAuth.instance.currentUser?.uid ?? '',
        ),
      ),
    );
  }
}
