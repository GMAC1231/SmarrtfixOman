import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'chat_screen.dart';
import 'session_utils.dart';
import 'settings_screen.dart';

const Color _brand = Color(0xFF01411C);

const List<Map<String, String>> _serviceCategories = [
  {'key': 'Technician', 'emoji': '🔧'},
  {'key': 'Plumber', 'emoji': '🚰'},
  {'key': 'Electrician', 'emoji': '💡'},
  {'key': 'Carpenter', 'emoji': '🪚'},
  {'key': 'Painter', 'emoji': '🎨'},
  {'key': 'Handyman', 'emoji': '🛠️'},
  {'key': 'Cleaner', 'emoji': '🧹'},
];

class CustomerDashboardScreen extends StatefulWidget {
  const CustomerDashboardScreen({super.key});

  @override
  State<CustomerDashboardScreen> createState() => _CustomerDashboardScreenState();
}

class _CustomerDashboardScreenState extends State<CustomerDashboardScreen> {
  int _currentIndex = 0;
  Position? _position;
  bool _loadingLocation = false;

  User? get _user => FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  Future<void> _loadLocation() async {
    setState(() => _loadingLocation = true);
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) return;

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return;
      }

      final pos = await Geolocator.getCurrentPosition();
      if (mounted) {
        setState(() => _position = pos);
      }
    } catch (_) {
      // keep dashboard usable even if GPS fails
    } finally {
      if (mounted) {
        setState(() => _loadingLocation = false);
      }
    }
  }

  Future<void> _createRequest({
    required String serviceType,
    required double fare,
    String? note,
  }) async {
    final user = _user;
    if (user == null) return;

    final lat = _position?.latitude;
    final lng = _position?.longitude;

    final data = <String, dynamic>{
      'customerId': user.uid,
      'customerName': user.displayName ?? 'Customer',
      'customerEmail': user.email,
      'customerPhone': user.phoneNumber,
      'serviceType': serviceType,
      'priceOffer': fare,
      'status': 'bidding',
      'createdAt': firestore.FieldValue.serverTimestamp(),
      'updatedAt': firestore.FieldValue.serverTimestamp(),
      'customerNote': note?.trim().isEmpty == true ? null : note?.trim(),
      'customerLat': lat,
      'customerLng': lng,
      if (lat != null && lng != null) 'customerLocation': firestore.GeoPoint(lat, lng),
      'location': {
        'lat': lat,
        'lng': lng,
      },
    };

    await firestore.FirebaseFirestore.instance.collection('serviceRequests').add(data);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Request sent successfully')),
    );
    setState(() => _currentIndex = 1);
  }

  Future<void> _openRequestDialog() async {
    final fareController = TextEditingController();
    final noteController = TextEditingController();
    String selected = _serviceCategories.first['key']!;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            return AlertDialog(
              title: const Text('Book a service'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selected,
                      items: _serviceCategories
                          .map(
                            (item) => DropdownMenuItem<String>(
                              value: item['key'],
                              child: Text('${item['emoji']} ${item['key']}'),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setLocalState(() => selected = value);
                        }
                      },
                      decoration: const InputDecoration(
                        labelText: 'Service type',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: fareController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Your fare offer',
                        border: OutlineInputBorder(),
                        prefixText: 'OMR ',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: noteController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Optional note',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final fare = double.tryParse(fareController.text.trim());
                    if (fare == null || fare <= 0) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Enter a valid fare amount')),
                      );
                      return;
                    }
                    Navigator.pop(context);
                    await _createRequest(
                      serviceType: selected,
                      fare: fare,
                      note: noteController.text,
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: _brand),
                  child: const Text('Send'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please sign in first')),
      );
    }

    final pages = [
      _CustomerHomeTab(
        user: user,
        position: _position,
        loadingLocation: _loadingLocation,
        onRefreshLocation: _loadLocation,
        onBookNow: _openRequestDialog,
      ),
      _CustomerActiveRequestsTab(userId: user.uid),
      const SettingsScreen(isEmployee: false, currentTheme: 'light'),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _brand,
        foregroundColor: Colors.white,
        title: const Text('Customer Dashboard'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: const BoxDecoration(color: _brand),
              accountName: Text(user.displayName ?? 'Customer'),
              accountEmail: Text(user.email ?? ''),
              currentAccountPicture: const CircleAvatar(
                child: Icon(Icons.person),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home_outlined),
              title: const Text('Home'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.work_outline),
              title: const Text('My Requests'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 1);
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('Settings'),
              onTap: () {
                Navigator.pop(context);
                setState(() => _currentIndex = 2);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.add_circle_outline),
              title: const Text('New Request'),
              onTap: () async {
                Navigator.pop(context);
                await _openRequestDialog();
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () async {
                Navigator.pop(context);
                await SessionUtils.logout(context);
              },
            ),
          ],
        ),
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _openRequestDialog,
              backgroundColor: _brand,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('Request Service'),
            )
          : null,
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        selectedItemColor: _brand,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.work), label: 'Requests'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class _CustomerHomeTab extends StatelessWidget {
  final User user;
  final Position? position;
  final bool loadingLocation;
  final Future<void> Function() onRefreshLocation;
  final Future<void> Function() onBookNow;

  const _CustomerHomeTab({
    required this.user,
    required this.position,
    required this.loadingLocation,
    required this.onRefreshLocation,
    required this.onBookNow,
  });

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: onRefreshLocation,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: _brand,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome, ${user.displayName ?? 'Customer'}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  user.email ?? '',
                  style: const TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Icon(Icons.my_location, color: Colors.white),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        loadingLocation
                            ? 'Detecting your location...'
                            : position == null
                                ? 'Location unavailable'
                                : 'Lat ${position!.latitude.toStringAsFixed(5)}, Lng ${position!.longitude.toStringAsFixed(5)}',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Available services',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ..._serviceCategories.map(
            (item) => Card(
              child: ListTile(
                leading: Text(
                  item['emoji']!,
                  style: const TextStyle(fontSize: 24),
                ),
                title: Text(item['key']!),
                subtitle: const Text('Tap Request Service to create a booking'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 18),
                onTap: onBookNow,
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: onRefreshLocation,
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh location'),
          ),
        ],
      ),
    );
  }
}

class _CustomerActiveRequestsTab extends StatelessWidget {
  final String userId;

  const _CustomerActiveRequestsTab({required this.userId});

  @override
  Widget build(BuildContext context) {
    final query = firestore.FirebaseFirestore.instance
        .collection('serviceRequests')
        .where('customerId', isEqualTo: userId)
        .orderBy('createdAt', descending: true);

    return StreamBuilder<firestore.QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Center(child: Text('No requests yet'));
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data();
            final status = (data['status'] ?? 'unknown').toString();
            final serviceType = (data['serviceType'] ?? 'Service').toString();
            final fare = data['agreedFare'] ?? data['priceOffer'];
            final providerName =
                (data['employeeName'] ?? data['providerName'] ?? 'Waiting for provider')
                    .toString();
            final providerId = (data['employeeId'] ?? data['providerId'] ?? '').toString();
            final createdAt = data['createdAt'];

            return Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            serviceType,
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                        _StatusChip(status: status),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('Fare: ${fare ?? '-'}'),
                    Text('Provider: $providerName'),
                    if (createdAt is firestore.Timestamp)
                      Text('Created: ${createdAt.toDate()}'),
                    const SizedBox(height: 12),
                    if (status == 'bidding' || status == 'pending') ...[
                      _OfferSection(requestId: doc.id),
                      const SizedBox(height: 12),
                    ],
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        if (providerId.isNotEmpty)
                          ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    chatId: '${doc.id}-$providerId',
                                    otherUserId: providerId,
                                    title: providerName,
                                    requestId: doc.id,
                                    iAmCustomer: true,
                                    providerId: providerId,
                                  ),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(backgroundColor: _brand),
                            icon: const Icon(Icons.chat),
                            label: const Text('Chat'),
                          ),
                        if (status == 'bidding' || status == 'pending')
                          OutlinedButton.icon(
                            onPressed: () async {
                              await firestore.FirebaseFirestore.instance
                                  .collection('serviceRequests')
                                  .doc(doc.id)
                                  .set({
                                'status': 'cancelled',
                                'updatedAt': firestore.FieldValue.serverTimestamp(),
                              }, firestore.SetOptions(merge: true));
                            },
                            icon: const Icon(Icons.cancel_outlined),
                            label: const Text('Cancel'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _OfferSection extends StatelessWidget {
  final String requestId;

  const _OfferSection({required this.requestId});

  Future<void> _acceptOffer(String offerId, Map<String, dynamic> offer) async {
    final requestRef = firestore.FirebaseFirestore.instance
        .collection('serviceRequests')
        .doc(requestId);
    final offersRef = requestRef.collection('offers');

    final providerId = (offer['providerId'] ?? '').toString();
    final providerName = (offer['providerName'] ?? 'Provider').toString();
    final car = (offer['car'] ?? 'N/A').toString();
    final ratingRaw = offer['rating'];
    final rating = ratingRaw is num ? ratingRaw.toDouble() : 0.0;
    final fare = offer['fare'];

    await requestRef.set({
      'status': 'accepted',
      'providerId': providerId,
      'employeeId': providerId,
      'providerName': providerName,
      'employeeName': providerName,
      'car': car,
      'rating': rating,
      'acceptedOfferId': offerId,
      if (fare != null) 'agreedFare': fare,
      'updatedAt': firestore.FieldValue.serverTimestamp(),
    }, firestore.SetOptions(merge: true));

    final allOffers = await offersRef.get();
    for (final doc in allOffers.docs) {
      await doc.reference.set({
        'status': doc.id == offerId ? 'accepted' : 'rejected',
        'updatedAt': firestore.FieldValue.serverTimestamp(),
      }, firestore.SetOptions(merge: true));
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<firestore.QuerySnapshot<Map<String, dynamic>>>(
      stream: firestore.FirebaseFirestore.instance
          .collection('serviceRequests')
          .doc(requestId)
          .collection('offers')
          .where('status', isEqualTo: 'pending')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: LinearProgressIndicator(),
          );
        }

        final offers = snapshot.data!.docs;
        if (offers.isEmpty) {
          return const Text('Waiting for offers from providers...');
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Offers',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ...offers.map((offerDoc) {
              final offer = offerDoc.data();
              final providerName = (offer['providerName'] ?? 'Provider').toString();
              final car = (offer['car'] ?? 'N/A').toString();
              final fare = offer['fare']?.toString() ?? '-';
              final eta = offer['etaMinutes']?.toString() ?? '-';
              final ratingRaw = offer['rating'];
              final rating = ratingRaw is num ? ratingRaw.toDouble() : 0.0;

              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                color: Colors.grey.shade50,
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(providerName),
                  subtitle: Text('$car • ⭐ ${rating.toStringAsFixed(1)} • ETA $eta min'),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      await _acceptOffer(offerDoc.id, offer);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('$providerName accepted')),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: _brand),
                    child: Text('Accept $fare'),
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case 'accepted':
        color = Colors.green;
        break;
      case 'ongoing':
        color = Colors.orange;
        break;
      case 'completed':
        color = Colors.blue;
        break;
      case 'cancelled':
      case 'rejected':
        color = Colors.redAccent;
        break;
      default:
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
      ),
    );
  }
}
