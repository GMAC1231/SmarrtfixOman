import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';
import 'map_tab.dart';

class ActiveJobTab extends StatelessWidget {
  final GlobalKey<MapTabState>? mapTabKey;

  const ActiveJobTab({super.key, this.mapTabKey});

  Future<void> _updateStatus(
    BuildContext context,
    String requestId,
    String status,
  ) async {
    try {
      await FirebaseFirestore.instance.collection('serviceRequests').doc(requestId).set({
        'status': status,
        if (status == 'ongoing') 'startedAt': FieldValue.serverTimestamp(),
        if (status == 'completed') 'completedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Job marked as $status')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Center(child: Text('Please log in'));
    }

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('serviceRequests')
          .where('status', whereIn: ['accepted', 'ongoing', 'arrived'])
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs.where((doc) {
          final data = doc.data();
          return data['employeeId'] == user.uid || data['providerId'] == user.uid;
        }).toList();

        if (docs.isEmpty) {
          return const Center(child: Text('No active job'));
        }

        final doc = docs.first;
        final data = doc.data();
        final status = data['status']?.toString() ?? 'unknown';
        final service = data['serviceType']?.toString() ?? 'Service';
        final customerName = data['customerName']?.toString() ?? 'Customer';
        final customerId = data['customerId']?.toString() ?? '';
        final price = data['agreedFare'] ?? data['priceOffer'] ?? 0;
        final providerName = (data['providerName'] ?? data['employeeName'] ?? 'Provider').toString();

        final location = data['location'];
        final customerLat = data['customerLat'];
        final customerLng = data['customerLng'];

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Card(
            elevation: 6,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    service,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text('👤 Customer: $customerName'),
                  Text('🧑‍🔧 Provider: $providerName'),
                  Text('💰 $price OMR'),
                  Text('📌 Status: $status'),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      if (customerLat is num && customerLng is num)
                        OutlinedButton.icon(
                          onPressed: () {
                            mapTabKey?.currentState?.setCustomerLocationFromMap({
                              'lat': customerLat,
                              'lng': customerLng,
                            });
                          },
                          icon: const Icon(Icons.route),
                          label: const Text('Show Route'),
                        )
                      else if (location is Map)
                        OutlinedButton.icon(
                          onPressed: () {
                            mapTabKey?.currentState?.setCustomerLocationFromMap(location);
                          },
                          icon: const Icon(Icons.route),
                          label: const Text('Show Route'),
                        ),
                      if (customerId.isNotEmpty)
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  chatId: '${doc.id}-$customerId',
                                  otherUserId: customerId,
                                  title: customerName,
                                  requestId: doc.id,
                                  iAmCustomer: false,
                                  providerId: user.uid,
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('Chat'),
                        ),
                    ],
                  ),
                  const Spacer(),
                  if (status == 'accepted')
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => _updateStatus(context, doc.id, 'ongoing'),
                        child: const Text('Start Job'),
                      ),
                    ),
                  if (status == 'ongoing')
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () => _updateStatus(context, doc.id, 'completed'),
                        child: const Text('Complete Job'),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
